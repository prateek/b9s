#!/usr/bin/env bash
# Write the CI bazelrc for .github/actions/setup-bazel.
#
# Always: --repository_cache under BAZEL_CI_CACHE_DIR (the directory the
# runner cache saves and restores; Bazel checks every hit's sha256) and no
# repo contents cache (--repo_contents_cache=: its extracted repos would be
# restored from the runner cache unverified). Never --disk_cache: remote runs have the
# remote cache, and a local run's disk cache (about 7 GB) would not fit next to
# its output base on a hosted runner.
#
# Remote execution only when all three of BAZEL_REMOTE_EXECUTOR, RBE_TLS_CERT
# and RBE_TLS_KEY are set (repo secrets; empty on fork PRs, so those runs stay
# local). Exactly one or two of them is a misconfiguration and fails. Optional:
# RBE_TLS_CA (base64 PEM CA bundle) and RBE_INSTANCE (instance name; a warning
# when empty, because the default instance may share its action cache with
# other repos on the same farm). Cert and key are base64-encoded PEM (raw PEM
# is accepted too). Every line of the decoded PEM is masked in the job log.
#
# CI uploads only remotely executed results (--noremote_upload_local_results):
# a job's locally executed actions (PR code included) never enter the shared
# action cache from here. Developer rcs keep Bazel's default.
#
# The rc and the key material go to BAZEL_CI_SECRET_DIR, which must be outside
# the workspace (tests that walk the checkout must never see an endpoint or a
# cert path) and outside BAZEL_CI_CACHE_DIR (the runner cache must never store
# credentials). The endpoint is masked in the job log.
#
# BAZEL_FORK_CACHE=true (bazel.yml mode "cache": rbe=cache dispatches, and
# fork/Dependabot runs while rbe-fork is closed) appends --config=fork-cache:
# .bazelrc's credential-free, read-only rbe-west cache. While that cache
# advertises zstd (cache-zstd-probe.sh asks its GetCapabilities; any failure
# means no) it also asks for zstd transfers (--remote_cache_compression). A
# probe, not a repository variable: fork pull_request runs see no vars. No
# other mode ever asks, because only the anonymous cache can advertise zstd,
# and Bazel refuses a remote that does not. With BAZEL_RRC_READ=true too
# (bazel.yml's remote repo contents cache readers alone: the jobs whose
# configs rrc-lane-commands.txt seeds), and while rbe-cache answers
# (cache-rrc-probe.sh, which also holds the committed kill switch), it reads
# Bazel's remote repo contents cache, as those jobs' trusted readers do: the
# trees rrc-seed wrote on main pushes, through rbe-cache's anonymous AC and
# CAS reads. The job's step summary says whether it reads, and why.
#
# RBE_FORK_CERT_FILE + RBE_FORK_KEY_FILE + RBE_FORK_ENDPOINT + RBE_FORK_INSTANCE
# (bazel.yml modes fork-ro/fork-rw: fork-credential.sh's outputs, a
# short-lived rbe-fork-mint certificate) enable --config=remote-exec against
# rbe-fork: instance oss-fork (the fork pool, nothing cached) or oss
# (allowlisted authors: the OSS pool, results cached by the workers). The
# three modes are mutually exclusive.
#
# Outputs (to $GITHUB_OUTPUT when set, else stdout): rc=<path>,
# remote=true|false, cache=true|false.
set -euo pipefail

cache_dir="${BAZEL_CI_CACHE_DIR:?BAZEL_CI_CACHE_DIR is required}"
secret_dir="${BAZEL_CI_SECRET_DIR:?BAZEL_CI_SECRET_DIR is required}"
workspace="${GITHUB_WORKSPACE:-$PWD}"

abs() { mkdir -p "$1" && (cd "$1" && pwd -P); }
cache_dir="$(abs "$cache_dir")"
secret_dir="$(abs "$secret_dir")"
workspace="$(cd "$workspace" && pwd -P)"
case "$secret_dir/" in
"$workspace"/*)
	echo "setup-bazel: BAZEL_CI_SECRET_DIR ($secret_dir) must be outside the workspace" >&2
	exit 1
	;;
"$cache_dir"/*)
	echo "setup-bazel: BAZEL_CI_SECRET_DIR must not be inside the cached BAZEL_CI_CACHE_DIR" >&2
	exit 1
	;;
esac
chmod 700 "$secret_dir"
mkdir -p "$cache_dir/repo"

mask() {
	local v="${1:-}"
	[[ -z "$v" ]] && return 0
	printf '::add-mask::%s\n' "$v"
}

# Mask the endpoint and its bare host[:port]: Bazel prints bytestream:// URIs
# that carry the host without the scheme.
executor="${BAZEL_REMOTE_EXECUTOR:-}"
if [[ -n "$executor" ]]; then
	mask "$executor"
	hostport="${executor#*://}"
	hostport="${hostport%%/*}"
	mask "$hostport"
	mask "${hostport%:*}"
	# Bazel's connection errors print the resolved address ("host/1.2.3.4:443").
	if command -v getent >/dev/null 2>&1; then
		while read -r addr _; do
			mask "$addr"
		done < <(getent ahosts "${hostport%:*}" 2>/dev/null | sort -u -k1,1)
	fi
fi

cert="${RBE_TLS_CERT:-}"
key="${RBE_TLS_KEY:-}"
ca="${RBE_TLS_CA:-}"
instance="${RBE_INSTANCE:-}"
fork_cache="${BAZEL_FORK_CACHE:-}"
rrc_reader="${BAZEL_RRC_READ:-}"
fork_cert="${RBE_FORK_CERT_FILE:-}"
fork_key="${RBE_FORK_KEY_FILE:-}"
fork_endpoint="${RBE_FORK_ENDPOINT:-}"
fork_instance="${RBE_FORK_INSTANCE:-}"
fork_fields=0
for v in "$fork_cert" "$fork_key" "$fork_endpoint" "$fork_instance"; do
	[[ -n "$v" ]] && fork_fields=$((fork_fields + 1))
done
case "$fork_fields/$fork_instance" in
0/ | 4/oss | 4/oss-fork) ;;
*)
	echo "setup-bazel: RBE_FORK_CERT_FILE, RBE_FORK_KEY_FILE, RBE_FORK_ENDPOINT and RBE_FORK_INSTANCE (oss or oss-fork) go together" >&2
	exit 1
	;;
esac
case "$fork_cache" in
"" | true) ;;
*)
	echo "setup-bazel: BAZEL_FORK_CACHE must be \"true\" or empty, got \"$fork_cache\"" >&2
	exit 1
	;;
esac
case "$rrc_reader" in
"" | true) ;;
*)
	echo "setup-bazel: BAZEL_RRC_READ must be \"true\" or empty, got \"$rrc_reader\"" >&2
	exit 1
	;;
esac

rc="$secret_dir/ci.bazelrc"
umask 077
{
	echo "# Generated by .github/actions/setup-bazel; not a workspace file."
	echo "common --repository_cache=$cache_dir/repo"
	# The repo contents cache (default: under the repository cache, so in
	# the runner cache) holds extracted repos Bazel never re-verifies; off.
	echo "common --repo_contents_cache="
	# Every mode fetches external repositories on the runner. gazelle's
	# go_repository fetches Go modules with the go command (fetch_repo), not
	# Bazel's downloader, and the go command never retries: one TLS
	# handshake timeout against proxy.golang.org failed a whole lane. With
	# "|" the go command moves to the next entry on any error (a ","
	# list only on 404/410): the proxy twice, then the module's origin.
	# fetch_repo checks every module against its go.sum hash whatever the
	# source. Key neutral: repository fetching only, no action reads it.
	echo "common --repo_env=GOPROXY=https://proxy.golang.org|https://proxy.golang.org|direct"
	# Bazel's own downloader (the Go SDK, http_archive) already retries;
	# give slow TLS handshakes and reads twice the default timeouts.
	echo "common --http_timeout_scaling=2.0"
	# The client's JVM heap. Bazel's default caps it at 25% of RAM, about
	# 2 GB on the 8 GB 2 vCPU runners every remote lane uses; //... analysis
	# fits today, with little headroom. A startup option: key neutral, it only
	# restarts the server. Each lane reports peak-heap-size to size this.
	echo "startup --host_jvm_args=-Xmx4g"
} >"$rc"

# write_pem DEST VALUE: decode base64 (or accept raw PEM) and check it is PEM.
write_pem() {
	local dest="$1" body="$2"
	body="$(printf '%s' "$body" | tr -d '\r')"
	if [[ "$body" != *"-----BEGIN "* ]]; then
		if ! body="$(printf '%s' "$body" | tr -d '\n ' | base64 -d 2>/dev/null)"; then
			echo "setup-bazel: $(basename "$dest") secret is neither PEM nor base64 PEM" >&2
			return 1
		fi
	fi
	if [[ "$body" != *"-----BEGIN "* ]]; then
		echo "setup-bazel: $(basename "$dest") secret does not decode to PEM" >&2
		return 1
	fi
	# GitHub masks the secret as stored (base64), not what it decodes to.
	local line
	while IFS= read -r line; do
		[[ -z "$line" || "$line" == -----* ]] || mask "$line"
	done <<<"$body"
	printf '%s\n' "$body" >"$dest"
	chmod 600 "$dest"
}

set_fields=0
for v in "$executor" "$cert" "$key"; do
	[[ -n "$v" ]] && set_fields=$((set_fields + 1))
done

remote=false
cache=false
if [[ "$fork_fields" -eq 4 ]]; then
	if [[ "$set_fields" -ne 0 || "$fork_cache" == true ]]; then
		echo "setup-bazel: the rbe-fork certificate, the remote execution secrets and BAZEL_FORK_CACHE are mutually exclusive" >&2
		exit 1
	fi
	{
		echo "build:remote-exec --remote_executor=$fork_endpoint"
		echo "build:remote-exec --tls_client_certificate=$fork_cert"
		echo "build:remote-exec --tls_client_key=$fork_key"
		echo "build:remote-exec --remote_instance_name=$fork_instance"
		echo "build:remote-exec --noremote_upload_local_results"
		# The farm admits 128 connections per source IP (Blacksmith runners
		# share addresses). Key-neutral, like everything in this rc.
		echo "build:remote-exec --remote_max_connections=8"
		echo "build --config=remote-exec"
	} >>"$rc"
	remote=true
	echo "setup-bazel: remote execution on rbe-fork (instance $fork_instance, short-lived certificate)"
elif [[ "$set_fields" -eq 3 ]]; then
	if [[ "$fork_cache" == true ]]; then
		echo "setup-bazel: BAZEL_FORK_CACHE and the remote execution secrets are mutually exclusive" >&2
		exit 1
	fi
	write_pem "$secret_dir/client.crt" "$cert"
	write_pem "$secret_dir/client.key" "$key"
	# Outside the rc block below: write_pem's mask commands go to the log.
	if [[ -n "$ca" ]]; then
		write_pem "$secret_dir/ca.crt" "$ca"
	fi
	{
		echo "build:remote-exec --remote_executor=$executor"
		echo "build:remote-exec --tls_client_certificate=$secret_dir/client.crt"
		echo "build:remote-exec --tls_client_key=$secret_dir/client.key"
		if [[ -n "$ca" ]]; then
			echo "build:remote-exec --tls_certificate=$secret_dir/ca.crt"
		fi
		if [[ -n "$instance" ]]; then
			echo "build:remote-exec --remote_instance_name=$instance"
		fi
		echo "build:remote-exec --noremote_upload_local_results"
		# Every command in this job (test, run //:gazelle, query) uses the
		# executor; the committed .bazelrc holds the generic remote-exec tuning.
		echo "build --config=remote-exec"
	} >>"$rc"
	if [[ -z "$instance" ]]; then
		echo "::warning title=RBE_INSTANCE not set::remote execution uses the executor's default instance, whose action cache other repos on the farm may share; set RBE_INSTANCE to a beads-only instance"
	fi
	remote=true
	echo "setup-bazel: remote execution enabled"
elif [[ "$set_fields" -ne 0 ]]; then
	echo "setup-bazel: remote execution is partially configured; BAZEL_REMOTE_EXECUTOR, RBE_TLS_CERT and RBE_TLS_KEY must be set together (or none, for local execution)" >&2
	exit 1
elif [[ "$fork_cache" == true ]]; then
	# The remote repo contents cache, read-only, for the jobs that opt in
	# (BAZEL_RRC_READ: only their configs are seeded), while rbe-cache
	# answers and the probe's kill switch (fork_rrc_read) is on. With the
	# startup flag set and the cache unreachable, every repository first
	# fails a lookup (gascity engdocs/design/bazel-remote-repo-contents-cache.md,
	# R6), so a closed or down rbe-cache gets no lines, and a notice says
	# why. That holds at probe time only: after loading, Bazel fetches the
	# files lazily, and losing rbe-cache then fails the command (R4). Both
	# lines are key neutral, as for the trusted readers; fork-cache uploads
	# nothing, and rbe-cache refuses every write.
	rrc_read=false
	if [[ "$rrc_reader" != true ]]; then
		why="not a remote repo contents cache reader (no BAZEL_RRC_READ)"
	elif why=$(bash "$(dirname "${BASH_SOURCE[0]}")/cache-rrc-probe.sh" 2>&1); then
		rrc_read=true
		echo "$why"
	else
		echo "::notice title=No remote repo contents cache::$why"
	fi
	echo "Fork cache remote repo contents cache read: **$([[ "$rrc_read" == true ]] && echo on || echo off)** (${why#rbe-cache rrc probe: })" >>"${GITHUB_STEP_SUMMARY:-/dev/null}"
	# zstd for the anonymous cache's transfers while it advertises zstd:
	# transport only, so action keys are unchanged. The probes never fail
	# this script; they only decide the lines.
	{
		echo "build --config=fork-cache"
		if bash "$(dirname "${BASH_SOURCE[0]}")/cache-zstd-probe.sh"; then
			echo "build:fork-cache --remote_cache_compression"
		fi
		if [[ "$rrc_read" == true ]]; then
			echo "startup --experimental_remote_repo_contents_cache"
			echo "common --loading_phase_threads=64"
		fi
	} >>"$rc"
	cache=true
	echo "setup-bazel: read-only remote cache (rbe-cache); executing locally"
else
	echo "setup-bazel: no remote execution secrets; running locally"
fi

out="${GITHUB_OUTPUT:-/dev/stdout}"
{
	echo "rc=$rc"
	echo "remote=$remote"
	echo "cache=$cache"
} >>"$out"
