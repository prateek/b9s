package conformance

import (
	"context"
	"errors"
	"fmt"
	"reflect"
	"testing"
	"time"

	"github.com/steveyegge/beads/internal/types"
	publicops "github.com/steveyegge/beads/issueops"
)

// This file holds the semantic contract every implementation of
// publicops.Sweeper must satisfy. Each case asserts what issueops/sweeper.go
// PROMISES, cited by line, rather than what any one backend happens to do; a
// backend that genuinely disagrees is parked at its own wiring site with
// skipKnownDivergence so the case still runs on the ones that agree.
//
// THERE ARE TWO BODIES BEHIND THE THREE WIRINGS. dolt and embeddeddolt share
// internal/storage/issueops.SweepInTx and differ only in how they reach a
// transaction; the unit-of-work provider goes through the domain use cases and
// is genuinely separate code. So the wirings are one vote plus an engine check,
// and a second independent vote — and the selection half of both votes runs
// through the SAME internal/workapi functions. The cases below therefore spend
// their assertions on what only a real backend can show: which rows are gone,
// what a dry run left alone, what the version-control plane recorded.
//
// EVERY CASE SCOPES ITSELF WITH AN ID PATTERN, which is a precondition rather
// than hygiene. A sweep is asked of a whole TIER, so a case that swept without
// a pattern would delete the rows the next case seeded — and on the ephemeral
// tier that is a legal unfiltered request the role does not refuse.
//
// EVERY CASE PINS closed_at EXPLICITLY. The recheck the role performs is
// against a cutoff, and a seeded row whose closed_at defaulted to "now" would
// make "closed before now" a race with the test's own clock.

// SweeperFixture supplies adapter-specific storage access for the
// bulk-clearance assertions. Every field is named and typed exactly like the
// per-backend roleFixtureKit hook it is filled from.
type SweeperFixture struct {
	// IssuePrefix namespaces the ids each assertion seeds, so several of them
	// can share one database.
	IssuePrefix string
	// Sweeper is the surface under test.
	Sweeper publicops.Sweeper
	// CreateIssue seeds a durable issue in the issues plane.
	CreateIssue func(context.Context, *types.Issue, string) error
	// CreateWisp seeds an ephemeral issue in the wisps plane. It is a separate
	// field rather than an Ephemeral flag on CreateIssue because the three
	// adapters reach the two planes through different verbs.
	CreateWisp func(context.Context, *types.Issue, string) error
	// QueryScalar runs a single-row query and scans it. It is how these cases
	// observe whether the rows are really gone.
	QueryScalar func(context.Context, string, []any, ...any) error
	// CountHistory reports how many history entries the fixture's branch has.
	// A nil hook means "this backend cannot observe history", and the case
	// that needs it SKIPS with that reason rather than passing quietly.
	CountHistory func(context.Context) (int, error)
	// CommitPending puts everything written so far into the version history,
	// so a later CountHistory delta measures the call under test and nothing
	// that led up to it.
	//
	// IT IS A PRECONDITION OF THE HISTORY CASE, NOT A CONVENIENCE. Sweeping
	// rows that never reached the history is not a change AGAINST the history:
	// the working set returns to the state HEAD is already at, every backend's
	// commit finds an empty diff, and none of them records an entry. Two of
	// the three kits happen to version each seed as a side effect of writing
	// it and one does not, so without this hook the same case measures a
	// versioned sweep on two legs and an unversioned one on the third — and on
	// that third leg it also depends on which OTHER subtests ran first,
	// because their uncommitted seeds are what keep the working set dirty.
	//
	// A nil hook means the backend cannot settle its history on demand, and
	// the case that needs it SKIPS with that reason rather than passing
	// quietly.
	CommitPending func(context.Context) error
	// AddComment attaches a comment to an issue OR a wisp. It is filled from
	// the backend's Commenter role, which resolves the plane itself, so a case
	// can cite a candidate from a wisp's comment without knowing how that
	// backend reaches wisp_comments.
	AddComment func(ctx context.Context, issueID, author, text string) error
	// Exec runs a raw seeding script, the same hook shape the cycle-detector
	// kit uses. The tier-boundary case needs it to manufacture the LEGACY
	// typed-wisp row (issues plane, wisp_type set, ephemeral 0) that no
	// current create path can mint — every one of them now infers ephemeral
	// from wisp_type, which is exactly why the legacy rows have to be built
	// by hand. A nil Exec means "this backend cannot seed raw rows", and the
	// case that needs it SKIPS with that reason rather than passing quietly.
	Exec func(ctx context.Context, statements []SQLStatement) error
	// AddDependencies wires edges between seeded rows, filled from the
	// backend's DependencyEditor role so each adapter routes an edge to the
	// dependency table of its source's plane itself. The live-dependent case
	// needs it; a nil hook SKIPS that case with the reason.
	AddDependencies func(ctx context.Context, req publicops.AddDependenciesRequest) error
}

// sweeperClosedAt is the stamp every seeded candidate carries, and
// sweeperCutoff is an instant strictly after it. Fixed rather than offsets from
// time.Now so the cutoff cases do not race the clock.
var (
	sweeperClosedAt = time.Date(2026, 3, 1, 12, 0, 0, 0, time.UTC)
	sweeperCutoff   = time.Date(2026, 4, 1, 12, 0, 0, 0, time.UTC)
)

// RunSweeperRefusesAnUnfilteredDurableSweep pins the safety invariant the role
// took off the CLI (issueops/sweeper.go:59-73): a durable sweep with neither a
// cutoff nor a pattern is ErrValidation, asserted at the role rather than at a
// handler so a second front door inherits it.
//
// It asserts the refusal AND its effect: a guard that returned an error after
// deleting would satisfy an errors.Is assertion perfectly.
func RunSweeperRefusesAnUnfilteredDurableSweep(t *testing.T, ctx context.Context, fixture SweeperFixture) {
	t.Helper()
	id := sweeperSeedClosedIssue(t, ctx, fixture, "gate", false)

	result, err := fixture.Sweeper.Sweep(ctx, publicops.SweepRequest{Tier: publicops.SweepDurable})
	if !errors.Is(err, publicops.ErrValidation) {
		t.Fatalf("Sweep(durable, no cutoff, no pattern) error = %v, want ErrValidation: "+
			"the require-a-filter guard is a safety invariant of the ROLE, so a second front door inherits it", err)
	}
	if result.Swept != 0 {
		t.Errorf("refused sweep reported Swept = %d, want 0", result.Swept)
	}
	sweeperAssertIssueRows(t, ctx, fixture, 1, id)

	// The ephemeral tier carries no such gate: an unfiltered sweep of closed
	// wisps is the ordinary use of `bd purge`. Asked with a pattern that matches
	// nothing so the case does not clear another case's seeds.
	if _, err := fixture.Sweeper.Sweep(ctx, publicops.SweepRequest{
		Tier:      publicops.SweepEphemeral,
		IDPattern: fixture.IssuePrefix + "-gate-nothing-*",
	}); err != nil {
		t.Fatalf("Sweep(ephemeral) error = %v, want nil: the gate is the durable tier's, not every tier's", err)
	}
}

// RunSweeperRefusesAMalformedRequest pins the other two ErrValidation clauses
// (issueops/sweeper.go): an unset or unrecognized Tier, and an IDPattern that
// is not a well-formed glob.
//
// The pattern case is a DEFECT FIX: both front doors used to discard
// filepath.Match's error, so `--pattern '['` reported "nothing to prune",
// indistinguishable from a correct pattern over an empty set.
func RunSweeperRefusesAMalformedRequest(t *testing.T, ctx context.Context, fixture SweeperFixture) {
	t.Helper()
	for _, test := range []struct {
		name    string
		request publicops.SweepRequest
	}{
		{"unset tier", publicops.SweepRequest{IDPattern: "*"}},
		{"unrecognized tier", publicops.SweepRequest{Tier: publicops.SweepTier("wisps"), IDPattern: "*"}},
		{"malformed pattern", publicops.SweepRequest{Tier: publicops.SweepDurable, IDPattern: "[bad"}},
	} {
		t.Run(test.name, func(t *testing.T) {
			if _, err := fixture.Sweeper.Sweep(ctx, test.request); !errors.Is(err, publicops.ErrValidation) {
				t.Fatalf("Sweep(%s) error = %v, want ErrValidation", test.name, err)
			}
		})
	}
}

// RunSweeperClearsOneTierAndLeavesTheOther pins the disjointness that makes
// `bd purge` and `bd prune` ONE capability with a tier parameter
// (issueops/sweeper.go, SweepTier). Both planes are seeded with ids the SAME
// pattern admits, so a body that forgot the tier deletes the wrong rows rather
// than merely reporting a wrong number.
func RunSweeperClearsOneTierAndLeavesTheOther(t *testing.T, ctx context.Context, fixture SweeperFixture) {
	t.Helper()
	issueID := sweeperSeedClosedIssue(t, ctx, fixture, "tier", false)
	wispID := sweeperSeedClosedIssue(t, ctx, fixture, "tier", true)

	result := sweeperSweep(t, ctx, fixture, publicops.SweepRequest{
		Tier:      publicops.SweepDurable,
		IDPattern: sweeperPattern(fixture, "tier"),
	})
	if result.Swept != 1 {
		t.Fatalf("durable sweep reported Swept = %d, want 1", result.Swept)
	}
	sweeperAssertIssueRows(t, ctx, fixture, 0, issueID)
	sweeperAssertWispRows(t, ctx, fixture, 1, wispID)

	result = sweeperSweep(t, ctx, fixture, publicops.SweepRequest{
		Tier:      publicops.SweepEphemeral,
		IDPattern: sweeperPattern(fixture, "tier"),
	})
	if result.Swept != 1 {
		t.Fatalf("ephemeral sweep reported Swept = %d, want 1", result.Swept)
	}
	sweeperAssertWispRows(t, ctx, fixture, 0, wispID)
}

// RunSweeperTreatsALegacyTypedWispAsEphemeralTier pins the tier boundary on
// the row shape that motivated it: a closed row in the ISSUES plane carrying a
// wisp_type but not the ephemeral flag — the shape older creators minted, 858
// of which survived every purge in one production DB because the candidate
// filter matched the flag alone (and the flag's search route never left the
// wisps plane).
//
// The ephemeral sweep must take it; the durable sweep must not — a typed wisp
// is ephemeral-tier however it was minted. The durable sibling proves the
// boundary moved rather than collapsed into "purge takes everything".
//
// The legacy shape is manufactured with a raw UPDATE because every current
// create path infers ephemeral from wisp_type; the rows this case guards were
// minted before the inference existed.
func RunSweeperTreatsALegacyTypedWispAsEphemeralTier(t *testing.T, ctx context.Context, fixture SweeperFixture) {
	t.Helper()
	if fixture.Exec == nil {
		t.Skip("backend cannot seed raw rows (no Exec hook)")
	}
	legacy := sweeperSeed(t, ctx, fixture, sweeperIssue(fixture, "legacywisp", "typed", false), nil)
	durable := sweeperSeed(t, ctx, fixture, sweeperIssue(fixture, "legacywisp", "plain", false), nil)
	if err := fixture.Exec(ctx, []SQLStatement{{
		Query: "UPDATE issues SET wisp_type = 'patrol' WHERE id = ?",
		Args:  []any{legacy},
	}}); err != nil {
		t.Fatalf("manufacturing the legacy typed-wisp shape: %v", err)
	}

	result := sweeperSweep(t, ctx, fixture, publicops.SweepRequest{
		Tier:      publicops.SweepEphemeral,
		IDPattern: sweeperPattern(fixture, "legacywisp"),
	})
	if result.Swept != 1 {
		t.Fatalf("ephemeral sweep Swept = %d, want 1 (the legacy typed wisp)", result.Swept)
	}
	sweeperAssertIssueRows(t, ctx, fixture, 0, legacy)
	sweeperAssertIssueRows(t, ctx, fixture, 1, durable)

	result = sweeperSweep(t, ctx, fixture, publicops.SweepRequest{
		Tier:      publicops.SweepDurable,
		IDPattern: sweeperPattern(fixture, "legacywisp"),
	})
	if result.Swept != 1 {
		t.Fatalf("durable sweep Swept = %d, want 1 (the plain closed issue)", result.Swept)
	}
	sweeperAssertIssueRows(t, ctx, fixture, 0, durable)
}

// RunSweeperLeavesNoHistoryBeadsToTheDurableTier pins the other edge of the
// same boundary: a NoHistory bead lives in the WISPS plane with ephemeral=0
// and no wisp_type, and it is durable-tier (GH#3649) — widening the ephemeral
// tier to typed wisps must not sweep it up.
func RunSweeperLeavesNoHistoryBeadsToTheDurableTier(t *testing.T, ctx context.Context, fixture SweeperFixture) {
	t.Helper()
	// Seeded through CreateWisp, not CreateIssue: putting a NoHistory bead in
	// the wisps plane is the CREATE verb's routing, and not every fixture's
	// CreateIssue goes through that verb (the uow kit calls the domain-level
	// create, which takes the plane as an argument). The sweeper contract
	// needs the row SHAPE in the wisps plane, however a backend gets it there.
	noHistory := sweeperIssue(fixture, "nohist", "keep", false)
	noHistory.NoHistory = true
	if err := fixture.CreateWisp(ctx, noHistory, "sweeper-seed"); err != nil {
		t.Fatalf("seeding %s: %v", noHistory.ID, err)
	}

	result := sweeperSweep(t, ctx, fixture, publicops.SweepRequest{
		Tier:      publicops.SweepEphemeral,
		IDPattern: sweeperPattern(fixture, "nohist"),
	})
	if result.Swept != 0 {
		t.Fatalf("ephemeral sweep Swept = %d, want 0 — a NoHistory bead is durable-tier", result.Swept)
	}
	sweeperAssertWispRows(t, ctx, fixture, 1, noHistory.ID)
}

// RunSweeperProtectsPinnedRows pins the protection no request field overrides
// (issueops.SweepSkips.Pinned): a pinned closed row is held back and counted,
// and the sweep still clears everything beside it.
func RunSweeperProtectsPinnedRows(t *testing.T, ctx context.Context, fixture SweeperFixture) {
	t.Helper()
	plain := sweeperSeedClosedIssue(t, ctx, fixture, "pin", false)
	pinned := sweeperSeed(t, ctx, fixture, sweeperIssue(fixture, "pin", "keep", false), func(issue *types.Issue) {
		issue.Pinned = true
	})

	result := sweeperSweep(t, ctx, fixture, publicops.SweepRequest{
		Tier:      publicops.SweepDurable,
		IDPattern: sweeperPattern(fixture, "pin"),
	})

	if result.Swept != 1 {
		t.Errorf("Swept = %d, want 1 — the pinned row must not be one of them", result.Swept)
	}
	if result.Skipped.Pinned != 1 {
		t.Errorf("Skipped.Pinned = %d, want 1", result.Skipped.Pinned)
	}
	sweeperAssertIssueRows(t, ctx, fixture, 0, plain)
	sweeperAssertIssueRows(t, ctx, fixture, 1, pinned)
}

// RunSweeperHonorsTheCutoffAndThePattern pins the two narrowing fields.
//
// The CUTOFF is HALF-OPEN: a row closed exactly at the cutoff is KEPT
// (issueops.SweepRequest.ClosedBefore, "strictly before"). An off-by-one there
// deletes a bead closed the instant a scheduled sweep names.
//
// The PATTERN is matched in Go rather than translated to SQL, so the case
// includes a character class — the construct a LIKE translation would get
// wrong, on the operation where getting it wrong deletes rows.
func RunSweeperHonorsTheCutoffAndThePattern(t *testing.T, ctx context.Context, fixture SweeperFixture) {
	t.Helper()
	old := sweeperSeed(t, ctx, fixture, sweeperIssue(fixture, "when", "old", false), nil)
	atCutoff := sweeperSeed(t, ctx, fixture, sweeperIssue(fixture, "when", "edge", false), func(issue *types.Issue) {
		at := sweeperCutoff
		issue.ClosedAt = &at
	})

	cutoff := sweeperCutoff
	result := sweeperSweep(t, ctx, fixture, publicops.SweepRequest{
		Tier:         publicops.SweepDurable,
		ClosedBefore: &cutoff,
		IDPattern:    sweeperPattern(fixture, "when"),
	})
	if result.Swept != 1 {
		t.Errorf("Swept = %d, want 1 — ClosedBefore is strictly before, so the row closed AT the cutoff stays", result.Swept)
	}
	sweeperAssertIssueRows(t, ctx, fixture, 0, old)
	sweeperAssertIssueRows(t, ctx, fixture, 1, atCutoff)

	// A character class, and a row the class excludes.
	inClass := sweeperSeed(t, ctx, fixture, sweeperIssue(fixture, "glob", "a1", false), nil)
	outOfClass := sweeperSeed(t, ctx, fixture, sweeperIssue(fixture, "glob", "z9", false), nil)
	result = sweeperSweep(t, ctx, fixture, publicops.SweepRequest{
		Tier:      publicops.SweepDurable,
		IDPattern: fixture.IssuePrefix + "-glob-[a-c]*",
	})
	if result.Swept != 1 {
		t.Errorf("Swept = %d, want 1 for the character-class pattern", result.Swept)
	}
	sweeperAssertIssueRows(t, ctx, fixture, 0, inClass)
	sweeperAssertIssueRows(t, ctx, fixture, 1, outOfClass)
}

// RunSweeperDryRunChangesNothing pins issueops.Sweeper.Sweep's "A DRY RUN
// CHANGES NOTHING": the preview reports the same counts the real sweep goes on
// to report, and leaves every row where it was. The two are compared against
// EACH OTHER rather than against a literal, because that is the property a
// caller relies on.
func RunSweeperDryRunChangesNothing(t *testing.T, ctx context.Context, fixture SweeperFixture) {
	t.Helper()
	ids := []string{
		sweeperSeed(t, ctx, fixture, sweeperIssue(fixture, "dry", "1", false), nil),
		sweeperSeed(t, ctx, fixture, sweeperIssue(fixture, "dry", "2", false), nil),
	}
	request := publicops.SweepRequest{
		Tier:      publicops.SweepDurable,
		IDPattern: sweeperPattern(fixture, "dry"),
	}

	preview := sweeperSweep(t, ctx, fixture, sweeperAsDryRun(request))
	if !preview.DryRun {
		t.Error("preview.DryRun = false; the result must echo the request it answered")
	}
	if preview.Swept != 2 {
		t.Fatalf("preview Swept = %d, want 2", preview.Swept)
	}
	sweeperAssertIssueRows(t, ctx, fixture, 2, ids...)

	// A second preview: a dry run that had deleted anything reports a smaller
	// number here.
	if again := sweeperSweep(t, ctx, fixture, sweeperAsDryRun(request)); again.Swept != preview.Swept {
		t.Fatalf("second preview Swept = %d, first = %d: the first preview changed the store", again.Swept, preview.Swept)
	}

	real := sweeperSweep(t, ctx, fixture, request)
	if real.Swept != preview.Swept {
		t.Errorf("real Swept = %d, preview said %d: a preview that disagrees with its run is worse than none",
			real.Swept, preview.Swept)
	}
	if real.DryRun {
		t.Error("real.DryRun = true")
	}
	sweeperAssertIssueRows(t, ctx, fixture, 0, ids...)
}

// RunSweeperProtectsRowsCitedFromAWispComment is the quadrant the protection
// scan was blind in.
//
// ProtectReferenced promises the scan covers every not-done row's description,
// notes AND comments, and the not-done set spans both planes. Three of those
// four combinations had cases; a citation living in a comment on an open WISP
// had none, and the two bodies read comments through different code — the
// store-backed one partitions between `comments` and `wisp_comments`, the
// unit-of-work one went through a use case that reads the durable table only.
// So `bd prune` deleted the cited bead on one route and kept it on the other,
// with all three legs green.
//
// The citation is the row's ONLY one, and it is on a wisp that is OPEN, so
// nothing but a both-planes comment scan can protect it.
func RunSweeperProtectsRowsCitedFromAWispComment(t *testing.T, ctx context.Context, fixture SweeperFixture) {
	t.Helper()
	if fixture.AddComment == nil {
		t.Skip("fixture cannot attach comments")
	}
	cited := sweeperSeed(t, ctx, fixture, sweeperIssue(fixture, "wcx", "cited", false), nil)

	witness := sweeperIssue(fixture, "wcx", "live", true)
	witness.Status = types.StatusOpen
	witness.ClosedAt = nil
	witnessID := sweeperSeedOpen(t, ctx, fixture, witness)
	if err := fixture.AddComment(ctx, witnessID, "sweeper-seed",
		fmt.Sprintf("decision trail: see %s", cited)); err != nil {
		t.Fatalf("commenting on the wisp: %v", err)
	}

	request := publicops.SweepRequest{
		Tier:              publicops.SweepDurable,
		IDPattern:         sweeperPattern(fixture, "wcx"),
		ProtectReferenced: true,
	}
	result := sweeperSweep(t, ctx, fixture, request)

	if result.Skipped.Referenced != 1 {
		t.Errorf("Skipped.Referenced = %d, want 1: the only citation of %s is a comment on an open wisp",
			result.Skipped.Referenced, cited)
	}
	if result.Swept != 0 {
		t.Errorf("Swept = %d, want 0", result.Swept)
	}
	sweeperAssertIssueRows(t, ctx, fixture, 1, cited)

	// And the same request without the protection deletes it, so the case
	// cannot pass for an implementation that skipped every candidate.
	request.ProtectReferenced = false
	unprotected := sweeperSweep(t, ctx, fixture, request)
	if unprotected.Swept != 1 {
		t.Errorf("unprotected Swept = %d, want 1", unprotected.Swept)
	}
	sweeperAssertIssueRows(t, ctx, fixture, 0, cited)
}

// RunSweeperProtectsCitedRows pins ProtectReferenced
// (issueops.SweepRequest.ProtectReferenced): a candidate whose id appears in a
// not-done bead's description is held back, counted, and named in the bounded
// sample — and the SAME request without the protection deletes it.
//
// The two halves matter together: asserting only the protection would pass for
// an implementation that skipped every candidate, and asserting only the
// unprotected sweep would pass for one that never scanned at all. The citation
// is at a WORD BOUNDARY with a near-miss beside it, so an implementation that
// fell back to a bare substring search protects a row nothing cites.
func RunSweeperProtectsCitedRows(t *testing.T, ctx context.Context, fixture SweeperFixture) {
	t.Helper()
	cited := sweeperSeed(t, ctx, fixture, sweeperIssue(fixture, "ref", "cited", false), nil)
	free := sweeperSeed(t, ctx, fixture, sweeperIssue(fixture, "ref", "free", false), nil)

	citing := sweeperIssue(fixture, "ref", "live", false)
	citing.Status = types.StatusOpen
	citing.ClosedAt = nil
	// The near-miss `<free>x` must NOT protect anything; the parenthesised
	// occurrence must.
	citing.Description = fmt.Sprintf("superseded by (%s). unrelated: %sx", cited, free)
	// The citing bead is OPEN, so the pattern below must not admit it as a
	// candidate: the closed recheck would skip it either way, but a case relying
	// on that would be asserting the wrong protection.
	sweeperSeedOpen(t, ctx, fixture, citing)

	request := publicops.SweepRequest{
		Tier:              publicops.SweepDurable,
		IDPattern:         sweeperPattern(fixture, "ref"),
		ProtectReferenced: true,
	}
	result := sweeperSweep(t, ctx, fixture, request)

	if result.Skipped.Referenced != 1 {
		t.Fatalf("Skipped.Referenced = %d, want 1 (sample %v)", result.Skipped.Referenced, result.ReferencedIDs)
	}
	if len(result.ReferencedIDs) != 1 || result.ReferencedIDs[0] != cited {
		t.Errorf("ReferencedIDs = %v, want [%s]", result.ReferencedIDs, cited)
	}
	if result.Swept != 1 {
		t.Errorf("Swept = %d, want 1 — the uncited candidate goes", result.Swept)
	}
	sweeperAssertIssueRows(t, ctx, fixture, 1, cited)
	sweeperAssertIssueRows(t, ctx, fixture, 0, free)

	// Without the protection the same candidate goes, and nothing is reported
	// as protected — a caller reading Referenced=0 without having asked has
	// learned nothing.
	request.ProtectReferenced = false
	result = sweeperSweep(t, ctx, fixture, request)
	if result.Skipped.Referenced != 0 {
		t.Errorf("Skipped.Referenced = %d with ProtectReferenced false, want 0", result.Skipped.Referenced)
	}
	if result.Swept != 1 {
		t.Errorf("Swept = %d, want 1 — the cited candidate is no longer protected", result.Swept)
	}
	sweeperAssertIssueRows(t, ctx, fixture, 0, cited)
}

// RunSweeperEmptyMatchIsZeroAndNil pins the not-found story
// (issueops.Sweeper.Sweep, "A REQUEST THAT MATCHES NOTHING"): a zero result and
// a nil error.
func RunSweeperEmptyMatchIsZeroAndNil(t *testing.T, ctx context.Context, fixture SweeperFixture) {
	t.Helper()
	for _, tier := range []publicops.SweepTier{publicops.SweepDurable, publicops.SweepEphemeral} {
		t.Run(string(tier), func(t *testing.T) {
			result, err := fixture.Sweeper.Sweep(ctx, publicops.SweepRequest{
				Tier:      tier,
				IDPattern: fixture.IssuePrefix + "-none-ever-*",
			})
			if err != nil {
				t.Fatalf("Sweep(nothing matches) error = %v, want nil", err)
			}
			if result.Swept != 0 {
				t.Errorf("Swept = %d, want 0", result.Swept)
			}
			if len(result.ReferencedIDs) != 0 {
				t.Errorf("ReferencedIDs = %v, want empty", result.ReferencedIDs)
			}
		})
	}
}

// RunSweeperRecordsExactlyOneHistoryEntry pins the versioning clause
// (issueops.Sweeper.Sweep, "A DRY RUN CHANGES NOTHING, including history"): a
// dry run and a no-op record NONE, and a sweep that deleted durable rows
// records EXACTLY ONE — the deletion is one act, not none and not one per row.
//
// The two zeros and the one are all exact. The range this case used to assert
// on the last half absorbed a real split — the embedded store minted no Dolt
// commit for a sweep at all — and passed either way; a lower bound that cannot
// fail pins nothing. The zeros were always exact and stay that way: they are
// what makes a preview a preview.
//
// AN EPHEMERAL SWEEP IS DELIBERATELY NOT THIS CASE'S SUBJECT. It touches only
// tables the version-control plane ignores, so every wiring records none for
// it — a uniform property of dolt_ignore rather than of the role.
//
// THE ENTRY IS NOT PROMISED TO BE CRASH-ATOMIC WITH THE SWEEP. The
// server-backed store writes it inside the write transaction; the embedded one
// writes it after its SQL commit, on a second connection, so a crash in that
// window leaves the rows swept and the entry unwritten until the next flush.
// What all three wirings promise, and what this case reads, is the steady
// state one returned call leaves behind.
//
// THE SEEDS ARE SETTLED INTO THE HISTORY BEFORE ANYTHING IS MEASURED; see
// SweeperFixture.CommitPending for why sweeping unversioned rows records
// nothing anywhere.
func RunSweeperRecordsExactlyOneHistoryEntry(t *testing.T, ctx context.Context, fixture SweeperFixture) {
	t.Helper()
	if fixture.CountHistory == nil {
		t.Skip("this backend cannot observe history, so the entry-per-call clause is unobservable here")
	}
	if fixture.CommitPending == nil {
		t.Skip("this backend cannot settle its history on demand, so a sweep of these seeds is not a change against the history and the clause is unobservable here")
	}
	ids := []string{
		sweeperSeed(t, ctx, fixture, sweeperIssue(fixture, "hist", "1", false), nil),
		sweeperSeed(t, ctx, fixture, sweeperIssue(fixture, "hist", "2", false), nil),
	}
	request := publicops.SweepRequest{
		Tier:      publicops.SweepDurable,
		IDPattern: sweeperPattern(fixture, "hist"),
	}
	if err := fixture.CommitPending(ctx); err != nil {
		t.Fatalf("CommitPending() after seeding: %v", err)
	}

	before := sweeperHistory(t, ctx, fixture)
	sweeperSweep(t, ctx, fixture, sweeperAsDryRun(request))
	if after := sweeperHistory(t, ctx, fixture); after != before {
		t.Errorf("history went %d -> %d across a DRY RUN, want no entry at all", before, after)
	}

	before = sweeperHistory(t, ctx, fixture)
	sweeperSweep(t, ctx, fixture, publicops.SweepRequest{
		Tier:      publicops.SweepDurable,
		IDPattern: fixture.IssuePrefix + "-hist-nothing-*",
	})
	if after := sweeperHistory(t, ctx, fixture); after != before {
		t.Errorf("history went %d -> %d across a sweep that deleted nothing, want no entry", before, after)
	}

	before = sweeperHistory(t, ctx, fixture)
	sweeperSweep(t, ctx, fixture, request)
	after := sweeperHistory(t, ctx, fixture)
	if after != before+1 {
		t.Errorf("history went %d -> %d across one sweep of %d rows, want exactly one more entry",
			before, after, len(ids))
	}
}

// RunSweeperDoesNotMutateTheCallerRequest pins the no-mutation promise
// (issueops.SweepRequest: "Implementations never mutate caller-owned request
// values"). ClosedBefore is the pointer that would otherwise be written
// through, and a normalization step is exactly the kind of edit that does it.
func RunSweeperDoesNotMutateTheCallerRequest(t *testing.T, ctx context.Context, fixture SweeperFixture) {
	t.Helper()
	cutoff := sweeperCutoff
	request := publicops.SweepRequest{
		Tier:              publicops.SweepDurable,
		Actor:             "sweeper-contract",
		ClosedBefore:      &cutoff,
		IDPattern:         sweeperPattern(fixture, "immutable"),
		ProtectReferenced: true,
		DryRun:            true,
	}
	snapshot := request
	snapshotCutoff := cutoff

	if _, err := fixture.Sweeper.Sweep(ctx, request); err != nil {
		t.Fatalf("Sweep() error = %v", err)
	}

	if !reflect.DeepEqual(request, snapshot) {
		t.Errorf("request changed across the call: got %+v, want %+v", request, snapshot)
	}
	if !cutoff.Equal(snapshotCutoff) {
		t.Errorf("the caller's cutoff changed: got %v, want %v", cutoff, snapshotCutoff)
	}
}

// RunSweeperWispsPlaneClearsTheWholeWispsTable pins issueops.SweepWispsPlane:
// the selection is the wisps TABLE, so a closed no-history bead — durable-tier,
// and left alone by SweepEphemeral (RunSweeperLeavesNoHistoryBeadsToTheDurableTier)
// — goes with the closed ephemeral wisp, while a closed issues-plane row the
// same pattern admits stays.
func RunSweeperWispsPlaneClearsTheWholeWispsTable(t *testing.T, ctx context.Context, fixture SweeperFixture) {
	t.Helper()
	wisp := sweeperSeedClosedIssue(t, ctx, fixture, "plane", true)
	durable := sweeperSeedClosedIssue(t, ctx, fixture, "plane", false)
	noHistory := sweeperIssue(fixture, "plane", "nohist", false)
	noHistory.NoHistory = true
	if err := fixture.CreateWisp(ctx, noHistory, "sweeper-seed"); err != nil {
		t.Fatalf("seeding %s: %v", noHistory.ID, err)
	}
	pinned := sweeperSeed(t, ctx, fixture, sweeperIssue(fixture, "plane", "pinned", true), func(issue *types.Issue) {
		issue.Pinned = true
	})

	request := publicops.SweepRequest{
		Tier:         publicops.SweepWispsPlane,
		IDPattern:    sweeperPattern(fixture, "plane"),
		ClosedBefore: &sweeperCutoff,
	}
	preview := sweeperSweep(t, ctx, fixture, sweeperAsDryRun(request))
	if preview.Swept != 2 {
		t.Fatalf("dry-run Swept = %d, want 2 (the ephemeral wisp and the no-history bead)", preview.Swept)
	}
	sweeperAssertWispRows(t, ctx, fixture, 3, wisp, noHistory.ID, pinned)

	result := sweeperSweep(t, ctx, fixture, request)
	if result.Swept != 2 {
		t.Errorf("Swept = %d, want 2 (the ephemeral wisp and the no-history bead)", result.Swept)
	}
	if result.Skipped.Pinned != 1 {
		t.Errorf("Skipped.Pinned = %d, want 1 — the plane selector does not override pinning", result.Skipped.Pinned)
	}
	sweeperAssertWispRows(t, ctx, fixture, 0, wisp, noHistory.ID)
	sweeperAssertWispRows(t, ctx, fixture, 1, pinned)
	sweeperAssertIssueRows(t, ctx, fixture, 1, durable)
}

// RunSweeperWispsPlaneRequiresAFilter pins that the wisps-plane tier carries
// the durable tier's require-a-filter gate: it reaches no-history beads, which
// are durable-tier. The refusal is asserted with its effect, as the durable
// case does.
func RunSweeperWispsPlaneRequiresAFilter(t *testing.T, ctx context.Context, fixture SweeperFixture) {
	t.Helper()
	id := sweeperSeedClosedIssue(t, ctx, fixture, "planegate", true)

	result, err := fixture.Sweeper.Sweep(ctx, publicops.SweepRequest{Tier: publicops.SweepWispsPlane})
	if !errors.Is(err, publicops.ErrValidation) {
		t.Fatalf("Sweep(wisps-plane, no cutoff, no pattern) error = %v, want ErrValidation", err)
	}
	if result.Swept != 0 {
		t.Errorf("refused sweep reported Swept = %d, want 0", result.Swept)
	}
	sweeperAssertWispRows(t, ctx, fixture, 1, id)
}

// RunSweeperProtectsLiveDependents pins issueops.SweepRequest.ProtectLiveDependents:
// a closed row a LIVE row depends on through parent-child, tracks or blocks is
// held back and counted, while a closed row reached only by a non-structural
// edge, or only by a dependent that is itself closed, is swept.
//
// The live sources carry three different not-done statuses (open,
// in_progress, hooked), because "live" is the not-done set and not "open".
// It runs on the wisps-plane tier with a cutoff — the request an
// orchestrator's retention sweep sends — after proving on a dry run that the
// same rows ARE candidates without the protection.
func RunSweeperProtectsLiveDependents(t *testing.T, ctx context.Context, fixture SweeperFixture) {
	t.Helper()
	if fixture.AddDependencies == nil {
		t.Skip("fixture has no AddDependencies hook; cannot wire the edges this case needs")
	}
	live := func(name string, status types.Status) string {
		issue := sweeperIssue(fixture, "live", name, true)
		issue.Status = status
		issue.ClosedAt = nil
		return sweeperSeed(t, ctx, fixture, issue, nil)
	}
	closed := func(name string) string {
		return sweeperSeed(t, ctx, fixture, sweeperIssue(fixture, "live", name, true), nil)
	}

	parent := closed("parent")
	openChild := live("child-open", types.StatusOpen)
	tracked := closed("tracked")
	convoy := live("convoy", types.StatusInProgress)
	blocker := closed("blocker")
	hooked := live("hooked", types.StatusHooked)
	related := closed("related")
	relater := live("relater", types.StatusOpen)
	doneParent := closed("done-parent")
	doneChild := closed("done-child")

	if err := fixture.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "sweeper-seed",
		Edges: []publicops.DependencyEdge{
			{IssueID: openChild, DependsOnID: parent, Type: publicops.DepParentChild},
			{IssueID: convoy, DependsOnID: tracked, Type: publicops.DepTracks},
			{IssueID: hooked, DependsOnID: blocker, Type: publicops.DepBlocks},
			{IssueID: relater, DependsOnID: related, Type: publicops.DepRelated},
			{IssueID: doneChild, DependsOnID: doneParent, Type: publicops.DepParentChild},
		},
	}); err != nil {
		t.Fatalf("wiring dependencies: %v", err)
	}

	request := publicops.SweepRequest{
		Tier:         publicops.SweepWispsPlane,
		IDPattern:    sweeperPattern(fixture, "live"),
		ClosedBefore: &sweeperCutoff,
	}
	unprotected := sweeperSweep(t, ctx, fixture, sweeperAsDryRun(request))
	if unprotected.Swept != 6 || unprotected.Skipped.LiveDependent != 0 {
		t.Fatalf("unprotected dry run: Swept = %d, LiveDependent = %d; want 6 and 0 — "+
			"the protection must be asked for", unprotected.Swept, unprotected.Skipped.LiveDependent)
	}

	request.ProtectLiveDependents = true
	result := sweeperSweep(t, ctx, fixture, request)
	if result.Skipped.LiveDependent != 3 {
		t.Errorf("Skipped.LiveDependent = %d, want 3 (the parent, the tracked bead and the blocker)",
			result.Skipped.LiveDependent)
	}
	if result.Swept != 3 {
		t.Errorf("Swept = %d, want 3 (the related-only bead and the closed parent/child pair)", result.Swept)
	}
	sweeperAssertWispRows(t, ctx, fixture, 3, parent, tracked, blocker)
	sweeperAssertWispRows(t, ctx, fixture, 0, related, doneParent, doneChild)
	sweeperAssertWispRows(t, ctx, fixture, 4, openChild, convoy, hooked, relater)
}

// RunSweeperProtectsTransitiveLiveDependents pins that protection propagates
// through closed candidates: an open grandchild keeps both its closed parent
// and closed grandparent. Otherwise sweeping the grandparent orphans a live
// hierarchy even though the direct parent was correctly retained.
func RunSweeperProtectsTransitiveLiveDependents(t *testing.T, ctx context.Context, fixture SweeperFixture) {
	t.Helper()
	if fixture.AddDependencies == nil {
		t.Skip("fixture has no AddDependencies hook; cannot wire the hierarchy this case needs")
	}
	root := sweeperSeed(t, ctx, fixture, sweeperIssue(fixture, "transitive", "root", true), nil)
	middle := sweeperSeed(t, ctx, fixture, sweeperIssue(fixture, "transitive", "middle", true), nil)
	leafIssue := sweeperIssue(fixture, "transitive", "leaf", true)
	leafIssue.Status = types.StatusOpen
	leafIssue.ClosedAt = nil
	leaf := sweeperSeed(t, ctx, fixture, leafIssue, nil)

	if err := fixture.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "sweeper-seed",
		Edges: []publicops.DependencyEdge{
			{IssueID: middle, DependsOnID: root, Type: publicops.DepParentChild},
			{IssueID: leaf, DependsOnID: middle, Type: publicops.DepParentChild},
		},
	}); err != nil {
		t.Fatalf("wiring transitive hierarchy: %v", err)
	}

	request := publicops.SweepRequest{
		Tier:                  publicops.SweepWispsPlane,
		IDPattern:             sweeperPattern(fixture, "transitive"),
		ClosedBefore:          &sweeperCutoff,
		ProtectLiveDependents: true,
	}
	preview := sweeperSweep(t, ctx, fixture, sweeperAsDryRun(request))
	if preview.Swept != 0 || preview.Skipped.LiveDependent != 2 {
		t.Fatalf("dry run: Swept = %d, LiveDependent = %d; want 0 and 2", preview.Swept, preview.Skipped.LiveDependent)
	}
	result := sweeperSweep(t, ctx, fixture, request)
	if result.Swept != 0 || result.Skipped.LiveDependent != 2 {
		t.Fatalf("sweep: Swept = %d, LiveDependent = %d; want 0 and 2", result.Swept, result.Skipped.LiveDependent)
	}
	sweeperAssertWispRows(t, ctx, fixture, 3, root, middle, leaf)
}

// RunSweeperProtectsLiveDependentsAcrossPlanes pins that the live-dependent
// protection reads BOTH dependency tables: a closed wisp that a live DURABLE
// (issues-table) bead depends on through parent-child, tracks or blocks is
// kept, whatever not-done status the durable source carries.
func RunSweeperProtectsLiveDependentsAcrossPlanes(t *testing.T, ctx context.Context, fixture SweeperFixture) {
	t.Helper()
	if fixture.AddDependencies == nil {
		t.Skip("fixture has no AddDependencies hook; cannot wire the edges this case needs")
	}
	durableLive := func(name string, status types.Status) string {
		issue := sweeperIssue(fixture, "xplane", name, false)
		issue.Status = status
		issue.ClosedAt = nil
		return sweeperSeed(t, ctx, fixture, issue, nil)
	}
	closedWisp := func(name string) string {
		return sweeperSeed(t, ctx, fixture, sweeperIssue(fixture, "xplane", name, true), nil)
	}

	parent := closedWisp("parent")
	tracked := closedWisp("tracked")
	blocker := closedWisp("blocker")
	loose := closedWisp("loose")
	child := durableLive("child", types.StatusOpen)
	convoy := durableLive("convoy", types.StatusInProgress)
	waiter := durableLive("waiter", types.StatusDeferred)

	if err := fixture.AddDependencies(ctx, publicops.AddDependenciesRequest{
		Actor: "sweeper-seed",
		Edges: []publicops.DependencyEdge{
			{IssueID: child, DependsOnID: parent, Type: publicops.DepParentChild},
			{IssueID: convoy, DependsOnID: tracked, Type: publicops.DepTracks},
			{IssueID: waiter, DependsOnID: blocker, Type: publicops.DepBlocks},
		},
	}); err != nil {
		t.Fatalf("wiring cross-plane dependencies: %v", err)
	}

	result := sweeperSweep(t, ctx, fixture, publicops.SweepRequest{
		Tier:                  publicops.SweepWispsPlane,
		IDPattern:             sweeperPattern(fixture, "xplane"),
		ClosedBefore:          &sweeperCutoff,
		ProtectLiveDependents: true,
	})
	if result.Skipped.LiveDependent != 3 || result.Swept != 1 {
		t.Errorf("Swept = %d, LiveDependent = %d; want 1 (the unlinked wisp) and 3", result.Swept, result.Skipped.LiveDependent)
	}
	sweeperAssertWispRows(t, ctx, fixture, 3, parent, tracked, blocker)
	sweeperAssertWispRows(t, ctx, fixture, 0, loose)
	sweeperAssertIssueRows(t, ctx, fixture, 3, child, convoy, waiter)
}

// RunSweeperLimitTakesTheOldestClosedFirst pins issueops.SweepRequest.Limit:
// one call deletes at most Limit rows, oldest closed_at first, and reports the
// rest as Remaining; the next call picks up where it stopped.
func RunSweeperLimitTakesTheOldestClosedFirst(t *testing.T, ctx context.Context, fixture SweeperFixture) {
	t.Helper()
	seed := func(name string, closed time.Time) string {
		return sweeperSeed(t, ctx, fixture, sweeperIssue(fixture, "limit", name, true), func(issue *types.Issue) {
			issue.ClosedAt = &closed
		})
	}
	newest := seed("newest", sweeperClosedAt)
	middle := seed("middle", sweeperClosedAt.Add(-24*time.Hour))
	oldest := seed("oldest", sweeperClosedAt.Add(-48*time.Hour))

	request := publicops.SweepRequest{
		Tier:      publicops.SweepEphemeral,
		IDPattern: sweeperPattern(fixture, "limit"),
		Limit:     2,
	}
	first := sweeperSweep(t, ctx, fixture, request)
	if first.Swept != 2 || first.Remaining != 1 {
		t.Fatalf("first limited sweep: Swept = %d, Remaining = %d; want 2 and 1", first.Swept, first.Remaining)
	}
	sweeperAssertWispRows(t, ctx, fixture, 0, oldest, middle)
	sweeperAssertWispRows(t, ctx, fixture, 1, newest)

	second := sweeperSweep(t, ctx, fixture, request)
	if second.Swept != 1 || second.Remaining != 0 {
		t.Fatalf("second limited sweep: Swept = %d, Remaining = %d; want 1 and 0", second.Swept, second.Remaining)
	}
	sweeperAssertWispRows(t, ctx, fixture, 0, newest)

	if _, err := fixture.Sweeper.Sweep(ctx, publicops.SweepRequest{
		Tier: publicops.SweepEphemeral, IDPattern: sweeperPattern(fixture, "limit"), Limit: -1,
	}); !errors.Is(err, publicops.ErrValidation) {
		t.Fatalf("negative Limit error = %v, want ErrValidation", err)
	}
}

// --- fixture helpers -------------------------------------------------------

// sweeperPattern is the glob that scopes one case's ids: a sweep is asked of a
// whole tier, so every case needs one.
func sweeperPattern(fixture SweeperFixture, tag string) string {
	return fixture.IssuePrefix + "-" + tag + "-*"
}

func sweeperIssue(fixture SweeperFixture, tag, name string, ephemeral bool) *types.Issue {
	closedAt := sweeperClosedAt
	return &types.Issue{
		ID:        fmt.Sprintf("%s-%s-%s", fixture.IssuePrefix, tag, name),
		Title:     tag + " " + name,
		Status:    types.StatusClosed,
		Priority:  2,
		IssueType: types.TypeTask,
		Ephemeral: ephemeral,
		ClosedAt:  &closedAt,
	}
}

// sweeperSeed writes one issue through the plane its Ephemeral flag names and
// returns its id. mutate runs before the write, which is how a case seeds a
// pinned row or moves a closed_at.
func sweeperSeed(t *testing.T, ctx context.Context, fixture SweeperFixture, issue *types.Issue, mutate func(*types.Issue)) string {
	t.Helper()
	if mutate != nil {
		mutate(issue)
	}
	create := fixture.CreateIssue
	if issue.Ephemeral {
		create = fixture.CreateWisp
	}
	if err := create(ctx, issue, "sweeper-seed"); err != nil {
		t.Fatalf("seeding %s: %v", issue.ID, err)
	}
	return issue.ID
}

func sweeperSeedClosedIssue(t *testing.T, ctx context.Context, fixture SweeperFixture, tag string, ephemeral bool) string {
	t.Helper()
	name := "durable"
	if ephemeral {
		name = "wisp"
	}
	return sweeperSeed(t, ctx, fixture, sweeperIssue(fixture, tag, name, ephemeral), nil)
}

func sweeperSeedOpen(t *testing.T, ctx context.Context, fixture SweeperFixture, issue *types.Issue) string {
	t.Helper()
	issue.Status = types.StatusOpen
	issue.ClosedAt = nil
	return sweeperSeed(t, ctx, fixture, issue, nil)
}

func sweeperAsDryRun(request publicops.SweepRequest) publicops.SweepRequest {
	request.DryRun = true
	return request
}

func sweeperSweep(t *testing.T, ctx context.Context, fixture SweeperFixture, request publicops.SweepRequest) publicops.SweepResult {
	t.Helper()
	result, err := fixture.Sweeper.Sweep(ctx, request)
	if err != nil {
		t.Fatalf("Sweep(%+v) error = %v", request, err)
	}
	return result
}

// sweeperAssertIssueRows counts the named ids in the ISSUES plane. It is the
// only assertion in this file that does not trust the result the sweep
// reported about itself.
func sweeperAssertIssueRows(t *testing.T, ctx context.Context, fixture SweeperFixture, want int, ids ...string) {
	t.Helper()
	sweeperAssertRows(t, ctx, fixture, "issues", want, ids...)
}

func sweeperAssertWispRows(t *testing.T, ctx context.Context, fixture SweeperFixture, want int, ids ...string) {
	t.Helper()
	sweeperAssertRows(t, ctx, fixture, "wisps", want, ids...)
}

func sweeperAssertRows(t *testing.T, ctx context.Context, fixture SweeperFixture, table string, want int, ids ...string) {
	t.Helper()
	var got int
	args := make([]any, len(ids))
	placeholders := ""
	for i, id := range ids {
		args[i] = id
		if i > 0 {
			placeholders += ", "
		}
		placeholders += "?"
	}
	query := fmt.Sprintf("SELECT COUNT(*) FROM %s WHERE id IN (%s)", table, placeholders)
	if err := fixture.QueryScalar(ctx, query, args, &got); err != nil {
		t.Fatalf("counting %s rows for %v: %v", table, ids, err)
	}
	if got != want {
		t.Errorf("%s rows for %v = %d, want %d", table, ids, got, want)
	}
}

func sweeperHistory(t *testing.T, ctx context.Context, fixture SweeperFixture) int {
	t.Helper()
	entries, err := fixture.CountHistory(ctx)
	if err != nil {
		t.Fatalf("CountHistory: %v", err)
	}
	return entries
}
