package main

import (
	"os"
	"strings"
	"testing"

	"github.com/steveyegge/beads/internal/config"
)

// TestGetActorWithGit tests the actor resolution fallback chain.
// Priority: --actor flag > BEADS_ACTOR env > BD_ACTOR env (deprecated) > git config user.name > $USER > "unknown"
func TestGetActorWithGit(t *testing.T) {
	// Save original environment and actor variable
	origActor := actor
	origBdActor, bdActorSet := os.LookupEnv("BD_ACTOR")
	origBeadsActor, beadsActorSet := os.LookupEnv("BEADS_ACTOR")
	origUser, userSet := os.LookupEnv("USER")

	// Cleanup after test
	defer func() {
		actor = origActor
		if bdActorSet {
			os.Setenv("BD_ACTOR", origBdActor)
		} else {
			os.Unsetenv("BD_ACTOR")
		}
		if beadsActorSet {
			os.Setenv("BEADS_ACTOR", origBeadsActor)
		} else {
			os.Unsetenv("BEADS_ACTOR")
		}
		if userSet {
			os.Setenv("USER", origUser)
		} else {
			os.Unsetenv("USER")
		}
	}()

	// Helper to get current git user.name (may be empty if not configured)
	getGitUserName := func() string {
		out, err := gitCommand("config", "user.name").Output()
		if err != nil {
			return ""
		}
		return strings.TrimSpace(string(out))
	}

	gitUserName := getGitUserName()

	tests := []struct {
		name        string
		actorFlag   string
		bdActor     string
		beadsActor  string
		user        string
		expected    string
		skipIfNoGit bool // Skip if git user.name is not configured
	}{
		{
			name:       "actor flag takes priority",
			actorFlag:  "flag-actor",
			bdActor:    "bd-actor",
			beadsActor: "beads-actor",
			user:       "system-user",
			expected:   "flag-actor",
		},
		{
			name:       "BEADS_ACTOR takes priority when no flag",
			actorFlag:  "",
			bdActor:    "bd-actor",
			beadsActor: "beads-actor",
			user:       "system-user",
			expected:   "beads-actor",
		},
		{
			name:       "BD_ACTOR used as fallback when no BEADS_ACTOR",
			actorFlag:  "",
			bdActor:    "bd-actor",
			beadsActor: "",
			user:       "system-user",
			expected:   "bd-actor",
		},
		{
			name:        "git config user.name used when no env vars",
			actorFlag:   "",
			bdActor:     "",
			beadsActor:  "",
			user:        "system-user",
			expected:    gitUserName, // Will be git user.name if configured
			skipIfNoGit: true,
		},
		{
			name:       "USER fallback when no git config",
			actorFlag:  "",
			bdActor:    "",
			beadsActor: "",
			user:       "fallback-user",
			expected:   "fallback-user",
			// Note: This test may fail if git user.name is configured
			// We handle this by checking the actual git config in the test
		},
		{
			name:       "unknown as final fallback",
			actorFlag:  "",
			bdActor:    "",
			beadsActor: "",
			user:       "",
			expected:   "unknown",
			// Note: This test may get git user.name instead if configured
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Skip tests that require git user.name to not be configured
			if tt.skipIfNoGit && gitUserName == "" {
				t.Skip("Skipping: git config user.name is not configured")
			}

			// For tests expecting USER or unknown, skip if git user.name is configured
			// because git takes priority over USER
			if (tt.expected == tt.user || tt.expected == "unknown") && gitUserName != "" && tt.bdActor == "" && tt.beadsActor == "" && tt.actorFlag == "" {
				t.Skipf("Skipping: git config user.name (%s) takes priority over expected %s", gitUserName, tt.expected)
			}

			// Set up test environment
			actor = tt.actorFlag

			if tt.bdActor != "" {
				os.Setenv("BD_ACTOR", tt.bdActor)
			} else {
				os.Unsetenv("BD_ACTOR")
			}

			if tt.beadsActor != "" {
				os.Setenv("BEADS_ACTOR", tt.beadsActor)
			} else {
				os.Unsetenv("BEADS_ACTOR")
			}

			if tt.user != "" {
				os.Setenv("USER", tt.user)
			} else {
				os.Unsetenv("USER")
			}

			// Call the function
			result := getActorWithGit()

			// Check result
			if result != tt.expected {
				t.Errorf("getActorWithGit() = %q, want %q", result, tt.expected)
			}
		})
	}
}

// TestResolveConfiguredActor verifies that BEADS_ACTOR (primary override)
// outranks the deprecated BD_ACTOR alias when the --actor flag is not set,
// even though viper's AutomaticEnv binds BD_ACTOR to the "actor" config key
// (GH#4645). This is the resolution the pre-run hooks use to pre-populate the
// global actor before getActorWithGit runs.
func TestResolveConfiguredActor(t *testing.T) {
	origBd, bdSet := os.LookupEnv("BD_ACTOR")
	origBeads, beadsSet := os.LookupEnv("BEADS_ACTOR")
	defer func() {
		if bdSet {
			os.Setenv("BD_ACTOR", origBd)
		} else {
			os.Unsetenv("BD_ACTOR")
		}
		if beadsSet {
			os.Setenv("BEADS_ACTOR", origBeads)
		} else {
			os.Unsetenv("BEADS_ACTOR")
		}
		_ = config.Initialize()
	}()

	t.Run("BEADS_ACTOR outranks BD_ACTOR", func(t *testing.T) {
		os.Setenv("BD_ACTOR", "from-bd-actor")
		os.Setenv("BEADS_ACTOR", "from-beads-actor")
		if err := config.Initialize(); err != nil {
			t.Fatalf("config.Initialize(): %v", err)
		}
		if got := resolveConfiguredActor(); got != "from-beads-actor" {
			t.Errorf("resolveConfiguredActor() = %q, want %q (BEADS_ACTOR must win)", got, "from-beads-actor")
		}
	})

	t.Run("BD_ACTOR used when BEADS_ACTOR unset", func(t *testing.T) {
		os.Unsetenv("BEADS_ACTOR")
		os.Setenv("BD_ACTOR", "from-bd-actor")
		if err := config.Initialize(); err != nil {
			t.Fatalf("config.Initialize(): %v", err)
		}
		if got := resolveConfiguredActor(); got != "from-bd-actor" {
			t.Errorf("resolveConfiguredActor() = %q, want %q (BD_ACTOR fallback)", got, "from-bd-actor")
		}
	})
}

// TestGetActorWithGit_PriorityOrder tests that the priority order is respected
func TestGetActorWithGit_PriorityOrder(t *testing.T) {
	// Save original state
	origActor := actor
	origBdActor, bdActorSet := os.LookupEnv("BD_ACTOR")
	origBeadsActor, beadsActorSet := os.LookupEnv("BEADS_ACTOR")

	defer func() {
		actor = origActor
		if bdActorSet {
			os.Setenv("BD_ACTOR", origBdActor)
		} else {
			os.Unsetenv("BD_ACTOR")
		}
		if beadsActorSet {
			os.Setenv("BEADS_ACTOR", origBeadsActor)
		} else {
			os.Unsetenv("BEADS_ACTOR")
		}
	}()

	// Test: flag > BEADS_ACTOR > BD_ACTOR
	actor = "from-flag"
	os.Setenv("BD_ACTOR", "from-bd-actor")
	os.Setenv("BEADS_ACTOR", "from-beads-actor")

	result := getActorWithGit()
	if result != "from-flag" {
		t.Errorf("Expected flag to take priority, got %q", result)
	}

	// Test: BEADS_ACTOR > BD_ACTOR (no flag)
	actor = ""
	result = getActorWithGit()
	if result != "from-beads-actor" {
		t.Errorf("Expected BEADS_ACTOR to take priority over BD_ACTOR, got %q", result)
	}

	// Test: BD_ACTOR as fallback when BEADS_ACTOR is empty
	os.Unsetenv("BEADS_ACTOR")
	result = getActorWithGit()
	if result != "from-bd-actor" {
		t.Errorf("Expected BD_ACTOR to be used as fallback, got %q", result)
	}
}

// TestDeferredActorGitFallback pins the lazy actor: PersistentPreRunE defers
// the git config user.name fallback, and the first reader resolves it to
// exactly what the former eager getActorWithGit assignment produced.
func TestDeferredActorGitFallback(t *testing.T) {
	origActor, origPending := actor, actorGitFallbackPending
	var origCtxActor string
	if cmdCtx != nil {
		origCtxActor = cmdCtx.Actor
	}
	t.Cleanup(func() {
		actor, actorGitFallbackPending = origActor, origPending
		if cmdCtx != nil {
			cmdCtx.Actor = origCtxActor
		}
	})
	t.Setenv("BEADS_ACTOR", "")
	t.Setenv("BD_ACTOR", "")

	actor = "explicit"
	deferActorGitFallback()
	if actorGitFallbackPending {
		t.Fatal("a configured actor must not defer a git lookup")
	}
	if got := currentActor(); got != "explicit" {
		t.Fatalf("currentActor() = %q, want %q", got, "explicit")
	}

	actor = ""
	want := resolveActorWithGit()
	deferActorGitFallback()
	if !actorGitFallbackPending || actor != "" {
		t.Fatalf("deferral resolved eagerly: pending=%v actor=%q", actorGitFallbackPending, actor)
	}
	if got := currentActor(); got != want {
		t.Fatalf("currentActor() = %q, want eager resolution %q", got, want)
	}
	if actorGitFallbackPending || actor != want {
		t.Fatalf("after first use: pending=%v actor=%q, want resolved %q", actorGitFallbackPending, actor, want)
	}

	actor = ""
	deferActorGitFallback()
	if got := getActorWithGit(); got != want || actorGitFallbackPending || actor != want {
		t.Fatalf("getActorWithGit() = %q (pending=%v actor=%q), want %q resolved into the global", got, actorGitFallbackPending, actor, want)
	}

	actor = ""
	deferActorGitFallback()
	setActor("assigned")
	if got := currentActor(); got != "assigned" {
		t.Fatalf("setActor must cancel a deferred fallback: currentActor() = %q", got)
	}
}
