package main

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"github.com/spf13/cobra"
	"github.com/steveyegge/beads/internal/config"
	"github.com/steveyegge/beads/internal/metrics"
)

var backupCmd = &cobra.Command{
	Use:   "backup",
	Short: "Back up your beads database",
	Long: `Back up your beads database for off-machine recovery.

This is a Dolt-native database backup. It preserves the database state,
including tables, branches, commit history, and working-set data. This is
different from 'bd export', which writes issue records to JSONL for migration
and interoperability.

Commands:
  bd backup init <path>    Set up a backup destination (filesystem or DoltHub)
  bd backup sync           Push to configured backup destination
  bd backup restore [path] Restore from a backup directory
  bd backup remove         Remove backup destination
  bd backup status         Show backup status

DoltHub is recommended for cloud backup:
  bd backup init https://doltremoteapi.dolthub.com/<user>/<repo>
  Set DOLT_REMOTE_USER and DOLT_REMOTE_PASSWORD for authentication.

Auto-backup default:
  When backup.enabled is unset, auto-backup turns ON in embedded mode if a
  git remote exists, and stays OFF in sql-server / shared-server mode. In
  server mode many bd clients share one Dolt server, and each would register
  a server-side backup remote under the same name pointing at its own local
  dir and full-sync the whole database — a self-amplifying storm. To back up
  a shared server, run 'bd backup' explicitly (or set backup.enabled=true and
  coordinate destinations). 'bd config get backup.enabled' shows the effective
  value and its source.

  A proxied-server workspace is server mode too: auto-backup is OFF by
  default and backup.enabled=true opts in. Both the opt-in and the five
  backup verbs above are honored only on a managed-local proxied server —
  one bd started itself; on a Dolt server bd does not own they are refused.`,
	GroupID: "sync",
}

type backupSizeFunc func(context.Context) (bytes int64, available bool, err error)

var backupStatusCmd = newBackupStatusCommand(doltBackupSize)

func newBackupStatusCommand(sizeDatabase backupSizeFunc) *cobra.Command {
	return &cobra.Command{
		Use:           "status",
		Short:         "Show last backup status",
		SilenceUsage:  true,
		SilenceErrors: true,
		RunE: func(cmd *cobra.Command, args []string) error {
			if usesProxiedServer() {
				if err := requireLocalProxiedBackup("backup status"); err != nil {
					return err
				}
			}
			evt := metrics.NewCommandEvent("backup-status")
			defer func() {
				if c := metrics.Global(); c != nil {
					c.CloseEventAndAdd(evt)
				}
			}()

			dir, err := backupDir()
			if err != nil {
				return err
			}

			state, err := loadBackupState(dir)
			if err != nil {
				return err
			}
			databaseSize, sizeAvailable, err := sizeDatabase(cmd.Context())
			if err != nil {
				return HandleErrorRespectJSON("measure database size: %v", err)
			}

			if jsonOutput {
				result := map[string]interface{}{
					"backup":   state,
					"dolt":     showDoltBackupStatusJSON(),
					"size_cap": showSizeCapStatusJSON(dir),
				}
				if sizeAvailable {
					result["database_size"] = showDBSizeJSON(databaseSize)
				}
				data, err := json.MarshalIndent(result, "", "  ")
				if err != nil {
					return err
				}
				fmt.Println(string(data))
				return nil
			}

			hasBackup := state.LastDoltCommit != ""
			hasDolt := false
			if cfg, _ := loadDoltBackupConfig(); cfg != nil {
				hasDolt = true
			}

			if !hasBackup && !hasDolt {
				fmt.Println("No backup has been performed yet.")
				fmt.Println()
				fmt.Println("Setup:")
				fmt.Println("  bd backup init <path>    Set up a backup destination")
				fmt.Println("  bd backup sync           Push to backup destination")
				if sizeAvailable {
					showDBSize(databaseSize)
				}
				return nil
			}

			if hasBackup {
				fmt.Println("Backup:")
				fmt.Printf("  Last backup: %s (%s ago)\n",
					state.Timestamp.Format(time.RFC3339),
					time.Since(state.Timestamp).Round(time.Second))
				fmt.Printf("  Dolt commit: %s\n", state.LastDoltCommit)
			}

			// Show config (effective values with source)
			enabled := isBackupAutoEnabled()
			interval := config.GetDuration("backup.interval")
			enabledNote := ""
			if note := backupAutoStatusNote(enabled); note != "" {
				enabledNote = " (" + note + ")"
			}
			fmt.Printf("\nConfig: enabled=%v%s interval=%s\n",
				enabled, enabledNote, interval)
			showSizeCapStatus(dir)

			// Show Dolt backup info
			showDoltBackupStatus()

			// Show database size when the active backend can measure it locally.
			if sizeAvailable {
				showDBSize(databaseSize)
			}

			return nil
		},
	}
}

func init() {
	backupCmd.AddCommand(backupStatusCmd)
	rootCmd.AddCommand(backupCmd)
}
