//go:build cgo

package main

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/steveyegge/beads/internal/config"
	"github.com/steveyegge/beads/internal/configfile"
)

// snapshotBootstrapEnv saves all BD_/BEADS_-prefixed env vars, clears them,
// and registers a t.Cleanup to restore them. It restores via t.Cleanup
// (rather than returning a function for the caller to defer) because
// t.Cleanup callbacks only start running after the test function's own
// regular defers have all completed. Tests using this helper commonly call
// t.Setenv("BEADS_DIR", ...) / t.Setenv("BEADS_TEST_IGNORE_REPO_CONFIG", ...)
// afterward; t.Setenv captures its "restore to" value at call time, which
// would be the already-wiped (absent) state. If this helper's own
// restoration ran via a caller-deferred function, it would run before those
// t.Setenv cleanups fire and its correct restoration would be clobbered by
// them, permanently leaking the wipe forward into later tests in the same
// binary. Registering via t.Cleanup here instead makes this the
// first-registered (and thus, by t.Cleanup's LIFO order, last-run) cleanup,
// so it always has the final word.
func snapshotBootstrapEnv(t *testing.T) {
	t.Helper()
	saved := make(map[string]string)
	for _, env := range os.Environ() {
		if strings.HasPrefix(env, "BD_") || strings.HasPrefix(env, "BEADS_") {
			parts := strings.SplitN(env, "=", 2)
			key := parts[0]
			saved[key] = os.Getenv(key)
			_ = os.Unsetenv(key)
		}
	}
	t.Cleanup(func() {
		for _, env := range os.Environ() {
			if strings.HasPrefix(env, "BD_") || strings.HasPrefix(env, "BEADS_") {
				parts := strings.SplitN(env, "=", 2)
				_ = os.Unsetenv(parts[0])
			}
		}
		for key, val := range saved {
			_ = os.Setenv(key, val)
		}
	})
}

func TestDetectBootstrapAction_NoneWhenDatabaseExists(t *testing.T) {
	t.Setenv("BEADS_DOLT_DATA_DIR", "")
	t.Setenv("BEADS_DOLT_SHARED_SERVER", "")
	t.Setenv("BEADS_DOLT_SERVER_DATABASE", "")
	t.Setenv("BEADS_DOLT_SERVER_HOST", "")
	t.Setenv("BEADS_DOLT_SERVER_PORT", "")
	tmpDir := t.TempDir()
	beadsDir := filepath.Join(tmpDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0o750); err != nil {
		t.Fatal(err)
	}

	// Create embeddeddolt directory with content so it's detected as existing.
	// Default config uses embedded mode, so the detection logic looks for
	// beadsDir/embeddeddolt (not beadsDir/dolt).
	embeddedDir := filepath.Join(beadsDir, "embeddeddolt")
	if err := os.MkdirAll(filepath.Join(embeddedDir, "beads"), 0o750); err != nil {
		t.Fatal(err)
	}

	// Run from tmpDir so auto-detect doesn't find parent git repo
	oldWd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = os.Chdir(oldWd) }()
	if err := os.Chdir(tmpDir); err != nil {
		t.Fatal(err)
	}

	cfg := configfile.DefaultConfig()
	plan := detectBootstrapAction(beadsDir, cfg)

	if plan.Action != "none" {
		t.Errorf("action = %q, want %q", plan.Action, "none")
	}
	if !plan.HasExisting {
		t.Error("HasExisting = false, want true")
	}
}

func TestDetectBootstrapAction_RestoreWhenBackupExists(t *testing.T) {
	t.Setenv("BEADS_DOLT_DATA_DIR", "")
	t.Setenv("BEADS_DOLT_SERVER_DATABASE", "")
	t.Setenv("BEADS_DOLT_SERVER_HOST", "")
	t.Setenv("BEADS_DOLT_SERVER_PORT", "")
	tmpDir := t.TempDir()
	beadsDir := filepath.Join(tmpDir, ".beads")
	backupDir := filepath.Join(beadsDir, "backup")
	if err := os.MkdirAll(backupDir, 0o750); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(backupDir, "issues.jsonl"), []byte("{}"), 0o644); err != nil {
		t.Fatal(err)
	}

	// Run from tmpDir so auto-detect doesn't find parent git repo
	oldWd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = os.Chdir(oldWd) }()
	if err := os.Chdir(tmpDir); err != nil {
		t.Fatal(err)
	}

	cfg := configfile.DefaultConfig()
	plan := detectBootstrapAction(beadsDir, cfg)

	if plan.Action != "restore" {
		t.Errorf("action = %q, want %q", plan.Action, "restore")
	}
	if plan.BackupDir != backupDir {
		t.Errorf("BackupDir = %q, want %q", plan.BackupDir, backupDir)
	}
}

func TestDetectBootstrapAction_InitWhenNothingExists(t *testing.T) {
	t.Setenv("BEADS_DOLT_DATA_DIR", "")
	t.Setenv("BEADS_DOLT_SERVER_DATABASE", "")
	t.Setenv("BEADS_DOLT_SERVER_HOST", "")
	t.Setenv("BEADS_DOLT_SERVER_PORT", "")
	tmpDir := t.TempDir()
	beadsDir := filepath.Join(tmpDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0o750); err != nil {
		t.Fatal(err)
	}

	// Run from the tmpDir so auto-detect doesn't find a git repo
	oldWd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = os.Chdir(oldWd) }()
	if err := os.Chdir(tmpDir); err != nil {
		t.Fatal(err)
	}

	cfg := configfile.DefaultConfig()
	plan := detectBootstrapAction(beadsDir, cfg)

	if plan.Action != "init" {
		t.Errorf("action = %q, want %q", plan.Action, "init")
	}
}

func TestNoWorkspaceBootstrapPayload(t *testing.T) {
	payload := noWorkspaceBootstrapPayload()

	if got := payload["action"]; got != "none" {
		t.Fatalf("action = %v, want %q", got, "none")
	}
	if got := payload["reason"]; got != activeWorkspaceNotFoundError() {
		t.Fatalf("reason = %v, want %q", got, activeWorkspaceNotFoundError())
	}
	if got := payload["suggestion"]; got != diagHint() {
		t.Fatalf("suggestion = %v, want %q", got, diagHint())
	}
}

func TestDetectBootstrapAction_ServerModeMissingConfiguredDBDoesNotReturnNone(t *testing.T) {
	t.Setenv("BEADS_DOLT_DATA_DIR", "")
	t.Setenv("BEADS_DOLT_SERVER_DATABASE", "")
	t.Setenv("BEADS_DOLT_SERVER_HOST", "")
	t.Setenv("BEADS_DOLT_SERVER_PORT", "")
	tmpDir := t.TempDir()
	beadsDir := filepath.Join(tmpDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0o750); err != nil {
		t.Fatal(err)
	}
	sharedDir := filepath.Join(tmpDir, "shared-dolt")
	if err := os.MkdirAll(filepath.Join(sharedDir, "hq"), 0o750); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(sharedDir, "dolt-server.port"), []byte("3311"), 0o644); err != nil {
		t.Fatal(err)
	}

	oldWd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = os.Chdir(oldWd) }()
	if err := os.Chdir(tmpDir); err != nil {
		t.Fatal(err)
	}

	cfg := configfile.DefaultConfig()
	cfg.DoltMode = configfile.DoltModeServer
	cfg.DoltDatabase = "project_missing"
	cfg.DoltDataDir = sharedDir
	t.Setenv("BEADS_DOLT_SHARED_SERVER", "1")
	t.Setenv("BEADS_DOLT_DATA_DIR", sharedDir)

	origCheck := checkBootstrapServerDB
	checkBootstrapServerDB = func(probeCfg bootstrapServerProbeConfig) bootstrapServerDBCheck {
		if probeCfg.database != "project_missing" {
			t.Fatalf("unexpected dbName: %s", probeCfg.database)
		}
		if probeCfg.port != 3311 {
			t.Fatalf("expected resolved server port 3311, got %d", probeCfg.port)
		}
		return bootstrapServerDBCheck{Exists: false, Reachable: true}
	}
	defer func() { checkBootstrapServerDB = origCheck }()
	origDelay := bootstrapRetryDelay
	bootstrapRetryDelay = func(time.Duration) {}
	defer func() { bootstrapRetryDelay = origDelay }()

	plan := detectBootstrapAction(beadsDir, cfg)
	if plan.Action == "none" {
		t.Fatalf("expected bootstrap to continue recovery when configured server DB is missing, got plan %#v", plan)
	}
	if plan.Action != "init" {
		t.Fatalf("expected init fallback when no remote/backup/jsonl exists, got %q", plan.Action)
	}
}

func TestDetectBootstrapAction_ServerModeProbeErrorStopsWithReason(t *testing.T) {
	t.Setenv("BEADS_DOLT_DATA_DIR", "")
	t.Setenv("BEADS_DOLT_SHARED_SERVER", "")
	t.Setenv("BEADS_DOLT_SERVER_DATABASE", "")
	t.Setenv("BEADS_DOLT_SERVER_HOST", "")
	t.Setenv("BEADS_DOLT_SERVER_PORT", "")
	tmpDir := t.TempDir()
	beadsDir := filepath.Join(tmpDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0o750); err != nil {
		t.Fatal(err)
	}
	sharedDir := filepath.Join(tmpDir, "shared-dolt")
	if err := os.MkdirAll(filepath.Join(sharedDir, "hq"), 0o750); err != nil {
		t.Fatal(err)
	}

	oldWd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = os.Chdir(oldWd) }()
	if err := os.Chdir(tmpDir); err != nil {
		t.Fatal(err)
	}

	cfg := configfile.DefaultConfig()
	cfg.DoltMode = configfile.DoltModeServer
	cfg.DoltDatabase = "project_missing"
	cfg.DoltDataDir = sharedDir
	t.Setenv("BEADS_DOLT_DATA_DIR", sharedDir)

	origCheck := checkBootstrapServerDB
	checkBootstrapServerDB = func(probeCfg bootstrapServerProbeConfig) bootstrapServerDBCheck {
		return bootstrapServerDBCheck{Reachable: true, Err: fmt.Errorf("permission denied")}
	}
	defer func() { checkBootstrapServerDB = origCheck }()

	plan := detectBootstrapAction(beadsDir, cfg)
	if plan.Action != "none" {
		t.Fatalf("expected bootstrap to stop when server probe errors, got %#v", plan)
	}
	if !strings.Contains(plan.Reason, "permission denied") {
		t.Fatalf("expected probe error in plan reason, got %#v", plan)
	}
}

func TestCheckBootstrapServerDB_HonorsTLSFlagInDSN(t *testing.T) {
	probeCfg := bootstrapServerProbeConfig{
		host:     "127.0.0.1",
		port:     1,
		user:     "root",
		database: "beads",
		tls:      true,
	}

	result := checkBootstrapServerDB(probeCfg)
	if result.Reachable {
		t.Fatal("expected unreachable test connection")
	}
	if result.Err == nil {
		t.Fatal("expected connection error for unreachable test host")
	}
}

func TestDetectBootstrapAction_SyncWhenOriginHasDoltRef(t *testing.T) {
	t.Setenv("BEADS_DOLT_DATA_DIR", "")
	t.Setenv("BEADS_DOLT_SERVER_DATABASE", "")
	t.Setenv("BEADS_DOLT_SERVER_HOST", "")
	t.Setenv("BEADS_DOLT_SERVER_PORT", "")
	// Create a bare repo with a refs/dolt/data ref
	bareDir := filepath.Join(t.TempDir(), "bare.git")
	runGitForBootstrapTest(t, "", "init", "--bare", bareDir)

	// Create a source repo, commit, push, then create the dolt ref
	sourceDir := t.TempDir()
	runGitForBootstrapTest(t, sourceDir, "init", "-b", "main")
	runGitForBootstrapTest(t, sourceDir, "config", "user.email", "test@test.com")
	runGitForBootstrapTest(t, sourceDir, "config", "user.name", "Test User")
	runGitForBootstrapTest(t, sourceDir, "commit", "--allow-empty", "-m", "init")
	runGitForBootstrapTest(t, sourceDir, "remote", "add", "origin", bareDir)
	runGitForBootstrapTest(t, sourceDir, "push", "origin", "HEAD:refs/dolt/data")
	// Create refs/dolt/data by pushing HEAD to that ref
	runGitForBootstrapTest(t, sourceDir, "push", "origin", "HEAD:refs/dolt/data")

	// Create a "clone" repo with origin pointing at the bare repo
	cloneDir := t.TempDir()
	runGitForBootstrapTest(t, cloneDir, "init", "-b", "main")
	runGitForBootstrapTest(t, cloneDir, "remote", "add", "origin", bareDir)

	beadsDir := filepath.Join(cloneDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0o750); err != nil {
		t.Fatal(err)
	}

	oldWd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = os.Chdir(oldWd) }()
	if err := os.Chdir(cloneDir); err != nil {
		t.Fatal(err)
	}

	cfg := configfile.DefaultConfig()
	plan := detectBootstrapAction(beadsDir, cfg)

	if plan.Action != "sync" {
		t.Errorf("action = %q, want %q", plan.Action, "sync")
	}
	if plan.SyncRemote == "" {
		t.Error("SyncRemote is empty, expected git+ prefixed URL")
	}
}

func TestDetectBootstrapAction_ExplicitSyncRemotePreservesRemotesAPIURL(t *testing.T) {
	snapshotBootstrapEnv(t)
	config.ResetForTesting()
	defer config.ResetForTesting()

	tmpDir := t.TempDir()
	beadsDir := filepath.Join(tmpDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0o750); err != nil {
		t.Fatal(err)
	}
	const syncRemote = "http://myserver:7007/mydb"
	seedSyncRemote(t, beadsDir, syncRemote)
	t.Setenv("BEADS_DIR", beadsDir)
	t.Setenv("BEADS_TEST_IGNORE_REPO_CONFIG", "1")
	if err := config.Initialize(); err != nil {
		t.Fatalf("config.Initialize failed: %v", err)
	}

	oldWd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = os.Chdir(oldWd) }()
	if err := os.Chdir(tmpDir); err != nil {
		t.Fatal(err)
	}

	cfg := configfile.DefaultConfig()
	plan := detectBootstrapAction(beadsDir, cfg)

	if plan.Action != "sync" {
		t.Errorf("action = %q, want %q", plan.Action, "sync")
	}
	if plan.SyncRemote != syncRemote {
		t.Errorf("SyncRemote = %q, want unnormalized explicit sync.remote %q", plan.SyncRemote, syncRemote)
	}
}

// TestDetectBootstrapAction_ExistingEmbeddedDBWithSyncRemoteIsNoOp is a
// regression for GH#5037: when sync.remote is set AND embeddeddolt already
// exists, plan must be Action=none (validate/report), not Action=sync which
// would DOLT_CLONE into the existing database and fail with Error 1007.
func TestDetectBootstrapAction_ExistingEmbeddedDBWithSyncRemoteIsNoOp(t *testing.T) {
	snapshotBootstrapEnv(t)
	config.ResetForTesting()
	defer config.ResetForTesting()

	tmpDir := t.TempDir()
	beadsDir := filepath.Join(tmpDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0o750); err != nil {
		t.Fatal(err)
	}
	// Non-empty embedded database footprint (what a prior successful bootstrap left).
	embedded := filepath.Join(beadsDir, "embeddeddolt")
	if err := os.MkdirAll(filepath.Join(embedded, "mydb"), 0o750); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(embedded, "mydb", ".keep"), []byte("x"), 0o644); err != nil {
		t.Fatal(err)
	}
	const syncRemote = "http://myserver:7007/mydb"
	seedSyncRemote(t, beadsDir, syncRemote)
	t.Setenv("BEADS_DIR", beadsDir)
	t.Setenv("BEADS_TEST_IGNORE_REPO_CONFIG", "1")
	if err := config.Initialize(); err != nil {
		t.Fatalf("config.Initialize failed: %v", err)
	}

	oldWd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = os.Chdir(oldWd) }()
	if err := os.Chdir(tmpDir); err != nil {
		t.Fatal(err)
	}

	cfg := configfile.DefaultConfig()
	plan := detectBootstrapAction(beadsDir, cfg)

	if plan.Action != "none" {
		t.Fatalf("action = %q reason=%q, want none (existing DB must not re-clone when sync.remote set)", plan.Action, plan.Reason)
	}
	if !plan.HasExisting {
		t.Error("HasExisting = false, want true")
	}
	if !strings.Contains(plan.Reason, "already exists") {
		t.Errorf("Reason = %q, want to mention already exists", plan.Reason)
	}
}

func TestDetectBootstrapAction_InitWhenOriginHasNoDoltRef(t *testing.T) {
	t.Setenv("BEADS_DOLT_DATA_DIR", "")
	t.Setenv("BEADS_DOLT_SERVER_DATABASE", "")
	t.Setenv("BEADS_DOLT_SERVER_HOST", "")
	t.Setenv("BEADS_DOLT_SERVER_PORT", "")
	// Create a bare repo without refs/dolt/data
	bareDir := filepath.Join(t.TempDir(), "bare.git")
	runGitForBootstrapTest(t, "", "init", "--bare", bareDir)

	cloneDir := t.TempDir()
	runGitForBootstrapTest(t, cloneDir, "init", "-b", "main")
	runGitForBootstrapTest(t, cloneDir, "remote", "add", "origin", bareDir)

	beadsDir := filepath.Join(cloneDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0o750); err != nil {
		t.Fatal(err)
	}

	oldWd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = os.Chdir(oldWd) }()
	if err := os.Chdir(cloneDir); err != nil {
		t.Fatal(err)
	}

	cfg := configfile.DefaultConfig()
	plan := detectBootstrapAction(beadsDir, cfg)

	if plan.Action != "init" {
		t.Errorf("action = %q, want %q (no dolt ref on origin)", plan.Action, "init")
	}
}

// TestBootstrapFreshCloneDetectsRemote verifies that when .beads does NOT
// exist but origin has refs/dolt/data, the bootstrap handler's remote-probe
// logic synthesizes beadsDir and detectBootstrapAction produces a "sync"
// plan instead of the handler exiting with "No .beads directory found".
// This is the core fix for GH#2792.
func TestBootstrapFreshCloneDetectsRemote(t *testing.T) {
	// Create a bare repo and push a fake refs/dolt/data ref to it.
	bareDir := filepath.Join(t.TempDir(), "bare.git")
	runGitForBootstrapTest(t, "", "init", "--bare", bareDir)

	sourceDir := t.TempDir()
	runGitForBootstrapTest(t, sourceDir, "init", "-b", "main")
	runGitForBootstrapTest(t, sourceDir, "config", "user.email", "test@test.com")
	runGitForBootstrapTest(t, sourceDir, "config", "user.name", "Test User")
	runGitForBootstrapTest(t, sourceDir, "commit", "--allow-empty", "-m", "init")
	runGitForBootstrapTest(t, sourceDir, "remote", "add", "origin", bareDir)
	runGitForBootstrapTest(t, sourceDir, "push", "origin", "HEAD:refs/dolt/data")
	runGitForBootstrapTest(t, sourceDir, "push", "origin", "HEAD:refs/dolt/data")

	// Clone into a fresh directory — no .beads exists.
	cloneDir := t.TempDir()
	runGitForBootstrapTest(t, cloneDir, "init", "-b", "main")
	runGitForBootstrapTest(t, cloneDir, "remote", "add", "origin", bareDir)

	// Verify .beads does NOT exist.
	beadsDir := filepath.Join(cloneDir, ".beads")
	if _, err := os.Stat(beadsDir); err == nil {
		t.Fatal(".beads should not exist before bootstrap")
	}

	oldWd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = os.Chdir(oldWd) }()
	if err := os.Chdir(cloneDir); err != nil {
		t.Fatal(err)
	}

	// Replicate the Run handler's remote-probe logic: when beadsDir is
	// empty, check origin for refs/dolt/data and synthesize beadsDir.
	// This exercises the same code path the handler uses before calling
	// detectBootstrapAction.
	if !isGitRepo() {
		t.Fatal("expected to be in a git repo")
	}
	originURL, err := gitOriginGetURL()
	if err != nil || originURL == "" {
		t.Fatalf("expected origin URL, got err=%v url=%q", err, originURL)
	}
	if !gitOriginHasDoltDataRef() {
		t.Fatal("expected origin to have refs/dolt/data")
	}

	// Synthesize beadsDir the same way the handler does, then feed it
	// through detectBootstrapAction — the single code path for plan building.
	cwd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	synthesizedDir := filepath.Join(cwd, ".beads")
	cfg := configfile.DefaultConfig()
	plan := detectBootstrapAction(synthesizedDir, cfg)

	if plan.Action != "sync" {
		t.Errorf("action = %q, want %q", plan.Action, "sync")
	}
	if plan.SyncRemote == "" {
		t.Error("SyncRemote should not be empty")
	}
	if plan.BeadsDir != synthesizedDir {
		t.Errorf("BeadsDir = %q, want %q", plan.BeadsDir, synthesizedDir)
	}
}

// TestBootstrapFreshCloneNoRemoteData verifies that when .beads does NOT exist
// and origin has NO refs/dolt/data, bootstrap correctly reports no data found
// (does not create .beads or crash).
func TestBootstrapFreshCloneNoRemoteData(t *testing.T) {
	// Create a bare repo WITHOUT refs/dolt/data.
	bareDir := filepath.Join(t.TempDir(), "bare.git")
	runGitForBootstrapTest(t, "", "init", "--bare", bareDir)

	cloneDir := t.TempDir()
	runGitForBootstrapTest(t, cloneDir, "init", "-b", "main")
	runGitForBootstrapTest(t, cloneDir, "remote", "add", "origin", bareDir)

	oldWd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = os.Chdir(oldWd) }()
	if err := os.Chdir(cloneDir); err != nil {
		t.Fatal(err)
	}

	// When no .beads and no remote data, the remote probe should return false.
	if !isGitRepo() {
		t.Fatal("expected to be in a git repo")
	}
	if gitOriginHasDoltDataRef() {
		t.Fatal("origin should NOT have refs/dolt/data")
	}

	// .beads should still not exist after detection.
	beadsDir := filepath.Join(cloneDir, ".beads")
	if _, err := os.Stat(beadsDir); err == nil {
		t.Fatal(".beads should not be created when remote has no data")
	}
}

// TestBootstrapExistingBeadsDirUnchanged verifies that when .beads already
// exists, the normal bootstrap flow is unaffected by the fresh-clone fix.
// TestDetectBootstrapAction_PlanUsesConfiguredDatabaseName verifies that
// detectBootstrapAction carries the configured dolt_database into the plan,
// rather than silently falling back to the default "beads". This is the
// core regression test for GH#3029.
func TestDetectBootstrapAction_PlanUsesConfiguredDatabaseName(t *testing.T) {
	t.Setenv("BEADS_DOLT_DATA_DIR", "")
	t.Setenv("BEADS_DOLT_SERVER_DATABASE", "")
	t.Setenv("BEADS_DOLT_SERVER_HOST", "")
	t.Setenv("BEADS_DOLT_SERVER_PORT", "")

	tmpDir := t.TempDir()
	beadsDir := filepath.Join(tmpDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0o750); err != nil {
		t.Fatal(err)
	}

	oldWd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = os.Chdir(oldWd) }()
	if err := os.Chdir(tmpDir); err != nil {
		t.Fatal(err)
	}

	cfg := configfile.DefaultConfig()
	cfg.DoltDatabase = "my_project_db"

	plan := detectBootstrapAction(beadsDir, cfg)

	if plan.Database != "my_project_db" {
		t.Errorf("plan.Database = %q, want %q; bootstrap must use the configured database name, not the default",
			plan.Database, "my_project_db")
	}
}

// TestDetectBootstrapAction_PlanDefaultDatabaseWhenNotConfigured verifies
// that the default "beads" is used when no dolt_database is configured.
func TestDetectBootstrapAction_PlanDefaultDatabaseWhenNotConfigured(t *testing.T) {
	t.Setenv("BEADS_DOLT_DATA_DIR", "")
	t.Setenv("BEADS_DOLT_SERVER_DATABASE", "")
	t.Setenv("BEADS_DOLT_SERVER_HOST", "")
	t.Setenv("BEADS_DOLT_SERVER_PORT", "")

	tmpDir := t.TempDir()
	beadsDir := filepath.Join(tmpDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0o750); err != nil {
		t.Fatal(err)
	}

	oldWd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = os.Chdir(oldWd) }()
	if err := os.Chdir(tmpDir); err != nil {
		t.Fatal(err)
	}

	cfg := configfile.DefaultConfig()
	plan := detectBootstrapAction(beadsDir, cfg)

	if plan.Database != configfile.DefaultDoltDatabase {
		t.Errorf("plan.Database = %q, want %q (default)", plan.Database, configfile.DefaultDoltDatabase)
	}
}

// TestDetectBootstrapAction_ServerModePlanUsesConfiguredDatabaseName verifies
// that in server mode, the plan carries the configured database name for
// both the plan.Database field and the server probe. This is the specific
// failure mode reported in GH#3029: when FindBeadsDir resolved to the wrong
// .beads/, the config had no dolt_database, and the plan fell back to "beads".
func TestDetectBootstrapAction_ServerModePlanUsesConfiguredDatabaseName(t *testing.T) {
	t.Setenv("BEADS_DOLT_DATA_DIR", "")
	t.Setenv("BEADS_DOLT_SERVER_DATABASE", "")
	t.Setenv("BEADS_DOLT_SERVER_HOST", "")
	t.Setenv("BEADS_DOLT_SERVER_PORT", "")
	t.Setenv("BEADS_DOLT_SHARED_SERVER", "")

	tmpDir := t.TempDir()
	beadsDir := filepath.Join(tmpDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0o750); err != nil {
		t.Fatal(err)
	}

	// Create a dolt data dir with a subdirectory so the existing-DB check fires.
	// Use BEADS_DOLT_DATA_DIR (not shared server mode) so ResolveDoltDir
	// returns our test directory instead of ~/.beads/shared-server/dolt/.
	doltDataDir := filepath.Join(tmpDir, "dolt-data")
	if err := os.MkdirAll(filepath.Join(doltDataDir, "myrig"), 0o750); err != nil {
		t.Fatal(err)
	}
	t.Setenv("BEADS_DOLT_DATA_DIR", doltDataDir)

	oldWd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = os.Chdir(oldWd) }()
	if err := os.Chdir(tmpDir); err != nil {
		t.Fatal(err)
	}

	cfg := configfile.DefaultConfig()
	cfg.DoltMode = configfile.DoltModeServer
	cfg.DoltDatabase = "myrig"
	cfg.DoltDataDir = doltDataDir

	var probedDBName string
	origCheck := checkBootstrapServerDB
	checkBootstrapServerDB = func(probeCfg bootstrapServerProbeConfig) bootstrapServerDBCheck {
		probedDBName = probeCfg.database
		return bootstrapServerDBCheck{Exists: false, Reachable: true}
	}
	defer func() { checkBootstrapServerDB = origCheck }()
	origDelay := bootstrapRetryDelay
	bootstrapRetryDelay = func(time.Duration) {}
	defer func() { bootstrapRetryDelay = origDelay }()

	plan := detectBootstrapAction(beadsDir, cfg)

	if plan.Database != "myrig" {
		t.Errorf("plan.Database = %q, want %q", plan.Database, "myrig")
	}
	if probedDBName != "myrig" {
		t.Errorf("server probe used database %q, want %q; bootstrap must probe the configured database, not the default",
			probedDBName, "myrig")
	}
}

func TestBootstrapExistingBeadsDirUnchanged(t *testing.T) {
	tmpDir := t.TempDir()
	beadsDir := filepath.Join(tmpDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0o750); err != nil {
		t.Fatal(err)
	}

	oldWd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = os.Chdir(oldWd) }()
	if err := os.Chdir(tmpDir); err != nil {
		t.Fatal(err)
	}

	// With .beads present but empty, detectBootstrapAction should return "init".
	cfg := configfile.DefaultConfig()
	plan := detectBootstrapAction(beadsDir, cfg)
	if plan.Action != "init" {
		t.Errorf("action = %q, want %q for existing empty .beads", plan.Action, "init")
	}
}

// TestDetectBootstrapAction_ServerModeUsesCustomDatabaseName verifies that when
// metadata.json has dolt_database set to a custom name (e.g. "my_rig"),
// detectBootstrapAction uses that name in the plan instead of the default "beads".
// This is the core fix for GH#3029.
func TestDetectBootstrapAction_ServerModeUsesCustomDatabaseName(t *testing.T) {
	t.Setenv("BEADS_DOLT_DATA_DIR", "")
	t.Setenv("BEADS_DOLT_SERVER_DATABASE", "")
	t.Setenv("BEADS_DOLT_SERVER_HOST", "")
	t.Setenv("BEADS_DOLT_SERVER_PORT", "")

	tmpDir := t.TempDir()
	beadsDir := filepath.Join(tmpDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0o750); err != nil {
		t.Fatal(err)
	}

	// Write metadata.json with a custom dolt_database name
	metadataJSON := `{"dolt_mode": "server", "dolt_database": "my_rig"}`
	if err := os.WriteFile(filepath.Join(beadsDir, "metadata.json"), []byte(metadataJSON), 0o644); err != nil {
		t.Fatal(err)
	}

	oldWd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = os.Chdir(oldWd) }()
	if err := os.Chdir(tmpDir); err != nil {
		t.Fatal(err)
	}

	// Load config the same way bootstrap.go does (lines 172-174)
	cfg, err := configfile.Load(beadsDir)
	if err != nil || cfg == nil {
		cfg = configfile.DefaultConfig()
	}

	// Verify config loaded the custom database name
	if got := cfg.GetDoltDatabase(); got != "my_rig" {
		t.Fatalf("GetDoltDatabase() = %q, want %q (metadata.json dolt_database ignored)", got, "my_rig")
	}

	plan := detectBootstrapAction(beadsDir, cfg)

	// The plan should use the custom database name, not "beads"
	if plan.Database != "my_rig" {
		t.Errorf("plan.Database = %q, want %q", plan.Database, "my_rig")
	}
}

// TestDetectBootstrapAction_FreshCloneUsesMetadataDBName verifies that when
// .beads doesn't exist but origin has refs/dolt/data, and metadata.json is
// committed to git with a custom dolt_database, the bootstrap plan uses the
// correct database name after .beads/metadata.json is loaded.
// Part of the fix for GH#3029.
func TestDetectBootstrapAction_FreshCloneUsesMetadataDBName(t *testing.T) {
	t.Setenv("BEADS_DOLT_DATA_DIR", "")
	t.Setenv("BEADS_DOLT_SERVER_DATABASE", "")
	t.Setenv("BEADS_DOLT_SERVER_HOST", "")
	t.Setenv("BEADS_DOLT_SERVER_PORT", "")

	// Create a bare repo with refs/dolt/data
	bareDir := filepath.Join(t.TempDir(), "bare.git")
	runGitForBootstrapTest(t, "", "init", "--bare", "--initial-branch=main", bareDir)

	sourceDir := t.TempDir()
	runGitForBootstrapTest(t, sourceDir, "init", "-b", "main")
	runGitForBootstrapTest(t, sourceDir, "config", "user.email", "test@test.com")
	runGitForBootstrapTest(t, sourceDir, "config", "user.name", "Test User")

	// Commit .beads/metadata.json with custom dolt_database to the source repo
	srcBeads := filepath.Join(sourceDir, ".beads")
	if err := os.MkdirAll(srcBeads, 0o750); err != nil {
		t.Fatal(err)
	}
	metadataJSON := `{"dolt_mode": "server", "dolt_database": "my_rig"}`
	if err := os.WriteFile(filepath.Join(srcBeads, "metadata.json"), []byte(metadataJSON), 0o644); err != nil {
		t.Fatal(err)
	}
	runGitForBootstrapTest(t, sourceDir, "add", ".beads/metadata.json")
	runGitForBootstrapTest(t, sourceDir, "commit", "-m", "add beads metadata")
	runGitForBootstrapTest(t, sourceDir, "remote", "add", "origin", bareDir)
	runGitForBootstrapTest(t, sourceDir, "push", "origin", "main")
	runGitForBootstrapTest(t, sourceDir, "push", "origin", "HEAD:refs/dolt/data")

	// Clone and verify .beads/metadata.json is checked out.
	// Use a subdirectory of TempDir so git clone creates it (clone fails
	// if the target directory already exists and is non-empty).
	cloneDir := filepath.Join(t.TempDir(), "repo")
	runGitForBootstrapTest(t, "", "clone", bareDir, cloneDir)

	beadsDir := filepath.Join(cloneDir, ".beads")

	oldWd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = os.Chdir(oldWd) }()
	if err := os.Chdir(cloneDir); err != nil {
		t.Fatal(err)
	}

	// Load config the same way bootstrap.go does
	cfg, cfgErr := configfile.Load(beadsDir)
	if cfgErr != nil || cfg == nil {
		cfg = configfile.DefaultConfig()
	}

	// After a git clone with committed metadata.json, the config should
	// have the custom database name
	if got := cfg.GetDoltDatabase(); got != "my_rig" {
		t.Fatalf("GetDoltDatabase() = %q, want %q (metadata.json dolt_database not loaded after clone)", got, "my_rig")
	}

	plan := detectBootstrapAction(beadsDir, cfg)

	if plan.Action != "sync" {
		t.Errorf("action = %q, want %q", plan.Action, "sync")
	}
	if plan.Database != "my_rig" {
		t.Errorf("plan.Database = %q, want %q", plan.Database, "my_rig")
	}
}

// TestBootstrapFreshCloneSynthesizedDirUsesDefaultDB verifies that when
// .beads directory doesn't exist (no metadata.json committed to git) and
// beadsDir is synthesized from the remote-probe path, the config falls back
// to DefaultConfig and uses the default "beads" database name.
// This is the expected behavior for repos that never committed metadata.json.
func TestBootstrapFreshCloneSynthesizedDirUsesDefaultDB(t *testing.T) {
	t.Setenv("BEADS_DOLT_DATA_DIR", "")
	t.Setenv("BEADS_DOLT_SERVER_DATABASE", "")
	t.Setenv("BEADS_DOLT_SERVER_HOST", "")
	t.Setenv("BEADS_DOLT_SERVER_PORT", "")

	// Create a bare repo with refs/dolt/data but NO .beads/metadata.json
	bareDir := filepath.Join(t.TempDir(), "bare.git")
	runGitForBootstrapTest(t, "", "init", "--bare", bareDir)

	sourceDir := t.TempDir()
	runGitForBootstrapTest(t, sourceDir, "init", "-b", "main")
	runGitForBootstrapTest(t, sourceDir, "config", "user.email", "test@test.com")
	runGitForBootstrapTest(t, sourceDir, "config", "user.name", "Test User")
	runGitForBootstrapTest(t, sourceDir, "commit", "--allow-empty", "-m", "init")
	runGitForBootstrapTest(t, sourceDir, "remote", "add", "origin", bareDir)
	runGitForBootstrapTest(t, sourceDir, "push", "origin", "HEAD:refs/dolt/data")
	runGitForBootstrapTest(t, sourceDir, "push", "origin", "HEAD:refs/dolt/data")

	// Clone — no .beads dir
	cloneDir := t.TempDir()
	runGitForBootstrapTest(t, cloneDir, "init", "-b", "main")
	runGitForBootstrapTest(t, cloneDir, "remote", "add", "origin", bareDir)

	oldWd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = os.Chdir(oldWd) }()
	if err := os.Chdir(cloneDir); err != nil {
		t.Fatal(err)
	}

	// Synthesize beadsDir the way the Run handler does
	cwd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	synthesizedDir := filepath.Join(cwd, ".beads")

	// Load config the same way bootstrap.go does — synthesized dir doesn't exist
	cfg, cfgErr := configfile.Load(synthesizedDir)
	if cfgErr != nil || cfg == nil {
		cfg = configfile.DefaultConfig()
	}

	// Without metadata.json, default "beads" is expected
	if got := cfg.GetDoltDatabase(); got != "beads" {
		t.Fatalf("GetDoltDatabase() = %q, want %q (should default when no metadata.json)", got, "beads")
	}

	plan := detectBootstrapAction(synthesizedDir, cfg)
	if plan.Action != "sync" {
		t.Errorf("action = %q, want %q", plan.Action, "sync")
	}
	if plan.Database != "beads" {
		t.Errorf("plan.Database = %q, want %q (default when no metadata.json)", plan.Database, "beads")
	}
}

// TestBootstrapRigSubdirUsesParentDBName verifies that when running bootstrap
// from a rig subdirectory (its own git repo) that doesn't have a local .beads,
// but the parent workspace has .beads/metadata.json with dolt_database set,
// the bootstrap plan uses the parent workspace's database name instead of "beads".
// This is the core reproduction for GH#3029.
func TestBootstrapRigSubdirUsesParentDBName(t *testing.T) {
	t.Setenv("BEADS_DOLT_DATA_DIR", "")
	t.Setenv("BEADS_DOLT_SERVER_DATABASE", "")
	t.Setenv("BEADS_DOLT_SERVER_HOST", "")
	t.Setenv("BEADS_DOLT_SERVER_PORT", "")

	// Create workspace layout:
	//   workspace/
	//     .beads/metadata.json  (dolt_database: "my_rig")
	//     mayor/rig/            (its own git repo, no .beads)
	workspace := t.TempDir()
	beadsDir := filepath.Join(workspace, ".beads")
	if err := os.MkdirAll(beadsDir, 0o750); err != nil {
		t.Fatal(err)
	}
	metadataJSON := `{"dolt_mode": "server", "dolt_database": "my_rig"}`
	if err := os.WriteFile(filepath.Join(beadsDir, "metadata.json"), []byte(metadataJSON), 0o644); err != nil {
		t.Fatal(err)
	}

	// Create a rig subdirectory with its own git repo and remote that has refs/dolt/data
	rigDir := filepath.Join(workspace, "mayor", "rig")
	if err := os.MkdirAll(rigDir, 0o750); err != nil {
		t.Fatal(err)
	}

	bareDir := filepath.Join(t.TempDir(), "rig-origin.git")
	runGitForBootstrapTest(t, "", "init", "--bare", "--initial-branch=main", bareDir)
	runGitForBootstrapTest(t, rigDir, "init", "-b", "main")
	runGitForBootstrapTest(t, rigDir, "config", "user.email", "test@test.com")
	runGitForBootstrapTest(t, rigDir, "config", "user.name", "Test User")
	runGitForBootstrapTest(t, rigDir, "commit", "--allow-empty", "-m", "init")
	runGitForBootstrapTest(t, rigDir, "remote", "add", "origin", bareDir)
	runGitForBootstrapTest(t, rigDir, "push", "origin", "HEAD:refs/dolt/data")
	runGitForBootstrapTest(t, rigDir, "push", "origin", "HEAD:refs/dolt/data")

	oldWd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = os.Chdir(oldWd) }()
	if err := os.Chdir(rigDir); err != nil {
		t.Fatal(err)
	}

	// Simulate what the bootstrap Run handler does when FindBeadsDir returns "":
	// 1. beadsDir is empty (rig's git root has no .beads)
	// 2. Remote probe finds refs/dolt/data on origin
	// 3. beadsDir is synthesized as <cwd>/.beads
	cwd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	synthesizedDir := filepath.Join(cwd, ".beads")

	// configfile.Load on synthesized dir fails — no metadata.json there
	cfg, cfgErr := configfile.Load(synthesizedDir)
	if cfgErr != nil || cfg == nil {
		// This is the fix path: search parent directories for metadata.json
		cfg, cfgErr = findParentConfig(synthesizedDir)
		if cfgErr != nil {
			t.Fatalf("findParentConfig: %v", cfgErr)
		}
	}
	if cfg == nil {
		cfg = configfile.DefaultConfig()
	}

	// The key assertion: should find the workspace's dolt_database, not default "beads"
	if got := cfg.GetDoltDatabase(); got != "my_rig" {
		t.Fatalf("GetDoltDatabase() = %q, want %q (parent workspace metadata.json not found)", got, "my_rig")
	}

	plan := detectBootstrapAction(synthesizedDir, cfg)
	if plan.Action != "sync" {
		t.Errorf("action = %q, want %q", plan.Action, "sync")
	}
	if plan.Database != "my_rig" {
		t.Errorf("plan.Database = %q, want %q", plan.Database, "my_rig")
	}
}

func TestFindParentConfigDoesNotSkipCorruptNearestAncestor(t *testing.T) {
	root := t.TempDir()
	higherBeadsDir := filepath.Join(root, ".beads")
	if err := os.MkdirAll(higherBeadsDir, 0o750); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(higherBeadsDir, "metadata.json"), []byte(`{"dolt_database":"wrong_higher_database"}`), 0o600); err != nil {
		t.Fatal(err)
	}

	nearestBeadsDir := filepath.Join(root, "workspace", ".beads")
	if err := os.MkdirAll(nearestBeadsDir, 0o750); err != nil {
		t.Fatal(err)
	}
	corrupt := []byte("{\n")
	metadataPath := filepath.Join(nearestBeadsDir, "metadata.json")
	if err := os.WriteFile(metadataPath, corrupt, 0o600); err != nil {
		t.Fatal(err)
	}

	synthesizedDir := filepath.Join(root, "workspace", "rig", ".beads")
	if cfg, err := findParentConfig(synthesizedDir); err == nil {
		t.Fatalf("findParentConfig skipped corrupt nearest metadata and selected higher database %q", cfg.GetDoltDatabase())
	} else if !strings.Contains(err.Error(), filepath.Join("workspace", ".beads", "metadata.json")) {
		t.Fatalf("findParentConfig error = %v, want nearest metadata path", err)
	}
	if after, err := os.ReadFile(metadataPath); err != nil || string(after) != string(corrupt) {
		t.Fatalf("corrupt nearest metadata changed: got %q, err %v", after, err)
	}
}

func TestFindParentConfigDoesNotAdoptOSTempRoot(t *testing.T) {
	sandbox := t.TempDir()
	tempRoot := filepath.Join(sandbox, "tmp")
	rootBeadsDir := filepath.Join(tempRoot, ".beads")
	if err := os.MkdirAll(rootBeadsDir, 0o750); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(rootBeadsDir, "metadata.json"), []byte(`{"dolt_database":"temp_root"}`), 0o600); err != nil {
		t.Fatal(err)
	}
	t.Setenv("TMPDIR", tempRoot)

	requested := filepath.Join(tempRoot, "isolated", "project", ".beads")
	cfg, err := findParentConfig(requested)
	if err != nil {
		t.Fatal(err)
	}
	if cfg != nil {
		t.Fatalf("findParentConfig() adopted OS temp-root database %q", cfg.GetDoltDatabase())
	}
}

// TestFindParentConfigWithoutHomeKeepsSearchingAboveCwd pins the $HOME
// boundary's empty sentinel. os.UserHomeDir fails when HOME is unset, and
// canonicalizing the resulting "" resolves it to the current working
// directory, which silently turns "don't search above $HOME" into "stop at the
// CWD". The walk here starts exactly at the CWD, so the ancestor workspace
// config one level up is only reachable when "" still means "no boundary".
func TestFindParentConfigWithoutHomeKeepsSearchingAboveCwd(t *testing.T) {
	sandbox := t.TempDir()
	workspace := filepath.Join(sandbox, "workspace")
	workspaceBeadsDir := filepath.Join(workspace, ".beads")
	if err := os.MkdirAll(workspaceBeadsDir, 0o750); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(workspaceBeadsDir, "metadata.json"), []byte(`{"dolt_database":"parent_workspace"}`), 0o600); err != nil {
		t.Fatal(err)
	}

	// findParentConfig starts at the parent of the requested .beads directory's
	// project, which is <workspace>/rig here.
	rig := filepath.Join(workspace, "rig")
	requested := filepath.Join(rig, "project", ".beads")
	if err := os.MkdirAll(requested, 0o750); err != nil {
		t.Fatal(err)
	}
	t.Chdir(rig)
	// Keep the temp-root ceiling clear of this walk; it is not what this pins.
	t.Setenv("TMPDIR", filepath.Join(sandbox, "tmp"))
	// os.UserHomeDir reads HOME everywhere except Windows, where it reads
	// USERPROFILE; clear both so it fails the way an unset HOME does.
	t.Setenv("HOME", "")
	t.Setenv("USERPROFILE", "")

	cfg, err := findParentConfig(requested)
	if err != nil {
		t.Fatal(err)
	}
	if cfg == nil {
		t.Fatal("findParentConfig() = nil, want the workspace config above the CWD")
	}
	if got := cfg.GetDoltDatabase(); got != "parent_workspace" {
		t.Errorf("GetDoltDatabase() = %q, want %q", got, "parent_workspace")
	}
}

// TestDetectBootstrapAction_SharedServerEnvUsesSharedPath verifies that when
// BEADS_DOLT_SHARED_SERVER=1 is set but cfg.DoltMode is the default (embedded),
// detectBootstrapAction looks in the shared-server directory — not embeddeddolt/.
// This is the root cause of GH#30.
func TestDetectBootstrapAction_SharedServerEnvUsesSharedPath(t *testing.T) {
	t.Setenv("BEADS_DOLT_DATA_DIR", "")
	t.Setenv("BEADS_DOLT_SERVER_DATABASE", "")
	t.Setenv("BEADS_DOLT_SERVER_HOST", "")
	t.Setenv("BEADS_DOLT_SERVER_PORT", "")

	tmpDir := t.TempDir()
	beadsDir := filepath.Join(tmpDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0o750); err != nil {
		t.Fatal(err)
	}

	// Override the home dir so SharedDoltDir() resolves to our temp directory
	// instead of the real ~/.beads/shared-server/dolt/. It goes through
	// os.UserHomeDir(), which reads USERPROFILE on Windows and HOME elsewhere,
	// so both must be set for this to be portable.
	t.Setenv("HOME", tmpDir)
	t.Setenv("USERPROFILE", tmpDir)

	// Create a database directory at the shared-server location.
	// SharedDoltDir() returns $HOME/.beads/shared-server/dolt/.
	sharedDoltDir := filepath.Join(tmpDir, ".beads", "shared-server", "dolt")
	if err := os.MkdirAll(filepath.Join(sharedDoltDir, "beads"), 0o750); err != nil {
		t.Fatal(err)
	}

	oldWd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = os.Chdir(oldWd) }()
	if err := os.Chdir(tmpDir); err != nil {
		t.Fatal(err)
	}

	// Shared server enabled, but cfg.DoltMode is default (embedded).
	// Before the fix, this would look in embeddeddolt/ and miss the
	// existing shared-server database.
	t.Setenv("BEADS_DOLT_SHARED_SERVER", "1")

	cfg := configfile.DefaultConfig()
	// Deliberately do NOT set cfg.DoltMode = configfile.DoltModeServer.
	// This reproduces the bug: shared-server via env var with default DoltMode.

	// The server probe stub: report the DB exists so we get action=none.
	origCheck := checkBootstrapServerDB
	checkBootstrapServerDB = func(probeCfg bootstrapServerProbeConfig) bootstrapServerDBCheck {
		return bootstrapServerDBCheck{Exists: true, Reachable: true}
	}
	defer func() { checkBootstrapServerDB = origCheck }()

	plan := detectBootstrapAction(beadsDir, cfg)

	if plan.Action != "none" {
		t.Fatalf("expected action=none (existing shared-server DB detected), got %q: %s", plan.Action, plan.Reason)
	}
	if !plan.HasExisting {
		t.Error("HasExisting = false, want true")
	}
}

// TestDetectBootstrapAction_WorktreeSynthesizedDirPrefersSyncOverDefaultSharedDB
// verifies that when bootstrap is running from a worktree whose fallback
// .beads path lives under a bare/common git directory, remote recovery via
// refs/dolt/data wins over an unrelated default "beads" database already
// present on the shared server.
func TestDetectBootstrapAction_WorktreeSynthesizedDirPrefersSyncOverDefaultSharedDB(t *testing.T) {
	t.Setenv("BEADS_DOLT_DATA_DIR", "")
	t.Setenv("BEADS_DOLT_SERVER_DATABASE", "")
	t.Setenv("BEADS_DOLT_SERVER_HOST", "")
	t.Setenv("BEADS_DOLT_SERVER_PORT", "")
	t.Setenv("BEADS_DOLT_SERVER_MODE", "")
	t.Setenv("BEADS_DOLT_SHARED_SERVER", "1")

	homeDir := t.TempDir()
	t.Setenv("HOME", homeDir)

	originBare := filepath.Join(t.TempDir(), "origin.git")
	runGitForBootstrapTest(t, "", "init", "--bare", "--initial-branch=main", originBare)

	sourceDir := t.TempDir()
	runGitForBootstrapTest(t, sourceDir, "init", "-b", "main")
	runGitForBootstrapTest(t, sourceDir, "config", "user.email", "test@test.com")
	runGitForBootstrapTest(t, sourceDir, "config", "user.name", "Test User")
	runGitForBootstrapTest(t, sourceDir, "commit", "--allow-empty", "-m", "init")
	runGitForBootstrapTest(t, sourceDir, "remote", "add", "origin", originBare)
	runGitForBootstrapTest(t, sourceDir, "push", "origin", "main")
	runGitForBootstrapTest(t, sourceDir, "push", "origin", "HEAD:refs/dolt/data")

	localBare := filepath.Join(t.TempDir(), "local-bare.git")
	runGitForBootstrapTest(t, "", "clone", "--bare", originBare, localBare)

	worktreeDir := filepath.Join(t.TempDir(), "worktree")
	runGitForBootstrapTest(t, "", "--git-dir="+localBare, "worktree", "add", worktreeDir, "main")

	sharedDoltDir := filepath.Join(homeDir, ".beads", "shared-server", "dolt")
	if err := os.MkdirAll(filepath.Join(sharedDoltDir, "beads"), 0o750); err != nil {
		t.Fatal(err)
	}

	oldWd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = os.Chdir(oldWd) }()
	if err := os.Chdir(worktreeDir); err != nil {
		t.Fatal(err)
	}

	synthesizedDir := filepath.Join(localBare, ".beads")
	cfg, cfgErr := configfile.Load(synthesizedDir)
	if cfgErr != nil || cfg == nil {
		cfg, cfgErr = findParentConfig(synthesizedDir)
		if cfgErr != nil {
			t.Fatalf("findParentConfig: %v", cfgErr)
		}
	}
	if cfg == nil {
		cfg = configfile.DefaultConfig()
	}

	if got := cfg.GetDoltDatabase(); got != "beads" {
		t.Fatalf("GetDoltDatabase() = %q, want %q (default expected without local metadata)", got, "beads")
	}

	origCheck := checkBootstrapServerDB
	checkBootstrapServerDB = func(probeCfg bootstrapServerProbeConfig) bootstrapServerDBCheck {
		if probeCfg.database != "beads" {
			t.Fatalf("probeCfg.database = %q, want %q", probeCfg.database, "beads")
		}
		return bootstrapServerDBCheck{Exists: true, Reachable: true}
	}
	defer func() { checkBootstrapServerDB = origCheck }()

	plan := detectBootstrapAction(synthesizedDir, cfg)

	if plan.Action != "sync" {
		t.Fatalf("expected action=%q, got %q: %s", "sync", plan.Action, plan.Reason)
	}
	if plan.SyncRemote == "" {
		t.Fatal("expected SyncRemote to be populated from origin refs/dolt/data detection")
	}
	if plan.Database != "beads" {
		t.Errorf("plan.Database = %q, want %q (default metadata-free value should still recover via sync)", plan.Database, "beads")
	}
}

func TestDetectBootstrapAction_SynthesizedDirWithoutRecoveryStillUsesExistingSharedDB(t *testing.T) {
	t.Setenv("BEADS_DOLT_DATA_DIR", "")
	t.Setenv("BEADS_DOLT_SERVER_DATABASE", "")
	t.Setenv("BEADS_DOLT_SERVER_HOST", "")
	t.Setenv("BEADS_DOLT_SERVER_PORT", "")
	t.Setenv("BEADS_DOLT_SERVER_MODE", "")
	t.Setenv("BEADS_DOLT_SHARED_SERVER", "1")

	homeDir := t.TempDir()
	// detectBootstrapAction resolves the home dir with os.UserHomeDir(), which reads
	// USERPROFILE on Windows and HOME elsewhere; set both so the shared-server probe
	// looks inside the temp home on every platform.
	t.Setenv("HOME", homeDir)
	t.Setenv("USERPROFILE", homeDir)

	worktreeDir := filepath.Join(t.TempDir(), "worktree")
	if err := os.MkdirAll(worktreeDir, 0o750); err != nil {
		t.Fatal(err)
	}

	oldWd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = os.Chdir(oldWd) }()
	if err := os.Chdir(worktreeDir); err != nil {
		t.Fatal(err)
	}

	sharedDoltDir := filepath.Join(homeDir, ".beads", "shared-server", "dolt")
	if err := os.MkdirAll(filepath.Join(sharedDoltDir, "project_existing"), 0o750); err != nil {
		t.Fatal(err)
	}

	synthesizedDir := filepath.Join(worktreeDir, ".beads")
	cfg := configfile.DefaultConfig()
	cfg.DoltMode = configfile.DoltModeServer
	cfg.DoltDatabase = "project_existing"

	origCheck := checkBootstrapServerDB
	checkBootstrapServerDB = func(probeCfg bootstrapServerProbeConfig) bootstrapServerDBCheck {
		if probeCfg.database != "project_existing" {
			t.Fatalf("probeCfg.database = %q, want %q", probeCfg.database, "project_existing")
		}
		return bootstrapServerDBCheck{Exists: true, Reachable: true}
	}
	defer func() { checkBootstrapServerDB = origCheck }()

	plan := detectBootstrapAction(synthesizedDir, cfg)

	if plan.Action != "none" {
		t.Fatalf("expected action=%q, got %q: %s", "none", plan.Action, plan.Reason)
	}
	if !plan.HasExisting {
		t.Fatal("expected HasExisting to be true when configured shared-server DB already exists")
	}
}

// TestFinalizeSyncedBootstrapWritesConfigFiles verifies that after a sync
// clone, finalizeSyncedBootstrap writes the metadata.json and config.yaml
// files bd needs to reopen the cloned database. This is the regression
// guard for GH#3201: executeSyncAction previously left the workspace
// without these files, causing "no beads configuration found" and
// "Error 1105: no database selected" on every subsequent bd command.
func TestFinalizeSyncedBootstrapWritesConfigFiles(t *testing.T) {
	t.Setenv("BEADS_DOLT_DATA_DIR", "")
	t.Setenv("BEADS_DOLT_SERVER_DATABASE", "")
	t.Setenv("BEADS_DOLT_SERVER_HOST", "")
	t.Setenv("BEADS_DOLT_SERVER_PORT", "")
	t.Setenv("BEADS_DOLT_SERVER_MODE", "")
	t.Setenv("BEADS_DOLT_SHARED_SERVER", "")

	tmpDir := t.TempDir()
	beadsDir := filepath.Join(tmpDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0o750); err != nil {
		t.Fatal(err)
	}
	// Simulate a post-clone workspace: cloneFromRemote created the
	// embeddeddolt directory but no metadata.json / config.yaml exists.
	if err := os.MkdirAll(filepath.Join(beadsDir, "embeddeddolt"), 0o750); err != nil {
		t.Fatal(err)
	}

	// Point findProjectConfigYaml at the test workspace instead of walking
	// up from CWD, so the sync.remote write lands in the right file even
	// when the test runs from an unrelated directory.
	t.Setenv("BEADS_DIR", beadsDir)

	const dbName = "beads_hq"
	const syncRemote = "file:///tmp/fake-origin.git"

	cfg := configfile.DefaultConfig()
	if err := finalizeSyncedBootstrap(beadsDir, syncRemote, cfg, dbName); err != nil {
		t.Fatalf("finalizeSyncedBootstrap failed: %v", err)
	}

	// metadata.json must exist and record the database name bd needs to
	// reopen the cloned data. Without this, GetDoltDatabase() falls back to
	// DefaultDoltDatabase ("beads") and the cloned DB is unreachable.
	loaded, err := configfile.Load(beadsDir)
	if err != nil {
		t.Fatalf("configfile.Load after finalize failed: %v", err)
	}
	if loaded == nil {
		t.Fatal("configfile.Load returned nil; metadata.json was not written")
	}
	if loaded.GetDoltDatabase() != dbName {
		t.Errorf("dolt_database = %q, want %q", loaded.GetDoltDatabase(), dbName)
	}
	if loaded.GetDoltMode() != configfile.DoltModeEmbedded {
		t.Errorf("dolt_mode = %q, want %q", loaded.GetDoltMode(), configfile.DoltModeEmbedded)
	}
	if loaded.GetBackend() != configfile.BackendDolt {
		t.Errorf("backend = %q, want %q", loaded.GetBackend(), configfile.BackendDolt)
	}

	// config.yaml must exist so GetYamlConfig / SetYamlConfig and other
	// yaml-backed settings (sync.remote, dolt.shared-server, etc.) work.
	configYamlPath := filepath.Join(beadsDir, "config.yaml")
	yamlBytes, err := os.ReadFile(configYamlPath)
	if err != nil {
		t.Fatalf("config.yaml missing after finalize: %v", err)
	}
	yaml := string(yamlBytes)

	// sync.remote must be persisted so subsequent fresh clones (and
	// bootstrap retries) can rediscover the remote without re-probing
	// origin refs.
	//
	// Asserted by READING it back rather than by matching a spelling. This used
	// to require a literal `sync.remote: ` line, which is a key whose name
	// contains a dot — the shape config.GetStringFromDir and viper can never
	// find, because both split on the dot and walk nested mappings. The writer
	// now nests (bd-zj95), so the old assertion passed for exactly as long as
	// the value was unreadable and failed the moment it became readable. What
	// bootstrap owes its caller is a remote that can be read back, so that is
	// what this checks.
	if got := config.GetStringFromDir(beadsDir, "sync.remote"); got != syncRemote {
		t.Errorf("config.GetStringFromDir(%q, \"sync.remote\") = %q, want %q:\n%s",
			beadsDir, got, syncRemote, yaml)
	}
	if !strings.Contains(yaml, syncRemote) {
		t.Errorf("config.yaml does not contain sync remote URL %q:\n%s", syncRemote, yaml)
	}

	gitignoreBytes, err := os.ReadFile(filepath.Join(beadsDir, ".gitignore"))
	if err != nil {
		t.Fatalf(".beads/.gitignore missing after finalize: %v", err)
	}
	gitignore := string(gitignoreBytes)
	for _, pattern := range []string{".local_version", "backup/", "export-state.json", "last-touched"} {
		if !strings.Contains(gitignore, pattern) {
			t.Errorf(".beads/.gitignore missing runtime pattern %q:\n%s", pattern, gitignore)
		}
	}
}

func TestFinalizeSyncedBootstrap_WorktreeStubDoesNotShadowTargetConfig(t *testing.T) {
	snapshotBootstrapEnv(t)

	config.ResetForTesting()
	defer config.ResetForTesting()

	originBare := filepath.Join(t.TempDir(), "origin.git")
	runGitForBootstrapTest(t, "", "init", "--bare", "--initial-branch=main", originBare)

	sourceDir := t.TempDir()
	runGitForBootstrapTest(t, sourceDir, "init", "-b", "main")
	runGitForBootstrapTest(t, sourceDir, "config", "user.email", "test@test.com")
	runGitForBootstrapTest(t, sourceDir, "config", "user.name", "Test User")
	runGitForBootstrapTest(t, sourceDir, "commit", "--allow-empty", "-m", "init")
	runGitForBootstrapTest(t, sourceDir, "remote", "add", "origin", originBare)
	runGitForBootstrapTest(t, sourceDir, "push", "origin", "main")

	localBare := filepath.Join(t.TempDir(), "local-bare.git")
	runGitForBootstrapTest(t, "", "clone", "--bare", originBare, localBare)

	worktreeDir := filepath.Join(t.TempDir(), "worktree")
	runGitForBootstrapTest(t, "", "--git-dir="+localBare, "worktree", "add", worktreeDir, "main")

	oldWd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = os.Chdir(oldWd) }()
	if err := os.Chdir(worktreeDir); err != nil {
		t.Fatal(err)
	}

	// Reproduce the failing shape from fix-worktree-config-yaml-resolution:
	// the worktree has a local .beads stub, but bootstrap is finalizing the
	// shared config under the bare/common-dir parent.
	worktreeStubDir := filepath.Join(worktreeDir, ".beads")
	if err := os.MkdirAll(worktreeStubDir, 0o750); err != nil {
		t.Fatal(err)
	}

	targetBeadsDir := filepath.Join(localBare, ".beads")
	if err := os.MkdirAll(filepath.Join(targetBeadsDir, "embeddeddolt"), 0o750); err != nil {
		t.Fatal(err)
	}

	const remoteURL = "git+ssh://git@github.com/example-org/example-app.git"
	cfg := configfile.DefaultConfig()
	if err := finalizeSyncedBootstrap(targetBeadsDir, remoteURL, cfg, "example-org"); err != nil {
		t.Fatalf("finalizeSyncedBootstrap failed: %v", err)
	}

	targetConfigPath := filepath.Join(targetBeadsDir, "config.yaml")
	targetContent, err := os.ReadFile(targetConfigPath)
	if err != nil {
		t.Fatalf("failed to read target config.yaml: %v", err)
	}
	if !strings.Contains(string(targetContent), remoteURL) {
		t.Fatalf("expected target config.yaml to contain %q, got:\n%s", remoteURL, string(targetContent))
	}

	if _, err := os.Stat(filepath.Join(worktreeStubDir, "config.yaml")); !os.IsNotExist(err) {
		t.Fatalf("expected worktree stub config.yaml to remain absent, got err=%v", err)
	}
}

// TestFinalizeSyncedBootstrapIsIdempotent verifies that re-running the
// finalize step over an already-finalized workspace is a no-op — the
// clone retry path relies on this.
func TestFinalizeSyncedBootstrapIsIdempotent(t *testing.T) {
	t.Setenv("BEADS_DOLT_DATA_DIR", "")
	t.Setenv("BEADS_DOLT_SERVER_DATABASE", "")
	t.Setenv("BEADS_DOLT_SERVER_HOST", "")
	t.Setenv("BEADS_DOLT_SERVER_PORT", "")
	t.Setenv("BEADS_DOLT_SERVER_MODE", "")
	t.Setenv("BEADS_DOLT_SHARED_SERVER", "")

	tmpDir := t.TempDir()
	beadsDir := filepath.Join(tmpDir, ".beads")
	if err := os.MkdirAll(filepath.Join(beadsDir, "embeddeddolt"), 0o750); err != nil {
		t.Fatal(err)
	}
	t.Setenv("BEADS_DIR", beadsDir)

	cfg := configfile.DefaultConfig()
	if err := finalizeSyncedBootstrap(beadsDir, "file:///tmp/a.git", cfg, "beads_hq"); err != nil {
		t.Fatalf("first finalize failed: %v", err)
	}

	firstYaml, err := os.ReadFile(filepath.Join(beadsDir, "config.yaml"))
	if err != nil {
		t.Fatalf("read config.yaml after first finalize: %v", err)
	}

	if err := finalizeSyncedBootstrap(beadsDir, "file:///tmp/a.git", cfg, "beads_hq"); err != nil {
		t.Fatalf("second finalize failed: %v", err)
	}

	secondYaml, err := os.ReadFile(filepath.Join(beadsDir, "config.yaml"))
	if err != nil {
		t.Fatalf("read config.yaml after second finalize: %v", err)
	}

	// createConfigYaml skips existing files, so the template portion must
	// be unchanged. SetYamlConfig rewrites in place but should produce the
	// same output for the same value.
	if string(firstYaml) != string(secondYaml) {
		t.Errorf("config.yaml changed on second finalize.\nfirst:\n%s\nsecond:\n%s", firstYaml, secondYaml)
	}

	// metadata.json must still load cleanly.
	loaded, err := configfile.Load(beadsDir)
	if err != nil || loaded == nil {
		t.Fatalf("metadata.json missing after second finalize: %v", err)
	}
	if loaded.GetDoltDatabase() != "beads_hq" {
		t.Errorf("dolt_database drifted: got %q, want %q", loaded.GetDoltDatabase(), "beads_hq")
	}
}

func TestApplyBootstrapMetadataRepair_UsesResolvedConfig(t *testing.T) {
	tmpDir := t.TempDir()
	beadsDir := filepath.Join(tmpDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0o750); err != nil {
		t.Fatal(err)
	}

	origResolve := resolveBootstrapAuthoritativeMetadata
	resolveBootstrapAuthoritativeMetadata = func(path string, apply bool) (*configfile.Config, string, error) {
		if path != tmpDir {
			t.Fatalf("path = %q, want %q", path, tmpDir)
		}
		if !apply {
			t.Fatal("expected apply=true")
		}
		return &configfile.Config{DoltMode: configfile.DoltModeServer, DoltDatabase: "canonical_db"}, "repaired dolt_database", nil
	}
	defer func() { resolveBootstrapAuthoritativeMetadata = origResolve }()

	resolved, msg, err := applyBootstrapMetadataRepair(beadsDir, configfile.DefaultConfig(), true)
	if err != nil {
		t.Fatalf("applyBootstrapMetadataRepair failed: %v", err)
	}
	if resolved == nil {
		t.Fatal("resolved config is nil")
	}
	if resolved.GetDoltDatabase() != "canonical_db" {
		t.Fatalf("GetDoltDatabase() = %q, want %q", resolved.GetDoltDatabase(), "canonical_db")
	}
	if msg != "repaired dolt_database" {
		t.Fatalf("msg = %q, want %q", msg, "repaired dolt_database")
	}
}

// TestCloneFromRemoteRoutesToServerMode verifies that cloneFromRemote uses
// the SQL server path (not filesystem clone) when ResolveServerMode
// detects external server mode from metadata.json. GH#3343.
func TestCloneFromRemoteRoutesToServerMode(t *testing.T) {
	t.Setenv("BEADS_DOLT_DATA_DIR", "")
	t.Setenv("BEADS_DOLT_SERVER_DATABASE", "")
	t.Setenv("BEADS_DOLT_SERVER_HOST", "")
	t.Setenv("BEADS_DOLT_SERVER_PORT", "")
	t.Setenv("BEADS_DOLT_SERVER_MODE", "")
	t.Setenv("BEADS_DOLT_SHARED_SERVER", "")

	tmpDir2 := t.TempDir()
	beadsDir2 := filepath.Join(tmpDir2, ".beads")
	if err := os.MkdirAll(beadsDir2, 0o750); err != nil {
		t.Fatal(err)
	}

	// Write metadata.json with server mode and explicit port — this makes
	// ResolveServerMode return ServerModeExternal.
	cfg := &configfile.Config{
		DoltMode:       configfile.DoltModeServer,
		DoltServerHost: "127.0.0.1",
		DoltServerPort: 3308,
		DoltDatabase:   "beads_proj",
	}
	if err := cfg.Save(beadsDir2); err != nil {
		t.Fatalf("save metadata.json: %v", err)
	}

	// cloneFromRemote should attempt a server connection (not a filesystem
	// clone). Since no server is running, we expect a connection error —
	// NOT a "dolt clone failed" error, which would indicate the filesystem
	// path was taken.
	err := cloneFromRemote(t.Context(), beadsDir2, "file:///tmp/nonexistent.git", "beads_proj", cfg)
	if err == nil {
		t.Fatal("expected error (no server running), got nil")
	}
	errMsg := err.Error()

	// The error should indicate a server connection attempt, not a CLI clone.
	if strings.Contains(errMsg, "dolt clone failed") {
		t.Errorf("cloneFromRemote used filesystem clone path in server mode: %v", err)
	}
	if !strings.Contains(errMsg, "server") {
		t.Errorf("expected server-related error, got: %v", err)
	}

	// Verify no local dolt directory was created.
	doltDir := filepath.Join(beadsDir2, "dolt")
	if _, err := os.Stat(doltDir); err == nil {
		t.Errorf("local .beads/dolt/ directory was created — clone should have gone to server, not filesystem")
	}
}

// TestCloneFromRemoteRoutesToServerModeViaEnv verifies that the
// BEADS_DOLT_SERVER_MODE=1 env var triggers the server clone path,
// even when metadata.json is absent.
func TestCloneFromRemoteRoutesToServerModeViaEnv(t *testing.T) {
	t.Setenv("BEADS_DOLT_DATA_DIR", "")
	t.Setenv("BEADS_DOLT_SERVER_DATABASE", "")
	t.Setenv("BEADS_DOLT_SERVER_HOST", "")
	t.Setenv("BEADS_DOLT_SERVER_PORT", "")
	t.Setenv("BEADS_DOLT_SERVER_MODE", "1")
	t.Setenv("BEADS_DOLT_SHARED_SERVER", "")

	tmpDir := t.TempDir()
	beadsDir := filepath.Join(tmpDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0o750); err != nil {
		t.Fatal(err)
	}

	cfg := &configfile.Config{
		DoltServerHost: "127.0.0.1",
		DoltServerPort: 3309,
		DoltDatabase:   "beads_env",
	}

	err := cloneFromRemote(t.Context(), beadsDir, "file:///tmp/nonexistent.git", "beads_env", cfg)
	if err == nil {
		t.Fatal("expected error (no server running), got nil")
	}
	if strings.Contains(err.Error(), "dolt clone failed") {
		t.Errorf("cloneFromRemote used filesystem clone path despite BEADS_DOLT_SERVER_MODE=1: %v", err)
	}
	if !strings.Contains(err.Error(), "server") {
		t.Errorf("expected server-related error, got: %v", err)
	}
}

// TestCloneFromRemoteExternalNilCfgLoadsDisk verifies that when cfg is nil
// in external server mode, cloneFromRemote falls back to loading config
// from metadata.json on disk.
func TestCloneFromRemoteExternalNilCfgLoadsDisk(t *testing.T) {
	t.Setenv("BEADS_DOLT_DATA_DIR", "")
	t.Setenv("BEADS_DOLT_SERVER_DATABASE", "")
	t.Setenv("BEADS_DOLT_SERVER_HOST", "")
	t.Setenv("BEADS_DOLT_SERVER_PORT", "")
	t.Setenv("BEADS_DOLT_SERVER_MODE", "")
	t.Setenv("BEADS_DOLT_SHARED_SERVER", "")

	tmpDir := t.TempDir()
	beadsDir := filepath.Join(tmpDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0o750); err != nil {
		t.Fatal(err)
	}

	// Write metadata.json to disk with server mode — but pass nil cfg.
	diskCfg := &configfile.Config{
		DoltMode:       configfile.DoltModeServer,
		DoltServerHost: "127.0.0.1",
		DoltServerPort: 3310,
		DoltDatabase:   "beads_disk",
	}
	if err := diskCfg.Save(beadsDir); err != nil {
		t.Fatalf("save metadata.json: %v", err)
	}

	// Pass nil cfg — cloneFromRemote should load from disk and still
	// take the server path.
	err := cloneFromRemote(t.Context(), beadsDir, "file:///tmp/nonexistent.git", "beads_disk", nil)
	if err == nil {
		t.Fatal("expected error (no server running), got nil")
	}
	if strings.Contains(err.Error(), "dolt clone failed") {
		t.Errorf("nil-cfg path used filesystem clone despite server metadata on disk: %v", err)
	}
	if !strings.Contains(err.Error(), "server") {
		t.Errorf("expected server-related error, got: %v", err)
	}
}

// TestCloneFromRemoteOwnedModeUsesCLI verifies that owned-server mode
// (the default when no metadata.json exists) uses the CLI clone path.
func TestCloneFromRemoteOwnedModeUsesCLI(t *testing.T) {
	t.Setenv("BEADS_DOLT_DATA_DIR", "")
	t.Setenv("BEADS_DOLT_SERVER_DATABASE", "")
	t.Setenv("BEADS_DOLT_SERVER_HOST", "")
	t.Setenv("BEADS_DOLT_SERVER_PORT", "")
	t.Setenv("BEADS_DOLT_SERVER_MODE", "")
	t.Setenv("BEADS_DOLT_SHARED_SERVER", "")

	tmpDir := t.TempDir()
	beadsDir := filepath.Join(tmpDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0o750); err != nil {
		t.Fatal(err)
	}

	// No metadata.json → ResolveServerMode returns ServerModeOwned → CLI path.
	// The CLI path calls BootstrapFromRemoteWithDB, which requires dolt CLI.
	// Since dolt may not be installed in CI, we accept either:
	// - "dolt CLI not found" (no dolt binary)
	// - "dolt clone failed" (dolt binary exists but remote is invalid)
	// Both confirm the CLI path was taken, not the server path.
	err := cloneFromRemote(t.Context(), beadsDir, "file:///tmp/nonexistent.git", "beads_owned", nil)
	if err == nil {
		// BootstrapFromRemoteWithDB returns (false, nil) if doltExists — skip.
		return
	}
	errMsg := err.Error()
	if strings.Contains(errMsg, "dolt server unreachable") || strings.Contains(errMsg, "connect to dolt server") {
		t.Errorf("owned-mode clone routed to server path: %v", err)
	}
}

func TestResolveRemoteCloneModeDefaultConfigUsesEmbedded(t *testing.T) {
	t.Setenv("BEADS_DOLT_DATA_DIR", "")
	t.Setenv("BEADS_DOLT_SERVER_DATABASE", "")
	t.Setenv("BEADS_DOLT_SERVER_HOST", "")
	t.Setenv("BEADS_DOLT_SERVER_PORT", "")
	t.Setenv("BEADS_DOLT_SERVER_MODE", "")
	t.Setenv("BEADS_DOLT_SHARED_SERVER", "")

	beadsDir := filepath.Join(t.TempDir(), ".beads")
	cfg := configfile.DefaultConfig()

	got := resolveRemoteCloneMode(beadsDir, cfg, remoteCloneAuto)
	if got != remoteCloneEmbedded {
		t.Fatalf("resolveRemoteCloneMode(default cfg) = %v, want embedded", got)
	}
}

func TestResolveRemoteCloneModeExplicitExternalOverridesMissingMetadata(t *testing.T) {
	t.Setenv("BEADS_DOLT_DATA_DIR", "")
	t.Setenv("BEADS_DOLT_SERVER_DATABASE", "")
	t.Setenv("BEADS_DOLT_SERVER_HOST", "")
	t.Setenv("BEADS_DOLT_SERVER_PORT", "")
	t.Setenv("BEADS_DOLT_SERVER_MODE", "")
	t.Setenv("BEADS_DOLT_SHARED_SERVER", "")

	beadsDir := filepath.Join(t.TempDir(), ".beads")
	cfg := &configfile.Config{
		DoltMode:       configfile.DoltModeServer,
		DoltServerHost: "127.0.0.1",
		DoltServerPort: 3312,
		DoltDatabase:   "beads_external",
	}

	got := resolveRemoteCloneMode(beadsDir, cfg, remoteCloneExternalServer)
	if got != remoteCloneExternalServer {
		t.Fatalf("resolveRemoteCloneMode(explicit external) = %v, want external server", got)
	}
}

// TestCloneFromRemoteSharedServerModeUsesServer verifies that
// BEADS_DOLT_SHARED_SERVER=1 triggers the server clone path.
func TestCloneFromRemoteSharedServerModeUsesServer(t *testing.T) {
	t.Setenv("BEADS_DOLT_DATA_DIR", "")
	t.Setenv("BEADS_DOLT_SERVER_DATABASE", "")
	t.Setenv("BEADS_DOLT_SERVER_HOST", "")
	t.Setenv("BEADS_DOLT_SERVER_PORT", "")
	t.Setenv("BEADS_DOLT_SERVER_MODE", "")
	t.Setenv("BEADS_DOLT_SHARED_SERVER", "1")

	tmpDir := t.TempDir()
	beadsDir := filepath.Join(tmpDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0o750); err != nil {
		t.Fatal(err)
	}

	cfg := &configfile.Config{
		DoltServerHost: "127.0.0.1",
		DoltServerPort: 3311,
		DoltDatabase:   "beads_shared",
	}

	err := cloneFromRemote(t.Context(), beadsDir, "file:///tmp/nonexistent.git", "beads_shared", cfg)
	if err == nil {
		t.Fatal("expected error (no server running), got nil")
	}
	if strings.Contains(err.Error(), "dolt clone failed") {
		t.Errorf("shared-server mode used filesystem clone: %v", err)
	}
	if !strings.Contains(err.Error(), "server") {
		t.Errorf("expected server-related error, got: %v", err)
	}
}

// TestFinalizeSyncedBootstrapSharedServerSetsServerMode verifies that
// finalizeSyncedBootstrap writes dolt_mode=server when shared-server
// mode is active via env var.
func TestFinalizeSyncedBootstrapSharedServerSetsServerMode(t *testing.T) {
	t.Setenv("BEADS_DOLT_DATA_DIR", "")
	t.Setenv("BEADS_DOLT_SERVER_DATABASE", "")
	t.Setenv("BEADS_DOLT_SERVER_HOST", "")
	t.Setenv("BEADS_DOLT_SERVER_PORT", "")
	t.Setenv("BEADS_DOLT_SERVER_MODE", "")
	t.Setenv("BEADS_DOLT_SHARED_SERVER", "1")

	tmpDir := t.TempDir()
	beadsDir := filepath.Join(tmpDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0o750); err != nil {
		t.Fatal(err)
	}
	t.Setenv("BEADS_DIR", beadsDir)

	cfg := configfile.DefaultConfig()
	if err := finalizeSyncedBootstrap(beadsDir, "file:///tmp/fake.git", cfg, "beads_shared"); err != nil {
		t.Fatalf("finalizeSyncedBootstrap failed: %v", err)
	}

	loaded, err := configfile.Load(beadsDir)
	if err != nil || loaded == nil {
		t.Fatalf("metadata.json missing: %v", err)
	}
	if loaded.GetDoltMode() != configfile.DoltModeServer {
		t.Errorf("dolt_mode = %q, want %q — shared server should set server mode", loaded.GetDoltMode(), configfile.DoltModeServer)
	}
}

// TestDetectBootstrapAction_NoLocalShadowDirStillLiveChecksExisting reproduces
// be-cy41 bug #1: existingBootstrapDBPlan returned BootstrapPlan{}, false (and
// detectBootstrapAction fell through toward Action="init") purely because no
// local shadow dolt-data directory existed — but in server mode that is the
// NORMAL state for a fresh clone of an already-initialized project. When
// metadata.json carries a ProjectID (proving this workspace was previously
// initialized), the server-side existence check must still run instead of
// being short-circuited by local filesystem state that a legitimate clone
// will never have (the same ambiguity PR #5791 addresses for bd init; that
// PR is open and not yet merged, so nothing it adds is referenced here).
func TestDetectBootstrapAction_NoLocalShadowDirStillLiveChecksExisting(t *testing.T) {
	t.Setenv("BEADS_DOLT_DATA_DIR", "")
	t.Setenv("BEADS_DOLT_SHARED_SERVER", "")
	t.Setenv("BEADS_DOLT_SERVER_DATABASE", "")
	t.Setenv("BEADS_DOLT_SERVER_HOST", "")
	t.Setenv("BEADS_DOLT_SERVER_PORT", "")
	tmpDir := t.TempDir()
	beadsDir := filepath.Join(tmpDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0o750); err != nil {
		t.Fatal(err)
	}
	// Deliberately do NOT create doltDataDir at all — no local shadow
	// directory, which is the normal state for a fresh clone of a
	// pre-existing server-mode project.
	doltDataDir := filepath.Join(tmpDir, "dolt-data")

	oldWd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = os.Chdir(oldWd) }()
	if err := os.Chdir(tmpDir); err != nil {
		t.Fatal(err)
	}

	cfg := configfile.DefaultConfig()
	cfg.DoltMode = configfile.DoltModeServer
	cfg.DoltDatabase = "project_exists"
	cfg.DoltDataDir = doltDataDir
	cfg.ProjectID = "proj-already-initialized-456"
	t.Setenv("BEADS_DOLT_DATA_DIR", doltDataDir)

	probed := false
	origCheck := checkBootstrapServerDB
	checkBootstrapServerDB = func(probeCfg bootstrapServerProbeConfig) bootstrapServerDBCheck {
		probed = true
		if probeCfg.database != "project_exists" {
			t.Fatalf("unexpected dbName: %s", probeCfg.database)
		}
		return bootstrapServerDBCheck{Exists: true, Reachable: true}
	}
	defer func() { checkBootstrapServerDB = origCheck }()
	origDelay := bootstrapRetryDelay
	bootstrapRetryDelay = func(time.Duration) {}
	defer func() { bootstrapRetryDelay = origDelay }()

	plan := detectBootstrapAction(beadsDir, cfg)

	if !probed {
		t.Fatal("checkBootstrapServerDB was never called — a local-shadow-directory gate short-circuited the real server-side existence check before it could run")
	}
	if plan.Action != "none" {
		t.Fatalf("action = %q, want %q — bootstrap must not plan to recreate a database that already exists on the server just because no local shadow directory is present", plan.Action, "none")
	}
	if !plan.HasExisting {
		t.Error("HasExisting = false, want true")
	}
}

// TestExecuteInitAction_ServerModeExistingProjectMissingDBRefuses reproduces
// be-cy41 bug #2: executeInitAction is mode-blind — it always builds a
// dolt.Config with CreateIfMissing:true, AutoStart:true, and no server
// host/port/mode fields, so it silently creates an embedded-style database
// even for a server-mode workspace. When the workspace was already
// initialized (metadata.json has a project_id — the same signal PR #5791 uses) but
// the configured database is missing on the server, this silently strands any
// existing issue data behind a new, empty database of the same name.
// executeInitAction must refuse instead (the same root cause as PR #5791's
// proposed bd init guard, which is still open).
func TestExecuteInitAction_ServerModeExistingProjectMissingDBRefuses(t *testing.T) {
	t.Setenv("BEADS_DOLT_DATA_DIR", "")
	t.Setenv("BEADS_DOLT_SHARED_SERVER", "")
	t.Setenv("BEADS_DOLT_SERVER_DATABASE", "")
	t.Setenv("BEADS_DOLT_SERVER_HOST", "")
	t.Setenv("BEADS_DOLT_SERVER_PORT", "")
	tmpDir := t.TempDir()
	beadsDir := filepath.Join(tmpDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0o750); err != nil {
		t.Fatal(err)
	}

	oldWd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	defer func() { _ = os.Chdir(oldWd) }()
	if err := os.Chdir(tmpDir); err != nil {
		t.Fatal(err)
	}

	cfg := configfile.DefaultConfig()
	cfg.DoltMode = configfile.DoltModeServer
	cfg.DoltDatabase = "myproj"
	cfg.ProjectID = "proj-existing-123"

	origCheck := checkBootstrapServerDB
	checkBootstrapServerDB = func(probeCfg bootstrapServerProbeConfig) bootstrapServerDBCheck {
		return bootstrapServerDBCheck{Exists: false, Reachable: true}
	}
	defer func() { checkBootstrapServerDB = origCheck }()
	origDelay := bootstrapRetryDelay
	bootstrapRetryDelay = func(time.Duration) {}
	defer func() { bootstrapRetryDelay = origDelay }()

	plan := BootstrapPlan{BeadsDir: beadsDir, Database: "myproj", Action: "init"}
	err = executeInitAction(context.Background(), plan, cfg)

	if err == nil {
		t.Fatal("executeInitAction succeeded silently for an existing project with a missing server-mode database — want a refusal error")
	}
	if !strings.Contains(err.Error(), "myproj") {
		t.Errorf("error %q does not mention the missing database name %q", err.Error(), "myproj")
	}
	if !strings.Contains(err.Error(), "will NOT create") && !strings.Contains(err.Error(), "not found on server") {
		t.Errorf("error %q does not read as a refusal to auto-create", err.Error())
	}
	if _, statErr := os.Stat(filepath.Join(beadsDir, "embeddeddolt")); statErr == nil {
		t.Error("executeInitAction created an embedded database as a side effect of a refused server-mode init — no database should have been created at all")
	}
}

// freshServerModeCloneFixture builds the state a fresh clone of an
// already-bootstrapped server-mode project is actually in: .beads/ present
// with a configured sync.remote, metadata.json carrying a ProjectID, and no
// local shadow dolt-data directory (a clone never has one).
func freshServerModeCloneFixture(t *testing.T) (beadsDir string, cfg *configfile.Config) {
	t.Helper()
	snapshotBootstrapEnv(t)
	config.ResetForTesting()
	t.Cleanup(config.ResetForTesting)
	t.Setenv("BEADS_DOLT_SHARED_SERVER", "")
	t.Setenv("BEADS_DOLT_SERVER_HOST", "")
	t.Setenv("BEADS_DOLT_SERVER_PORT", "")
	tmpDir := t.TempDir()
	beadsDir = filepath.Join(tmpDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0o750); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(beadsDir, "config.yaml"), []byte("sync.remote: http://myserver:7007/mydb\n"), 0o644); err != nil {
		t.Fatal(err)
	}
	t.Setenv("BEADS_DIR", beadsDir)
	t.Setenv("BEADS_TEST_IGNORE_REPO_CONFIG", "1")
	if err := config.Initialize(); err != nil {
		t.Fatalf("config.Initialize failed: %v", err)
	}
	t.Chdir(tmpDir)
	cfg = configfile.DefaultConfig()
	cfg.DoltMode = configfile.DoltModeServer
	cfg.DoltDatabase = "mydb"
	cfg.DoltDataDir = filepath.Join(tmpDir, "dolt-data") // never created: fresh clone
	cfg.ProjectID = "proj-fresh-clone-789"
	t.Setenv("BEADS_DOLT_DATA_DIR", cfg.DoltDataDir)
	return beadsDir, cfg
}

// TestDetectBootstrapAction_FreshCloneUnreachableServerStillSyncs pins the
// rule that an unverifiable probe means UNKNOWN, not "exists". A fresh clone
// of a locally-managed server-mode project has nothing running yet, so
// "connection refused" is its NORMAL state — it must not be converted into
// Action="none" ("nothing to do"), which would hide sync.remote,
// refs/dolt/data, .beads/backup/ and issues.jsonl behind a dead server.
func TestDetectBootstrapAction_FreshCloneUnreachableServerStillSyncs(t *testing.T) {
	beadsDir, cfg := freshServerModeCloneFixture(t)
	orig := checkBootstrapServerDB
	checkBootstrapServerDB = func(bootstrapServerProbeConfig) bootstrapServerDBCheck {
		return bootstrapServerDBCheck{Reachable: false, Err: errors.New("dial tcp 127.0.0.1:3307: connect: connection refused")}
	}
	defer func() { checkBootstrapServerDB = orig }()
	origDelay := bootstrapRetryDelay
	bootstrapRetryDelay = func(time.Duration) {}
	defer func() { bootstrapRetryDelay = origDelay }()

	plan := detectBootstrapAction(beadsDir, cfg)
	if plan.Action != "sync" {
		t.Errorf("action = %q (reason %q), want sync: an unreachable server must not veto sync.remote recovery on a fresh clone", plan.Action, plan.Reason)
	}
}

// TestDetectBootstrapAction_FreshCloneReachableAbsentSkipsTransientBackoff
// pins that the 10/20/40s transient-restart budget is only spent when a local
// shadow directory says the database really does live here. A fresh clone has
// no shadow directory by design, so "reachable but absent" is simply "not
// synced yet" and must cost one probe, not 70 seconds.
func TestDetectBootstrapAction_FreshCloneReachableAbsentSkipsTransientBackoff(t *testing.T) {
	beadsDir, cfg := freshServerModeCloneFixture(t)
	probes := 0
	orig := checkBootstrapServerDB
	checkBootstrapServerDB = func(bootstrapServerProbeConfig) bootstrapServerDBCheck {
		probes++
		return bootstrapServerDBCheck{Reachable: true, Exists: false}
	}
	defer func() { checkBootstrapServerDB = orig }()
	var slept time.Duration
	origDelay := bootstrapRetryDelay
	bootstrapRetryDelay = func(d time.Duration) { slept += d }
	defer func() { bootstrapRetryDelay = origDelay }()

	plan := detectBootstrapAction(beadsDir, cfg)
	if plan.Action != "sync" {
		t.Errorf("action = %q, want sync", plan.Action)
	}
	if slept > 0 {
		t.Errorf("fresh clone with no local DB paid %v of transient-restart backoff before sync", slept)
	}
	if probes != 1 {
		t.Errorf("probes = %d, want exactly 1 — a clone with no local shadow dir has nothing to be transiently missing", probes)
	}
}

// TestDetectBootstrapAction_ShadowDirUnreachableServerStillReportsNone pins
// the other side of that rule: with a populated local shadow directory there
// IS local evidence the database lives here, so an unreachable server is a
// live database we cannot see right now and "nothing to do" remains the
// correct answer. This is main's long-standing behavior and must survive the
// narrowing above.
func TestDetectBootstrapAction_ShadowDirUnreachableServerStillReportsNone(t *testing.T) {
	beadsDir, cfg := freshServerModeCloneFixture(t)
	if err := os.MkdirAll(filepath.Join(cfg.DoltDataDir, "mydb"), 0o750); err != nil {
		t.Fatal(err)
	}
	orig := checkBootstrapServerDB
	checkBootstrapServerDB = func(bootstrapServerProbeConfig) bootstrapServerDBCheck {
		return bootstrapServerDBCheck{Reachable: false, Err: errors.New("dial tcp 127.0.0.1:3307: connect: connection refused")}
	}
	defer func() { checkBootstrapServerDB = orig }()
	origDelay := bootstrapRetryDelay
	bootstrapRetryDelay = func(time.Duration) {}
	defer func() { bootstrapRetryDelay = origDelay }()

	plan := detectBootstrapAction(beadsDir, cfg)
	if plan.Action != "none" {
		t.Errorf("action = %q, want none — a populated shadow dir is local evidence the DB exists, so a down server means 'do nothing', not 'recover'", plan.Action)
	}
	if !strings.Contains(plan.Reason, "Could not verify") {
		t.Errorf("reason = %q, want the 'Could not verify' wording", plan.Reason)
	}
}

// TestDetectBootstrapAction_ExistingProjectMissingServerDBRefusesAtPlanTime
// pins that the refusal is a PLAN, not an execute-time surprise. With every
// recovery source absent the fall-through would be a fresh, empty database;
// because metadata.json proves the workspace was already initialized, the
// plan itself must say "refuse" so --dry-run and --json report it and
// printBootstrapPlan never advertises "will create fresh database".
func TestDetectBootstrapAction_ExistingProjectMissingServerDBRefusesAtPlanTime(t *testing.T) {
	snapshotBootstrapEnv(t)
	config.ResetForTesting()
	t.Cleanup(config.ResetForTesting)
	t.Setenv("BEADS_DOLT_SHARED_SERVER", "")
	t.Setenv("BEADS_DOLT_SERVER_HOST", "")
	t.Setenv("BEADS_DOLT_SERVER_PORT", "")
	tmpDir := t.TempDir()
	beadsDir := filepath.Join(tmpDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0o750); err != nil {
		t.Fatal(err)
	}
	// No sync.remote, no backup, no issues.jsonl: nothing to recover from.
	t.Setenv("BEADS_DIR", beadsDir)
	t.Setenv("BEADS_TEST_IGNORE_REPO_CONFIG", "1")
	if err := config.Initialize(); err != nil {
		t.Fatalf("config.Initialize failed: %v", err)
	}
	t.Chdir(tmpDir)
	cfg := configfile.DefaultConfig()
	cfg.DoltMode = configfile.DoltModeServer
	cfg.DoltDatabase = "mydb"
	cfg.DoltDataDir = filepath.Join(tmpDir, "dolt-data")
	cfg.ProjectID = "proj-already-initialized-456"
	t.Setenv("BEADS_DOLT_DATA_DIR", cfg.DoltDataDir)

	probes := 0
	orig := checkBootstrapServerDB
	checkBootstrapServerDB = func(bootstrapServerProbeConfig) bootstrapServerDBCheck {
		probes++
		return bootstrapServerDBCheck{Reachable: true, Exists: false}
	}
	defer func() { checkBootstrapServerDB = orig }()
	origDelay := bootstrapRetryDelay
	bootstrapRetryDelay = func(time.Duration) {}
	defer func() { bootstrapRetryDelay = origDelay }()

	plan := detectBootstrapAction(beadsDir, cfg)

	if plan.Action != "refuse" {
		t.Fatalf("action = %q (reason %q), want refuse — an already-initialized workspace must never plan a fresh empty database", plan.Action, plan.Reason)
	}
	if probes != 1 {
		t.Errorf("probes = %d, want exactly 1 — the refusal must reuse the plan-time probe, not dial again", probes)
	}
	if !strings.Contains(plan.Reason, "mydb") {
		t.Errorf("reason = %q does not name the database", plan.Reason)
	}
	if strings.Contains(plan.Reason, "\x1b[") {
		t.Errorf("reason = %q carries ANSI escapes; --json consumers must get plain text", plan.Reason)
	}
	if plan.refusalDetail == "" {
		t.Error("refusalDetail is empty — the operator-facing explanation is lost")
	}
	if !strings.Contains(plan.refusalDetail, "will NOT create") {
		t.Errorf("refusalDetail = %q does not read as a refusal", plan.refusalDetail)
	}

	// The machine-readable surface is what provisioning scripts consume, and
	// "blocked" — not the action string — is the discriminator they are
	// documented to switch on (see the BootstrapPlan.Blocked comment). A
	// refusal produced no database, so it must carry the flag; otherwise it is
	// the one no-database outcome a "blocked"-keyed consumer reads as success.
	if !plan.Blocked {
		t.Error("Blocked = false on a refuse plan — a run that produced no database must set the flag scripts key on")
	}
	raw, err := json.Marshal(plan)
	if err != nil {
		t.Fatalf("json.Marshal(plan): %v", err)
	}
	var decoded map[string]any
	if err := json.Unmarshal(raw, &decoded); err != nil {
		t.Fatalf("unmarshal plan JSON %s: %v", raw, err)
	}
	if decoded["action"] != "refuse" {
		t.Errorf("json action = %v, want refuse", decoded["action"])
	}
	// "blocked" is omitempty, so a false flag does not render as false — the
	// key vanishes entirely and the consumer cannot tell this run from a
	// successful one.
	if decoded["blocked"] != true {
		t.Errorf("json blocked = %v, want true; full plan JSON: %s", decoded["blocked"], raw)
	}
	if strings.Contains(string(raw), "\x1b[") {
		t.Errorf("plan JSON carries ANSI escapes, which --json consumers must never receive: %s", raw)
	}
}

// TestDetectBootstrapAction_RefusePlanDropsUnverifiedSyncRemote pins that a
// refusal honours SyncRemote's documented "empty on a Blocked plan" contract.
// A forge sync.remote with no Dolt data yet is recorded on the plan for the
// workspace bootstrap expected to create (planConfiguredSyncRemote keeps it
// and returns done=false), and the refusal is downstream of that — so without
// explicit clearing the credential-bearing URL rides out in --json for a run
// that wired up nothing, cloned nothing and pushed nothing.
func TestDetectBootstrapAction_RefusePlanDropsUnverifiedSyncRemote(t *testing.T) {
	beadsDir := newForgeSyncRemoteWorkspace(t, "https://github.com/org/repo.git")
	// Forge repo reachable, but no refs/dolt/data yet: sync.remote is recorded
	// and bootstrap keeps looking rather than cloning.
	stubProbeGitRemoteDoltData(t, func(string) (bool, error) { return false, nil })

	cfg := configfile.DefaultConfig()
	cfg.DoltMode = configfile.DoltModeServer
	cfg.DoltDatabase = "mydb"
	// Never created: a fresh clone has no local shadow directory.
	cfg.DoltDataDir = filepath.Join(filepath.Dir(beadsDir), "dolt-data")
	cfg.ProjectID = "proj-already-initialized-456"
	t.Setenv("BEADS_DOLT_DATA_DIR", cfg.DoltDataDir)

	orig := checkBootstrapServerDB
	checkBootstrapServerDB = func(bootstrapServerProbeConfig) bootstrapServerDBCheck {
		return bootstrapServerDBCheck{Reachable: true, Exists: false}
	}
	defer func() { checkBootstrapServerDB = orig }()
	origDelay := bootstrapRetryDelay
	bootstrapRetryDelay = func(time.Duration) {}
	defer func() { bootstrapRetryDelay = origDelay }()

	plan := detectBootstrapAction(beadsDir, cfg)

	if plan.Action != "refuse" {
		t.Fatalf("action = %q (reason %q), want refuse", plan.Action, plan.Reason)
	}
	if !plan.Blocked {
		t.Fatal("Blocked = false on a refuse plan")
	}
	if plan.SyncRemote != "" {
		t.Errorf("SyncRemote = %q on a Blocked plan, want empty — the refusal creates no workspace, so nothing may be cloned from or pushed to that remote", plan.SyncRemote)
	}
	raw, err := json.Marshal(plan)
	if err != nil {
		t.Fatalf("json.Marshal(plan): %v", err)
	}
	var decoded map[string]any
	if err := json.Unmarshal(raw, &decoded); err != nil {
		t.Fatalf("unmarshal plan JSON %s: %v", raw, err)
	}
	if got, ok := decoded["sync_remote"]; ok {
		t.Errorf("plan JSON carries sync_remote = %v on a Blocked plan; full JSON: %s", got, raw)
	}
}

// TestPrintBootstrapPlan_RefusePrintsSummaryNotDetail covers the refuse arm of
// printBootstrapPlan, which no test reached. The full explanation is the error
// executeBootstrapPlan returns, so printing refusalDetail here too would render
// it twice — a regression a future edit could reintroduce silently.
func TestPrintBootstrapPlan_RefusePrintsSummaryNotDetail(t *testing.T) {
	plan := BootstrapPlan{
		Action:   "refuse",
		Database: "mydb",
		Reason:   `Database "mydb" not found on server at 127.0.0.1:3307; workspace already initialized (project_id set) — refusing to create an empty database`,
		// A marker no production string can produce, so a match is proof the
		// detail field itself was printed rather than wording that overlaps.
		refusalDetail: "REFUSAL-DETAIL-MARKER: bd bootstrap will NOT create an empty database here",
		Blocked:       true,
	}

	out := captureStdout(t, func() error {
		printBootstrapPlan(plan)
		return nil
	})

	if !strings.Contains(out, "refuse — will NOT create a database") {
		t.Errorf("output does not announce the refusal:\n%s", out)
	}
	if !strings.Contains(out, plan.Reason) {
		t.Errorf("output omits the one-line reason:\n%s", out)
	}
	if strings.Contains(out, "REFUSAL-DETAIL-MARKER") {
		t.Errorf("printBootstrapPlan printed refusalDetail; executeBootstrapPlan already returns it, so the operator would read the whole explanation twice:\n%s", out)
	}
}

// TestExecuteBootstrapPlan_RefuseErrsWithoutPrompting pins that a refuse plan
// never reaches confirmPrompt or the workspace gates: it is a decision, not an
// action awaiting approval. Before this, the refusal was discovered inside
// executeInitAction — i.e. after the operator had already answered "Proceed?"
// to a plan that said the opposite.
func TestExecuteBootstrapPlan_RefuseErrsWithoutPrompting(t *testing.T) {
	snapshotBootstrapEnv(t)
	config.ResetForTesting()
	t.Cleanup(config.ResetForTesting)
	tmpDir := t.TempDir()
	beadsDir := filepath.Join(tmpDir, ".beads")
	if err := os.MkdirAll(beadsDir, 0o750); err != nil {
		t.Fatal(err)
	}
	cfg := configfile.DefaultConfig()
	cfg.DoltMode = configfile.DoltModeServer
	cfg.DoltDatabase = "mydb"
	cfg.ProjectID = "proj-existing-123"

	probes := 0
	orig := checkBootstrapServerDB
	checkBootstrapServerDB = func(bootstrapServerProbeConfig) bootstrapServerDBCheck {
		probes++
		return bootstrapServerDBCheck{Reachable: true, Exists: false}
	}
	defer func() { checkBootstrapServerDB = orig }()

	plan := BootstrapPlan{
		BeadsDir:      beadsDir,
		Database:      "mydb",
		Action:        "refuse",
		Reason:        "short summary",
		refusalDetail: "long refusal: bd bootstrap will NOT create an empty database here",
	}
	// nonInteractive=false so a confirmPrompt would be reached if one ran.
	err := executeBootstrapPlan(plan, cfg, false)
	if err == nil {
		t.Fatal("executeBootstrapPlan returned nil for a refuse plan — bootstrap would exit 0 having done nothing, hiding the refusal")
	}
	if !strings.Contains(err.Error(), "will NOT create") {
		t.Errorf("error = %q, want the refusalDetail text", err.Error())
	}
	if probes != 0 {
		t.Errorf("probes = %d, want 0 — the decision was already made at plan time", probes)
	}
}

// TestDetectBootstrapAction_FreshCloneServerNameMatchStillSyncs pins the
// POSITIVE half of the widened probe. Unlocking the server-side existence
// check for ProjectID-bearing workspaces also unlocked its Exists==true arm,
// and a reachable server merely holding a database of the configured NAME is
// not proof that this workspace is bound to it — nothing checks project_id or
// content. Before the widening such a clone never probed at all and always
// fell through to sync.remote, so a stale or unrelated same-named database
// (including one left behind by the very bug this guard fixes) must not
// silently settle the plan as "nothing to do" and suppress the configured
// recovery clone. The name match survives only as the fallback verdict, which
// TestDetectBootstrapAction_NoLocalShadowDirStillLiveChecksExisting pins.
func TestDetectBootstrapAction_FreshCloneServerNameMatchStillSyncs(t *testing.T) {
	beadsDir, cfg := freshServerModeCloneFixture(t)
	orig := checkBootstrapServerDB
	checkBootstrapServerDB = func(bootstrapServerProbeConfig) bootstrapServerDBCheck {
		return bootstrapServerDBCheck{Reachable: true, Exists: true}
	}
	defer func() { checkBootstrapServerDB = orig }()
	origDelay := bootstrapRetryDelay
	bootstrapRetryDelay = func(time.Duration) {}
	defer func() { bootstrapRetryDelay = origDelay }()

	plan := detectBootstrapAction(beadsDir, cfg)
	if plan.Action != "sync" {
		t.Errorf("action = %q (reason %q), want sync — a server-side name match with no local evidence binding this workspace to that database must not mask configured sync.remote recovery", plan.Action, plan.Reason)
	}
}

// TestDetectBootstrapAction_ShadowDirServerNameMatchSettlesNone pins the other
// half of the same gate: a populated local shadow directory IS evidence this
// workspace is bound to the database the server confirmed, so the Exists
// verdict must settle the plan immediately instead of being deferred behind
// sync.remote. Deferring it would re-clone over a database that already exists
// — GH#5037's Error 1007, which the comment above the settle gate exists to
// prevent — and the fixture configures a sync.remote precisely so the
// assertion discriminates: without the local-evidence half of
// settledOnNameAlone, sync.remote wins and the action becomes "sync". The
// Err-arm twin is TestDetectBootstrapAction_ShadowDirUnreachableServerStillReportsNone;
// this is the Exists-arm one, which nothing covered.
func TestDetectBootstrapAction_ShadowDirServerNameMatchSettlesNone(t *testing.T) {
	beadsDir, cfg := freshServerModeCloneFixture(t)
	if err := os.MkdirAll(filepath.Join(cfg.DoltDataDir, "mydb"), 0o750); err != nil {
		t.Fatal(err)
	}
	orig := checkBootstrapServerDB
	checkBootstrapServerDB = func(bootstrapServerProbeConfig) bootstrapServerDBCheck {
		return bootstrapServerDBCheck{Reachable: true, Exists: true}
	}
	defer func() { checkBootstrapServerDB = orig }()
	origDelay := bootstrapRetryDelay
	bootstrapRetryDelay = func(time.Duration) {}
	defer func() { bootstrapRetryDelay = origDelay }()

	plan := detectBootstrapAction(beadsDir, cfg)
	if plan.Action != "none" {
		t.Errorf("action = %q (reason %q), want none — with local evidence binding this workspace to the database the server reports, re-cloning it is GH#5037's Error 1007", plan.Action, plan.Reason)
	}
	if !plan.HasExisting {
		t.Error("HasExisting = false on a confirmed server-side database with local evidence")
	}
	// Discriminates the Exists arm from the Err arm's "Could not verify"
	// settle, which the same populated shadow directory also unlocks.
	if !strings.Contains(plan.Reason, "already exists on server") {
		t.Errorf("reason = %q, want the Exists-arm wording — a 'Could not verify' reason here means the probe result, not the local evidence, is what settled the plan", plan.Reason)
	}
}
