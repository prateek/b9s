package doctor

import (
	"context"
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"

	"github.com/spf13/viper"
	"github.com/steveyegge/beads/internal/beads"
	"github.com/steveyegge/beads/internal/configfile"
	"github.com/steveyegge/beads/internal/storage/dolt"
	"gopkg.in/yaml.v3"
)

// validRoutingModes are the allowed values for routing.mode
var validRoutingModes = map[string]bool{
	"auto":        true,
	"maintainer":  true,
	"contributor": true,
	"explicit":    true,
}

// validActorRegex validates actor names (alphanumeric with dashes, underscores, dots, and @ for emails)
var validActorRegex = regexp.MustCompile(`^[a-zA-Z0-9][a-zA-Z0-9._@-]*$`)

// validCustomStatusRegex validates custom status names (alphanumeric with underscores)
var validCustomStatusRegex = regexp.MustCompile(`^[a-z][a-z0-9_]*$`)

// CheckConfigValues validates configuration values in config.yaml and metadata.json
// Returns issues found, or OK if all values are valid
// CheckConfigValues validates configuration values across config.yaml, metadata.json, and the database.
// Opens its own store; prefer CheckConfigValuesWithStore when a shared store is available.
func CheckConfigValues(repoPath string) DoctorCheck {
	var issues []string

	// Check config.yaml values
	yamlIssues := checkYAMLConfigValues(repoPath)
	issues = append(issues, yamlIssues...)

	// Check metadata.json values
	metadataIssues := checkMetadataConfigValues(repoPath)
	issues = append(issues, metadataIssues...)

	// Check database config values (status.custom, etc.)
	dbIssues := checkDatabaseConfigValues(repoPath)
	issues = append(issues, dbIssues...)

	return formatConfigValuesResult(issues)
}

// CheckConfigValuesWithStore validates config values using a shared store (GH#2636).
func CheckConfigValuesWithStore(repoPath string, ss *SharedStore) DoctorCheck {
	var issues []string

	// Check config.yaml values
	yamlIssues := checkYAMLConfigValues(repoPath)
	issues = append(issues, yamlIssues...)

	// Check metadata.json values
	metadataIssues := checkMetadataConfigValues(repoPath)
	issues = append(issues, metadataIssues...)

	// Check database config values using shared store
	store := ss.Store()
	if store != nil {
		dbIssues := checkDatabaseConfigValuesWithStore(store)
		issues = append(issues, dbIssues...)
	}

	return formatConfigValuesResult(issues)
}

func formatConfigValuesResult(issues []string) DoctorCheck {
	if len(issues) == 0 {
		return DoctorCheck{
			Name:    "Config Values",
			Status:  "ok",
			Message: "All configuration values are valid",
		}
	}

	return DoctorCheck{
		Name:    "Config Values",
		Status:  "warning",
		Message: fmt.Sprintf("Found %d configuration issue(s)", len(issues)),
		Detail:  strings.Join(issues, "\n"),
		Fix:     "Edit config files to fix invalid values. Run 'bd config' to view current settings.",
	}
}

// findConfigPath locates config.yaml in standard locations.
func findConfigPath(repoPath string) string {
	configPath := filepath.Join(ResolveBeadsDirForRepo(repoPath), "config.yaml")
	if _, err := os.Stat(configPath); err == nil {
		return configPath
	}
	if configDir, err := os.UserConfigDir(); err == nil {
		userConfigPath := filepath.Join(configDir, "bd", "config.yaml")
		if _, err := os.Stat(userConfigPath); err == nil {
			return userConfigPath
		}
	}
	if homeDir, err := os.UserHomeDir(); err == nil {
		homeConfigPath := filepath.Join(homeDir, ".beads", "config.yaml")
		if _, err := os.Stat(homeConfigPath); err == nil {
			return homeConfigPath
		}
	}
	return ""
}

// validateBooleanConfigs validates boolean config values.
func validateBooleanConfigs(v *viper.Viper, keys []string) []string {
	var issues []string
	for _, key := range keys {
		if v.IsSet(key) {
			strVal := v.GetString(key)
			if strVal != "" && !isValidBoolString(strVal) {
				issues = append(issues, fmt.Sprintf("%s: %q is not a valid boolean value (expected true/false, yes/no, 1/0, on/off)", key, strVal))
			}
		}
	}
	return issues
}

// validateRoutingPaths validates routing path config values.
func validateRoutingPaths(v *viper.Viper) []string {
	var issues []string
	for _, key := range []string{"routing.default", "routing.maintainer", "routing.contributor"} {
		if v.IsSet(key) {
			path := v.GetString(key)
			if path != "" && path != "." {
				expandedPath := expandPath(path)
				if _, err := os.Stat(expandedPath); os.IsNotExist(err) {
					issues = append(issues, fmt.Sprintf("%s: path %q does not exist", key, path))
				}
			}
		}
	}
	return issues
}

// validateRepoPaths validates repos.primary and repos.additional paths.
func validateRepoPaths(v *viper.Viper) []string {
	var issues []string
	if v.IsSet("repos.primary") {
		primary := v.GetString("repos.primary")
		if primary != "" {
			expandedPath := expandPath(primary)
			if info, err := os.Stat(expandedPath); err == nil {
				if !info.IsDir() {
					issues = append(issues, fmt.Sprintf("repos.primary: %q is not a directory", primary))
				}
			} else if !os.IsNotExist(err) {
				issues = append(issues, fmt.Sprintf("repos.primary: cannot access %q: %v", primary, err))
			}
		}
	}
	if v.IsSet("repos.additional") {
		for _, path := range v.GetStringSlice("repos.additional") {
			if path != "" {
				expandedPath := expandPath(path)
				if info, err := os.Stat(expandedPath); err == nil && !info.IsDir() {
					issues = append(issues, fmt.Sprintf("repos.additional: %q is not a directory", path))
				}
			}
		}
	}
	return issues
}

// checkYAMLConfigValues validates values in config.yaml
func checkYAMLConfigValues(repoPath string) []string {
	var issues []string

	configPath := findConfigPath(repoPath)
	if configPath == "" {
		return issues
	}

	v := viper.New()
	v.SetConfigType("yaml")
	v.SetConfigFile(configPath)
	if err := v.ReadInConfig(); err != nil {
		issues = append(issues, fmt.Sprintf("config.yaml: failed to parse: %v", err))
		return issues
	}
	if data, err := os.ReadFile(configPath); err == nil { //nolint:gosec // resolved workspace config
		issues = append(issues, findDualSpelledConfigKeys(data)...)
	}

	// Validate issue-prefix (should be alphanumeric with dashes/underscores, reasonably short)
	if v.IsSet("issue-prefix") {
		prefix := v.GetString("issue-prefix")
		if prefix != "" {
			if len(prefix) > 20 {
				issues = append(issues, fmt.Sprintf("issue-prefix: %q is too long (max 20 characters)", prefix))
			}
			if !regexp.MustCompile(`^[a-zA-Z][a-zA-Z0-9_-]*$`).MatchString(prefix) {
				issues = append(issues, fmt.Sprintf("issue-prefix: %q is invalid (must start with letter, contain only letters, numbers, dashes, underscores)", prefix))
			}
		}
	}

	// Validate routing.mode (should be "auto", "maintainer", or "contributor")
	if v.IsSet("routing.mode") {
		mode := v.GetString("routing.mode")
		if mode != "" && !validRoutingModes[mode] {
			validModes := make([]string, 0, len(validRoutingModes))
			for m := range validRoutingModes {
				validModes = append(validModes, m)
			}
			issues = append(issues, fmt.Sprintf("routing.mode: %q is invalid (valid values: %s)", mode, strings.Join(validModes, ", ")))
		}

		// Validate routing + hydration consistency (bd-fix-routing)
		// When routing.mode=auto with routing targets, those targets should be in repos.additional
		// so routed issues are visible in bd list via multi-repo hydration
		if mode == "auto" {
			contributorRepo := v.GetString("routing.contributor")
			maintainerRepo := v.GetString("routing.maintainer")

			// Check if routing targets are configured (exclude "." which means current repo)
			hasRoutingTargets := (contributorRepo != "" && contributorRepo != ".") || (maintainerRepo != "" && maintainerRepo != ".")

			if hasRoutingTargets {
				// Check if hydration is configured
				additional := v.GetStringSlice("repos.additional")
				hasHydration := len(additional) > 0

				if !hasHydration {
					issues = append(issues,
						"routing.mode=auto with routing targets but repos.additional not configured. "+
							"Issues created via routing will not be visible in bd list. "+
							"Run 'bd repo add <routing-target>' to enable hydration.")
				} else {
					// Check if routing targets are in hydration list
					additionalSet := make(map[string]bool)
					for _, path := range additional {
						additionalSet[expandPath(path)] = true
					}

					if contributorRepo != "" {
						expandedContributor := expandPath(contributorRepo)
						if !additionalSet[expandedContributor] {
							issues = append(issues, fmt.Sprintf(
								"routing.contributor=%q is not in repos.additional. "+
									"Run 'bd repo add %s' to make routed issues visible.",
								contributorRepo, contributorRepo))
						}
					}

					if maintainerRepo != "" && maintainerRepo != "." {
						expandedMaintainer := expandPath(maintainerRepo)
						if !additionalSet[expandedMaintainer] {
							issues = append(issues, fmt.Sprintf(
								"routing.maintainer=%q is not in repos.additional. "+
									"Run 'bd repo add %s' to make routed issues visible.",
								maintainerRepo, maintainerRepo))
						}
					}
				}
			}
		}
	}

	// Validate routing paths exist if set
	issues = append(issues, validateRoutingPaths(v)...)

	// Validate actor (should be alphanumeric with common special chars if set)
	if v.IsSet("actor") {
		actor := v.GetString("actor")
		if actor != "" && !validActorRegex.MatchString(actor) {
			issues = append(issues, fmt.Sprintf("actor: %q is invalid (must start with letter/number, contain only letters, numbers, dashes, underscores, dots, or @)", actor))
		}
	}

	// Validate db path (should be a valid file path if set)
	if v.IsSet("db") {
		dbPath := v.GetString("db")
		if dbPath != "" {
			// Check for invalid path characters (null bytes, etc.)
			if strings.ContainsAny(dbPath, "\x00") {
				issues = append(issues, fmt.Sprintf("db: %q contains invalid characters", dbPath))
			}
		}
	}

	// Validate boolean config values
	boolKeys := []string{"json", "no-db", "sync.require_confirmation_on_mass_delete"}
	issues = append(issues, validateBooleanConfigs(v, boolKeys)...)

	// Validate repos paths
	issues = append(issues, validateRepoPaths(v)...)

	return issues
}

func findDualSpelledConfigKeys(data []byte) []string {
	var root yaml.Node
	if err := yaml.Unmarshal(data, &root); err != nil || len(root.Content) == 0 {
		return nil
	}
	mapping := root.Content[0]
	if mapping.Kind != yaml.MappingNode {
		return nil
	}

	var issues []string
	for i := 0; i+1 < len(mapping.Content); i += 2 {
		key := mapping.Content[i].Value
		parts := strings.Split(key, ".")
		if len(parts) < 2 || !yamlPathExists(mapping, parts) {
			continue
		}
		issues = append(issues, fmt.Sprintf(
			"config.yaml: %q is present in both flat and nested spelling; remove one spelling so all readers use the same value",
			key,
		))
	}
	return issues
}

func yamlPathExists(mapping *yaml.Node, parts []string) bool {
	current := mapping
	for i, part := range parts {
		if current.Kind != yaml.MappingNode {
			return false
		}
		idx := yamlMappingChild(current, part)
		if idx == -1 {
			return false
		}
		if i == len(parts)-1 {
			return true
		}
		current = current.Content[idx+1]
	}
	return false
}

func yamlMappingChild(mapping *yaml.Node, name string) int {
	for i := 0; i+1 < len(mapping.Content); i += 2 {
		key := mapping.Content[i]
		if key.Kind == yaml.ScalarNode && key.Value == name {
			return i
		}
	}
	return -1
}

// isValidBoolString checks if a string represents a valid boolean value
func isValidBoolString(s string) bool {
	lower := strings.ToLower(strings.TrimSpace(s))
	switch lower {
	case "true", "false", "yes", "no", "1", "0", "on", "off", "t", "f", "y", "n":
		return true
	}
	// Also check if it parses as a bool
	_, err := strconv.ParseBool(s)
	return err == nil
}

// expandPath expands ~ to home directory and resolves the path
func expandPath(path string) string {
	if strings.HasPrefix(path, "~") {
		if home, err := os.UserHomeDir(); err == nil {
			path = filepath.Join(home, path[1:])
		}
	}
	return path
}

// checkMetadataConfigValues validates values in metadata.json
func checkMetadataConfigValues(repoPath string) []string {
	var issues []string

	beadsDir := ResolveBeadsDirForRepo(repoPath)
	cfg, err := configfile.Load(beadsDir)
	if err != nil {
		issues = append(issues, fmt.Sprintf("metadata.json: failed to load: %v", err))
		return issues
	}

	if cfg == nil {
		// No metadata.json, that's OK
		return issues
	}

	// Validate database filename
	if cfg.Database != "" {
		if strings.Contains(cfg.Database, string(os.PathSeparator)) || strings.Contains(cfg.Database, "/") {
			issues = append(issues, fmt.Sprintf("metadata.json database: %q should be a filename, not a path", cfg.Database))
		}
		backend := cfg.GetBackend()
		if backend == configfile.BackendDolt {
			// Dolt is directory-backed; `database` should point to a directory (typically "dolt").
			if strings.HasSuffix(cfg.Database, ".db") || strings.HasSuffix(cfg.Database, ".sqlite") || strings.HasSuffix(cfg.Database, ".sqlite3") {
				issues = append(issues, fmt.Sprintf("metadata.json database: %q looks like a SQLite file, but backend is dolt (expected a directory like %q)", cfg.Database, "dolt"))
			}
			if cfg.Database == beads.CanonicalDatabaseName {
				issues = append(issues, fmt.Sprintf("metadata.json database: %q is misleading for dolt backend (expected %q)", cfg.Database, "dolt"))
			}
		}
	}

	// Validate dolt_database for embedded-mode compatibility (GH#3231).
	// Hyphens and dots are allowed by server mode but rejected by the
	// embedded Dolt engine because database names are interpolated into
	// system variable identifiers (@@<db>_head_ref) where only
	// [a-zA-Z_][a-zA-Z0-9_]* is valid.
	if cfg.DoltDatabase != "" && !cfg.IsDoltServerMode() {
		sanitized := strings.ReplaceAll(cfg.DoltDatabase, "-", "_")
		sanitized = strings.ReplaceAll(sanitized, ".", "_")
		if sanitized != cfg.DoltDatabase {
			issues = append(issues, fmt.Sprintf(
				"metadata.json dolt_database: %q contains characters invalid in embedded mode — "+
					"replace with %q or set dolt_mode to \"server\" (GH#3231)", cfg.DoltDatabase, sanitized))
		}
	}

	// Validate deletions_retention_days
	if cfg.DeletionsRetentionDays < 0 {
		issues = append(issues, fmt.Sprintf("metadata.json deletions_retention_days: %d is invalid (must be >= 0)", cfg.DeletionsRetentionDays))
	}

	return issues
}

// checkDatabaseConfigValues validates configuration values stored in the database
func checkDatabaseConfigValues(repoPath string) []string {
	var issues []string

	beadsDir := ResolveBeadsDirForRepo(repoPath)
	if _, err := os.Stat(beadsDir); os.IsNotExist(err) {
		return issues // No .beads directory, nothing to check
	}

	// Check backend
	cfg, err := configfile.Load(beadsDir)
	if err != nil {
		return issues
	}

	backend := configfile.BackendDolt
	if cfg != nil {
		backend = cfg.GetBackend()
	}

	if backend != configfile.BackendDolt {
		return issues // Non-Dolt backend, skip database config validation
	}

	// Check if Dolt directory exists
	doltPath := getDatabasePath(beadsDir)
	if _, err := os.Stat(doltPath); os.IsNotExist(err) {
		return issues // No database, nothing to check
	}

	// Open Dolt store in read-only mode
	ctx := context.Background()
	store, err := dolt.NewFromConfigWithCLIOptions(ctx, beadsDir, configValidationStoreOptions())
	if err != nil {
		issues = append(issues, fmt.Sprintf("database: failed to open Dolt store: %v", err))
		return issues
	}
	defer func() { _ = store.Close() }()

	return checkDatabaseConfigValuesWithStore(store)
}

func configValidationStoreOptions() *dolt.Config {
	return &dolt.Config{ReadOnly: true, DisableAutoStart: true}
}

func checkDatabaseConfigValuesWithStore(store *dolt.DoltStore) []string {
	var issues []string
	ctx := context.Background()

	// Check status.custom - custom status names should be lowercase alphanumeric with underscores
	statusCustom, err := store.GetConfig(ctx, "status.custom")
	if err == nil && statusCustom != "" {
		statuses := strings.Split(statusCustom, ",")
		for _, status := range statuses {
			status = strings.TrimSpace(status)
			if status == "" {
				continue
			}
			if !validCustomStatusRegex.MatchString(status) {
				issues = append(issues, fmt.Sprintf("status.custom: %q is invalid (must start with lowercase letter, contain only lowercase letters, numbers, and underscores)", status))
			}
			// Check for conflicts with built-in statuses
			switch status {
			case "open", "in_progress", "blocked", "closed":
				issues = append(issues, fmt.Sprintf("status.custom: %q conflicts with built-in status", status))
			}
		}
	}

	return issues
}
