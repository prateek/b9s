package main

import (
	"bytes"
	"encoding/json"
	"errors"
	"os"
	"strings"
	"testing"

	"github.com/spf13/cobra"
)

func transformTestCommand(path string, flags ...string) *cobra.Command {
	root := &cobra.Command{Use: "bd"}
	cmd := &cobra.Command{Use: path}
	for _, flag := range flags {
		if flag == "of" || flag == "with" {
			cmd.Flags().String(flag, "", "")
		} else {
			cmd.Flags().Bool(flag, false, "")
		}
	}
	root.AddCommand(cmd)
	return cmd
}

func TestProxyTransformCapabilityRows(t *testing.T) {
	cases := []struct {
		name, path, argument string
		flags                []string
		outcome              ProxyCapabilityOutcome
		code, message        string
		exit                 int
		mutates              bool
	}{
		{name: "rename", path: "rename", outcome: ProxyOutcomeRefused, code: "proxy.transform.unsupported", message: "rename is not supported in proxied-server mode", exit: 1},
		{name: "rename-prefix", path: "rename-prefix", outcome: ProxyOutcomeRefused, code: "proxy.transform.unsupported", message: "rename-prefix is not supported in proxied-server mode", exit: 1},
		{name: "rename-prefix dry-run", path: "rename-prefix", argument: "--dry-run", flags: []string{"dry-run"}, outcome: ProxyOutcomeRefused, code: "proxy.transform.unsupported", message: "rename-prefix --dry-run is not supported in proxied-server mode", exit: 1},
		{name: "rename-prefix repair", path: "rename-prefix", argument: "--repair", flags: []string{"repair"}, outcome: ProxyOutcomeRefused, code: "proxy.transform.unsupported", message: "rename-prefix --repair is not supported in proxied-server mode", exit: 1},
		{name: "rename-prefix repair dry-run", path: "rename-prefix", argument: "--dry-run --repair", flags: []string{"dry-run", "repair"}, outcome: ProxyOutcomeRefused, code: "proxy.transform.unsupported", message: "rename-prefix --dry-run --repair is not supported in proxied-server mode", exit: 1},
		{name: "duplicate", path: "duplicate", outcome: ProxyOutcomeRefused, code: "proxy.transform.unsupported", message: "duplicate is not supported in proxied-server mode", exit: 1},
		{name: "duplicate of", path: "duplicate", argument: "--of", flags: []string{"of"}, outcome: ProxyOutcomeRefused, code: "proxy.transform.unsupported", message: "duplicate --of is not supported in proxied-server mode", exit: 1},
		{name: "supersede", path: "supersede", outcome: ProxyOutcomeRefused, code: "proxy.transform.unsupported", message: "supersede is not supported in proxied-server mode", exit: 1},
		{name: "supersede with", path: "supersede", argument: "--with", flags: []string{"with"}, outcome: ProxyOutcomeRefused, code: "proxy.transform.unsupported", message: "supersede --with is not supported in proxied-server mode", exit: 1},
		{name: "duplicates", path: "duplicates", flags: []string{"auto-merge", "dry-run"}, outcome: ProxyOutcomeHonored},
		{name: "duplicates auto-merge", path: "duplicates", argument: "--auto-merge", flags: []string{"auto-merge", "dry-run"}, outcome: ProxyOutcomeRefused, code: "proxy.transform.unsupported", message: "duplicates --auto-merge is not supported in proxied-server mode", exit: 1},
		{name: "duplicates auto-merge dry-run", path: "duplicates", argument: "--auto-merge --dry-run", flags: []string{"auto-merge", "dry-run"}, outcome: ProxyOutcomeHonored},
	}

	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			cmd := transformTestCommand(tc.path, tc.flags...)
			if tc.argument != "" {
				for _, flag := range strings.Fields(tc.argument) {
					if err := cmd.Flags().Set(strings.TrimPrefix(flag, "--"), "true"); err != nil {
						t.Fatal(err)
					}
				}
			}
			row, ok := capabilityRowFor(cmd)
			if !ok {
				t.Fatalf("lookup(%q, %q) missing row", tc.path, tc.argument)
			}
			if row.Path != tc.path || row.ArgSet != tc.argument || row.Rule.Outcome != tc.outcome {
				t.Fatalf("row = %#v, want path=%q argument=%q outcome=%q", row, tc.path, tc.argument, tc.outcome)
			}
			if tc.outcome == ProxyOutcomeRefused {
				if row.Rule.Code != tc.code || row.Rule.Message != tc.message || row.Rule.ExitCode != tc.exit || row.Rule.Mutates != tc.mutates {
					t.Fatalf("refusal fields = code=%q message=%q exit=%d mutates=%t",
						row.Rule.Code, row.Rule.Message, row.Rule.ExitCode, row.Rule.Mutates)
				}
				var typed error = proxyCapabilityErrorFor(row.Rule)
				var got *ProxyCapabilityError
				if !errors.As(typed, &got) || got.Code != tc.code || got.ExitCode != 1 || got.Mutates {
					t.Fatalf("typed refusal = %#v", typed)
				}
			}
			if err := validateProxyRegistryBeforeProvider(cmd, ProxyTopologyManagedLocal); tc.outcome == ProxyOutcomeHonored && err != nil {
				t.Fatalf("honored transform refused: %v", err)
			}
		})
	}
}

func TestProxyDuplicatesAutoMergeDryRunMatrix(t *testing.T) {
	cmd := transformTestCommand("duplicates", "auto-merge", "dry-run")
	_ = cmd.Flags().Set("auto-merge", "true")
	if err := validateProxyRegistryBeforeProvider(cmd, ProxyTopologyManagedLocal); err == nil {
		t.Fatalf("non-dry auto-merge error = %v", err)
	}
	_ = cmd.Flags().Set("dry-run", "true")
	if err := validateProxyRegistryBeforeProvider(cmd, ProxyTopologyManagedLocal); err != nil {
		t.Fatalf("dry-run auto-merge refused: %v", err)
	}
}

func TestProxyTransformRefusalRendering(t *testing.T) {
	t.Setenv("BD_JSON_ENVELOPE", "")
	cmd := transformTestCommand("rename")
	oldJSON := jsonOutput
	t.Cleanup(func() { jsonOutput = oldJSON })

	jsonOutput = false
	var textErr string
	stderr := captureStderr(t, func() {
		err := validateProxyRegistryBeforeProvider(cmd, ProxyTopologyManagedLocal)
		if code, ok := exitCodeFromError(err); !ok || code != 1 {
			t.Fatalf("exit = %v, want 1", err)
		}
		textErr = err.Error()
	})
	if textErr != "exit code 1" || stderr != "Error: rename is not supported in proxied-server mode\n" {
		t.Fatalf("text refusal = %q (err %q)", stderr, textErr)
	}

	jsonOutput = true
	stdout := captureStdout(t, func() error {
		_ = validateProxyRegistryBeforeProvider(cmd, ProxyTopologyManagedLocal)
		return nil
	})
	var envelope map[string]any
	if err := json.Unmarshal([]byte(stdout), &envelope); err != nil {
		t.Fatalf("JSON refusal: %v (%q)", err, stdout)
	}
	if envelope["code"] != "proxy.transform.unsupported" || envelope["error"] != "rename is not supported in proxied-server mode" {
		t.Fatalf("JSON refusal = %#v", envelope)
	}
}

func TestProxyTransformMatcherIgnoresInheritedOutputFlags(t *testing.T) {
	root := &cobra.Command{Use: "bd"}
	root.PersistentFlags().Bool("json", false, "output JSON")
	cmd := &cobra.Command{Use: "duplicates"}
	cmd.Flags().Bool("auto-merge", false, "")
	cmd.Flags().Bool("dry-run", false, "")
	root.AddCommand(cmd)
	if err := cmd.Flags().Set("auto-merge", "true"); err != nil {
		t.Fatal(err)
	}
	if err := root.PersistentFlags().Set("json", "true"); err != nil {
		t.Fatal(err)
	}
	row, ok := capabilityRowFor(cmd)
	if !ok || row.ArgSet != "--auto-merge" || row.Rule.Outcome != ProxyOutcomeRefused {
		t.Fatalf("row with inherited --json = %#v, ok=%v", row, ok)
	}
}

func TestProxyTransformRefusalHasNoProviderOrFileMutation(t *testing.T) {
	dir := t.TempDir()
	version := []byte("version-before\n")
	issues := []byte(`{"id":"before","title":"untouched"}` + "\n")
	versionPath := dir + "/.local_version"
	issuesPath := dir + "/issues.jsonl"
	if err := os.WriteFile(versionPath, version, 0o600); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(issuesPath, issues, 0o600); err != nil {
		t.Fatal(err)
	}
	oldProvider := uowProvider
	uowProvider = nil
	t.Cleanup(func() { uowProvider = oldProvider })

	cmd := transformTestCommand("supersede")
	err := validateProxyRegistryBeforeProvider(cmd, ProxyTopologyManagedLocal)
	if err == nil {
		t.Fatal("expected transform refusal")
	}
	if code, ok := exitCodeFromError(err); !ok || code != 1 {
		t.Fatalf("exit = %v, want 1", err)
	}
	if uowProvider != nil {
		t.Fatal("transform refusal initialized a provider")
	}
	gotVersion, err := os.ReadFile(versionPath)
	if err != nil {
		t.Fatal(err)
	}
	gotIssues, err := os.ReadFile(issuesPath)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(gotVersion, version) || !bytes.Equal(gotIssues, issues) {
		t.Fatal("transform refusal mutated workspace files")
	}
}
