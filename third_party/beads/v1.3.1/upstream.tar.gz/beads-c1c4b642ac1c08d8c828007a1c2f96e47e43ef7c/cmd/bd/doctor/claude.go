package doctor

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"
)

var latestPyPIVersionFetcher = fetchLatestPyPIVersion

// CheckClaude returns Claude integration verification as a DoctorCheck.
// repoPath is the project root directory.
func CheckClaude(repoPath string) DoctorCheck {
	// Check what's installed
	hasPlugin := isBeadsPluginInstalled(repoPath)
	hasMCP := isMCPServerInstalled(repoPath)
	hasHooks := hasClaudeHooks(repoPath)
	inClaudeCode := os.Getenv("CLAUDECODE") == "1"

	// Plugin now provides hooks directly via plugin.json, so if plugin is installed
	// we consider hooks to be available (plugin hooks + any user-configured hooks)
	if hasPlugin {
		return DoctorCheck{
			Name:    "Claude Integration",
			Status:  "ok",
			Message: "Plugin installed",
			Detail:  "Slash commands and workflow hooks enabled via plugin",
		}
	} else if hasMCP && hasHooks {
		return DoctorCheck{
			Name:    "Claude Integration",
			Status:  "ok",
			Message: "MCP server and hooks installed",
			Detail:  "Workflow reminders enabled (legacy MCP mode)",
		}
	} else if !hasMCP && !hasPlugin && hasHooks {
		return DoctorCheck{
			Name:    "Claude Integration",
			Status:  "ok",
			Message: "Hooks installed (CLI mode)",
			Detail:  "Plugin not detected - install for slash commands",
		}
	} else if hasMCP && !hasHooks {
		return DoctorCheck{
			Name:    "Claude Integration",
			Status:  "warning",
			Message: "MCP server installed but hooks missing",
			Detail: "MCP-only mode: relies on tools for every query (~10.5k tokens)\n" +
				"  bd prime hooks provide much better token efficiency",
			Fix: "Add bd prime hooks for better token efficiency:\n" +
				"  1. Run 'bd setup claude' to add SessionStart hooks\n" +
				"\n" +
				"Benefits:\n" +
				"  • MCP mode: ~50 tokens vs ~10.5k for full tool scan (99% reduction)\n" +
				"  • Automatic context refresh on session start and compaction\n" +
				"  • Works alongside MCP tools for when you need them\n" +
				"\n" +
				"See: bd setup claude --help",
		}
	} else if !inClaudeCode || !isClaudePresent() {
		// Not in Claude Code, or CLAUDECODE=1 was set by another AI tool but
		// Claude CLI/~/.claude/ are absent — skip plugin suggestion.
		return DoctorCheck{
			Name:    "Claude Integration",
			Status:  "ok",
			Message: "CLI-only mode",
			Detail:  "To enable Claude integration, run bd setup claude",
		}
	} else {
		// In Claude Code but plugin not installed
		return DoctorCheck{
			Name:    "Claude Integration",
			Status:  "warning",
			Message: "Not configured",
			Detail:  "Claude can use bd more effectively with the beads plugin",
			Fix: "Set up Claude integration:\n" +
				"  Option 1: Install the beads plugin (recommended)\n" +
				"    • Provides hooks, slash commands, and MCP tools automatically\n" +
				"    • See: https://github.com/gastownhall/beads/blob/main/docs/integrations/claude-code-plugin.md\n" +
				"\n" +
				"  Option 2: CLI-only mode\n" +
				"    • Run 'bd setup claude' to add SessionStart hooks\n" +
				"    • No slash commands, but hooks provide workflow context\n" +
				"\n" +
				"Benefits:\n" +
				"  • Auto-inject workflow context on session start (~50-2k tokens)\n" +
				"  • Automatic context recovery before compaction",
		}
	}
}

// isBeadsPluginInstalled checks if beads plugin is enabled in Claude Code.
// It checks user-level (~/.claude/settings.json) and project-level settings
// (.claude/settings.json and .claude/settings.local.json).
// repoPath is the project root directory.
func isBeadsPluginInstalled(repoPath string) bool {
	home, err := os.UserHomeDir()
	if err != nil {
		return false
	}

	// Check user-level settings
	userSettings := filepath.Join(home, ".claude", "settings.json")
	if checkPluginInSettings(userSettings) {
		return true
	}

	// Check project-level settings
	projectSettings := filepath.Join(repoPath, ".claude", "settings.json")
	if checkPluginInSettings(projectSettings) {
		return true
	}

	// Check project-level local settings (gitignored)
	projectLocalSettings := filepath.Join(repoPath, ".claude", "settings.local.json")
	if checkPluginInSettings(projectLocalSettings) {
		return true
	}

	return false
}

// checkPluginInSettings checks if beads plugin is enabled in a settings file
func checkPluginInSettings(settingsPath string) bool {
	data, err := os.ReadFile(settingsPath) // #nosec G304 -- settingsPath is constructed from known safe locations, not user input
	if err != nil {
		return false
	}

	var settings map[string]interface{}
	if err := json.Unmarshal(data, &settings); err != nil {
		return false
	}

	// Check enabledPlugins section for beads
	enabledPlugins, ok := settings["enabledPlugins"].(map[string]interface{})
	if !ok {
		return false
	}

	// Look for beads@beads-marketplace plugin
	for key, value := range enabledPlugins {
		if strings.Contains(strings.ToLower(key), "beads") {
			// Check if it's enabled (value should be true)
			if enabled, ok := value.(bool); ok && enabled {
				return true
			}
		}
	}

	return false
}

// isMCPServerInstalled checks if MCP server is configured.
// It checks user-level (~/.claude/settings.json) and project-level settings
// (.claude/settings.json and .claude/settings.local.json).
// repoPath is the project root directory.
func isMCPServerInstalled(repoPath string) bool {
	home, err := os.UserHomeDir()
	if err != nil {
		return false
	}

	// Check user-level settings
	userSettings := filepath.Join(home, ".claude", "settings.json")
	if checkMCPInSettings(userSettings) {
		return true
	}

	// Check project-level settings
	projectSettings := filepath.Join(repoPath, ".claude", "settings.json")
	if checkMCPInSettings(projectSettings) {
		return true
	}

	// Check project-level local settings (gitignored)
	projectLocalSettings := filepath.Join(repoPath, ".claude", "settings.local.json")
	if checkMCPInSettings(projectLocalSettings) {
		return true
	}

	return false
}

// checkMCPInSettings checks if beads MCP server is configured in a settings file
func checkMCPInSettings(settingsPath string) bool {
	data, err := os.ReadFile(settingsPath) // #nosec G304 -- settingsPath is constructed from known safe locations, not user input
	if err != nil {
		return false
	}

	var settings map[string]interface{}
	if err := json.Unmarshal(data, &settings); err != nil {
		return false
	}

	// Check mcpServers section for beads
	mcpServers, ok := settings["mcpServers"].(map[string]interface{})
	if !ok {
		return false
	}

	// Look for beads server (any key containing "beads")
	for key := range mcpServers {
		if strings.Contains(strings.ToLower(key), "beads") {
			return true
		}
	}

	return false
}

// hasClaudeHooks checks if Claude hooks are installed.
// repoPath is the project root directory.
func hasClaudeHooks(repoPath string) bool {
	home, err := os.UserHomeDir()
	if err != nil {
		return false
	}

	globalSettings := filepath.Join(home, ".claude", "settings.json")
	projectSettings := filepath.Join(repoPath, ".claude", "settings.json")
	projectLocalSettings := filepath.Join(repoPath, ".claude", "settings.local.json")

	return hasBeadsHooks(globalSettings) || hasBeadsHooks(projectSettings) || hasBeadsHooks(projectLocalSettings)
}

// hasBeadsHooks checks if a settings file has bd prime hooks
func hasBeadsHooks(settingsPath string) bool {
	data, err := os.ReadFile(settingsPath) // #nosec G304 -- settingsPath is constructed from known safe locations (user home/.claude), not user input
	if err != nil {
		return false
	}

	var settings map[string]interface{}
	if err := json.Unmarshal(data, &settings); err != nil {
		return false
	}

	hooks, ok := settings["hooks"].(map[string]interface{})
	if !ok {
		return false
	}

	// Check SessionStart and PreCompact for "bd prime"
	for _, event := range []string{"SessionStart", "PreCompact"} {
		eventHooks, ok := hooks[event].([]interface{})
		if !ok {
			continue
		}

		for _, hook := range eventHooks {
			hookMap, ok := hook.(map[string]interface{})
			if !ok {
				continue
			}
			commands, ok := hookMap["hooks"].([]interface{})
			if !ok {
				continue
			}
			for _, cmd := range commands {
				cmdMap, ok := cmd.(map[string]interface{})
				if !ok {
					continue
				}
				cmdStr, _ := cmdMap["command"].(string)
				switch cmdStr {
				case "bd prime", "bd prime --stealth",
					"bd prime --hook-json", "bd prime --stealth --hook-json":
					return true
				}
			}
		}
	}

	return false
}

// VerifyPrimeOutput checks if bd prime command works and adapts correctly.
// repoPath is the project root directory.
func VerifyPrimeOutput(repoPath string) DoctorCheck {
	cmd := exec.Command("bd", "prime")
	output, err := cmd.CombinedOutput()

	if err != nil {
		return DoctorCheck{
			Name:    "bd prime Command",
			Status:  "error",
			Message: "Command failed to execute",
			Fix:     "Ensure bd is installed and in PATH",
		}
	}

	if len(output) == 0 {
		return DoctorCheck{
			Name:    "bd prime Command",
			Status:  "error",
			Message: "No output produced",
			Detail:  "Expected workflow context markdown",
		}
	}

	// Check if output adapts to MCP mode
	hasMCP := isMCPServerInstalled(repoPath)
	outputStr := string(output)

	if hasMCP && strings.Contains(outputStr, "mcp__plugin_beads_beads__") {
		return DoctorCheck{
			Name:    "bd prime Output",
			Status:  "ok",
			Message: "MCP mode detected",
			Detail:  "Outputting workflow reminders",
		}
	} else if !hasMCP && strings.Contains(outputStr, "bd ready") {
		return DoctorCheck{
			Name:    "bd prime Output",
			Status:  "ok",
			Message: "CLI mode detected",
			Detail:  "Outputting full command reference",
		}
	} else {
		return DoctorCheck{
			Name:    "bd prime Output",
			Status:  "warning",
			Message: "Output may not be adapting to environment",
		}
	}
}

// CheckBdInPath verifies that 'bd' command is available in PATH.
// This is important because Claude hooks rely on executing 'bd prime'.
func CheckBdInPath() DoctorCheck {
	_, err := exec.LookPath("bd")
	if err != nil {
		return DoctorCheck{
			Name:    "CLI Availability",
			Status:  "warning",
			Message: "'bd' command not found in PATH",
			Detail:  "Claude hooks execute 'bd prime' and won't work without bd in PATH",
			Fix: "Install bd globally:\n" +
				"  • Homebrew: brew install beads\n" +
				"  • Script: " + installScriptCommand + "\n" +
				"  • Or add bd to your PATH",
		}
	}

	return DoctorCheck{
		Name:    "CLI Availability",
		Status:  "ok",
		Message: "'bd' command available in PATH",
	}
}

// CheckDocumentationBdPrimeReference checks if the agents file or CLAUDE.md reference 'bd prime'
// and verifies the command exists. This helps catch version mismatches where docs
// reference features not available in the installed version.
// Also supports local-only variants (claude.local.md) that are gitignored.
func CheckDocumentationBdPrimeReference(repoPath string) DoctorCheck {
	docFiles := agentDocFiles(repoPath)

	var filesWithBdPrime []string
	for _, docFile := range docFiles {
		content, err := os.ReadFile(docFile) // #nosec G304 - controlled paths from repoPath
		if err != nil {
			continue
		}

		if strings.Contains(string(content), "bd prime") {
			filesWithBdPrime = append(filesWithBdPrime, filepath.Base(docFile))
		}
	}

	// If no docs reference bd prime, that's fine - not everyone uses it
	if len(filesWithBdPrime) == 0 {
		return DoctorCheck{
			Name:    "Prime Documentation",
			Status:  "ok",
			Message: "No bd prime references in documentation",
		}
	}

	// Docs reference bd prime - verify the command works
	cmd := exec.Command("bd", "prime", "--help")
	if err := cmd.Run(); err != nil {
		return DoctorCheck{
			Name:    "Prime Documentation",
			Status:  "warning",
			Message: "Documentation references 'bd prime' but command not found",
			Detail:  "Files: " + strings.Join(filesWithBdPrime, ", "),
			Fix: "Upgrade bd to get the 'bd prime' command:\n" +
				"  • Homebrew: brew upgrade beads\n" +
				"  • Script: " + installScriptCommand + "\n" +
				"  Or remove 'bd prime' references from documentation if using older version",
		}
	}

	return DoctorCheck{
		Name:    "Prime Documentation",
		Status:  "ok",
		Message: "Documentation references match installed features",
		Detail:  "Files: " + strings.Join(filesWithBdPrime, ", "),
	}
}

// isClaudePresent returns true when the Claude CLI binary exists in PATH or the
// ~/.claude/ directory is present.  CLAUDECODE=1 can be set by AI coding tools
// other than Claude Code itself, so checking for actual Claude artifacts prevents
// spurious warnings for users who never installed Claude Code.
func isClaudePresent() bool {
	if _, err := exec.LookPath("claude"); err == nil {
		return true
	}
	home, err := os.UserHomeDir()
	if err != nil {
		return false
	}
	info, err := os.Stat(filepath.Join(home, ".claude"))
	return err == nil && info.IsDir()
}

// CheckClaudePlugin checks if the beads Claude Code plugin is installed and up to date.
func CheckClaudePlugin() DoctorCheck {
	// Check if running in Claude Code.
	// CLAUDECODE=1 may be set by AI tools other than Claude Code, so also verify
	// that the claude CLI or ~/.claude/ directory actually exists.
	if os.Getenv("CLAUDECODE") != "1" || !isClaudePresent() {
		return DoctorCheck{
			Name:    "Claude Plugin",
			Status:  StatusOK,
			Message: "N/A (not running in Claude Code)",
		}
	}

	// Get plugin version from installed_plugins.json
	pluginVersion, pluginInstalled, err := GetClaudePluginVersion()
	if err != nil {
		return DoctorCheck{
			Name:    "Claude Plugin",
			Status:  StatusWarning,
			Message: "Unable to check plugin version",
			Detail:  err.Error(),
		}
	}

	if !pluginInstalled {
		return DoctorCheck{
			Name:    "Claude Plugin",
			Status:  StatusWarning,
			Message: "beads plugin not installed",
			Fix:     "Install plugin: /plugin marketplace add steveyegge/beads && /plugin install beads (see docs/integrations/claude-code-plugin.md)",
		}
	}

	// Query PyPI for latest MCP version
	latestMCPVersion, err := latestPyPIVersionFetcher("beads-mcp")
	if err != nil {
		// Network error - don't fail
		return DoctorCheck{
			Name:    "Claude Plugin",
			Status:  StatusOK,
			Message: fmt.Sprintf("version %s (unable to check for updates)", pluginVersion),
		}
	}

	// Compare versions
	if latestMCPVersion == "" || pluginVersion == latestMCPVersion {
		return DoctorCheck{
			Name:    "Claude Plugin",
			Status:  StatusOK,
			Message: fmt.Sprintf("version %s (latest)", pluginVersion),
		}
	}

	if CompareVersions(latestMCPVersion, pluginVersion) > 0 {
		return DoctorCheck{
			Name:    "Claude Plugin",
			Status:  StatusWarning,
			Message: fmt.Sprintf("version %s (latest: %s)", pluginVersion, latestMCPVersion),
			Fix:     "Update plugin: /plugin update beads@beads-marketplace\nRestart Claude Code after update",
		}
	}

	return DoctorCheck{
		Name:    "Claude Plugin",
		Status:  StatusOK,
		Message: fmt.Sprintf("version %s", pluginVersion),
	}
}

// CheckClaudePluginLocalOnly validates local Claude plugin presence/version
// without contacting PyPI.
func CheckClaudePluginLocalOnly() DoctorCheck {
	if os.Getenv("CLAUDECODE") != "1" || !isClaudePresent() {
		return DoctorCheck{
			Name:    "Claude Plugin",
			Status:  StatusOK,
			Message: "N/A (not running in Claude Code)",
		}
	}

	pluginVersion, pluginInstalled, err := GetClaudePluginVersion()
	if err != nil {
		return DoctorCheck{
			Name:    "Claude Plugin",
			Status:  StatusWarning,
			Message: "Unable to check plugin version",
			Detail:  err.Error(),
		}
	}

	if !pluginInstalled {
		return DoctorCheck{
			Name:    "Claude Plugin",
			Status:  StatusWarning,
			Message: "beads plugin not installed",
			Fix:     "Install plugin: /plugin marketplace add steveyegge/beads && /plugin install beads (see docs/integrations/claude-code-plugin.md)",
		}
	}

	return DoctorCheck{
		Name:    "Claude Plugin",
		Status:  StatusOK,
		Message: fmt.Sprintf("version %s (update check skipped in non-interactive mode)", pluginVersion),
	}
}

// GetClaudePluginVersion returns the installed beads Claude plugin version.
func GetClaudePluginVersion() (version string, installed bool, err error) {
	// Get user home directory (cross-platform)
	homeDir, err := os.UserHomeDir()
	if err != nil {
		return "", false, fmt.Errorf("unable to determine home directory: %w", err)
	}

	// Path to installed_plugins.json
	pluginPath := filepath.Join(homeDir, ".claude", "plugins", "installed_plugins.json")

	// Read plugin file
	data, err := os.ReadFile(pluginPath) // #nosec G304 - path is controlled
	if err != nil {
		if os.IsNotExist(err) {
			return "", false, nil
		}
		return "", false, fmt.Errorf("unable to read plugin file: %w", err)
	}

	// First, determine the format version
	var versionCheck struct {
		Version int `json:"version"`
	}
	if err := json.Unmarshal(data, &versionCheck); err != nil {
		return "", false, fmt.Errorf("unable to parse plugin file: %w", err)
	}

	// Handle version 2 format (GH#741): plugins map contains arrays
	if versionCheck.Version == 2 {
		var pluginDataV2 struct {
			Plugins map[string][]struct {
				Version string `json:"version"`
				Scope   string `json:"scope"`
			} `json:"plugins"`
		}
		if err := json.Unmarshal(data, &pluginDataV2); err != nil {
			return "", false, fmt.Errorf("unable to parse plugin file v2: %w", err)
		}

		// Look for beads plugin - take first entry from the array
		if entries, ok := pluginDataV2.Plugins["beads@beads-marketplace"]; ok && len(entries) > 0 {
			return entries[0].Version, true, nil
		}
		return "", false, nil
	}

	// Handle version 1 format (original): plugins map contains structs directly
	var pluginDataV1 struct {
		Plugins map[string]struct {
			Version string `json:"version"`
		} `json:"plugins"`
	}

	if err := json.Unmarshal(data, &pluginDataV1); err != nil {
		return "", false, fmt.Errorf("unable to parse plugin file: %w", err)
	}

	// Look for beads plugin
	if plugin, ok := pluginDataV1.Plugins["beads@beads-marketplace"]; ok {
		return plugin.Version, true, nil
	}

	return "", false, nil
}

func fetchLatestPyPIVersion(packageName string) (string, error) {
	url := fmt.Sprintf("https://pypi.org/pypi/%s/json", packageName)

	client := &http.Client{
		Timeout: 5 * time.Second,
	}

	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return "", err
	}

	// Set User-Agent
	req.Header.Set("User-Agent", "beads-cli-doctor")

	resp, err := client.Do(req)
	if err != nil {
		return "", err
	}
	defer func() { _ = resp.Body.Close() }()

	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("pypi api returned status %d", resp.StatusCode)
	}

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", err
	}

	var data struct {
		Info struct {
			Version string `json:"version"`
		} `json:"info"`
	}

	if err := json.Unmarshal(body, &data); err != nil {
		return "", err
	}

	return data.Info.Version, nil
}

// CheckClaudeSettingsHealth validates that Claude Code settings files are well-formed JSON.
// Malformed settings silently break hooks and plugin detection.
// repoPath is the project root directory.
func CheckClaudeSettingsHealth(repoPath string) DoctorCheck {
	home, err := os.UserHomeDir()
	if err != nil {
		return DoctorCheck{
			Name:    "Claude Settings Health",
			Status:  StatusOK,
			Message: "N/A (unable to determine home directory)",
		}
	}

	settingsFiles := []struct {
		path  string
		label string
	}{
		{filepath.Join(home, ".claude", "settings.json"), "~/.claude/settings.json"},
		{filepath.Join(repoPath, ".claude", "settings.json"), ".claude/settings.json"},
		{filepath.Join(repoPath, ".claude", "settings.local.json"), ".claude/settings.local.json"},
	}

	var malformed []string
	var checked int
	for _, sf := range settingsFiles {
		data, err := os.ReadFile(sf.path) // #nosec G304 -- paths are constructed from known safe locations
		if err != nil {
			continue // File doesn't exist, skip
		}
		checked++
		var parsed map[string]interface{}
		if err := json.Unmarshal(data, &parsed); err != nil {
			malformed = append(malformed, fmt.Sprintf("%s: %v", sf.label, err))
		}
	}

	if checked == 0 {
		return DoctorCheck{
			Name:    "Claude Settings Health",
			Status:  StatusOK,
			Message: "No Claude Code settings files found",
		}
	}

	if len(malformed) > 0 {
		return DoctorCheck{
			Name:    "Claude Settings Health",
			Status:  StatusError,
			Message: fmt.Sprintf("%d malformed settings file(s)", len(malformed)),
			Detail:  strings.Join(malformed, "\n"),
			Fix:     "Fix the JSON syntax in the listed file(s). Malformed settings break hooks and plugin detection.",
		}
	}

	return DoctorCheck{
		Name:    "Claude Settings Health",
		Status:  StatusOK,
		Message: fmt.Sprintf("%d settings file(s) valid", checked),
	}
}

// CheckClaudeHookCompleteness verifies that when hooks are installed,
// SessionStart is covered. Claude Code fires SessionStart on startup, resume,
// clear, and after compaction, so current bd prime context injection only needs
// SessionStart.
// repoPath is the project root directory.
func CheckClaudeHookCompleteness(repoPath string) DoctorCheck {
	home, err := os.UserHomeDir()
	if err != nil {
		return DoctorCheck{
			Name:    "Claude Hook Completeness",
			Status:  StatusOK,
			Message: "N/A (unable to determine home directory)",
		}
	}

	settingsFiles := []string{
		filepath.Join(home, ".claude", "settings.json"),
		filepath.Join(repoPath, ".claude", "settings.json"),
		filepath.Join(repoPath, ".claude", "settings.local.json"),
	}

	var hasAnyHook bool
	var hasSessionStart bool

	for _, sf := range settingsFiles {
		ss, pc := checkHookEvents(sf)
		if ss || pc {
			hasAnyHook = true
		}
		if ss {
			hasSessionStart = true
		}
	}

	if !hasAnyHook {
		// No hooks installed at all - CheckClaude already reports this
		return DoctorCheck{
			Name:    "Claude Hook Completeness",
			Status:  StatusOK,
			Message: "N/A (no hooks installed)",
		}
	}

	if hasSessionStart {
		return DoctorCheck{
			Name:    "Claude Hook Completeness",
			Status:  StatusOK,
			Message: "SessionStart hook present",
		}
	}

	return DoctorCheck{
		Name:    "Claude Hook Completeness",
		Status:  StatusWarning,
		Message: "Missing hook event(s): SessionStart",
		Detail:  "SessionStart injects context on new sessions and after compaction.",
		Fix: "Run 'bd setup claude' to install hooks, or\n" +
			"install the beads plugin which includes hooks automatically.",
	}
}

// checkHookEvents returns which bd-prime hook events are present in a settings file.
func checkHookEvents(settingsPath string) (hasSessionStart, hasPreCompact bool) {
	data, err := os.ReadFile(settingsPath) // #nosec G304 -- paths are constructed from known safe locations
	if err != nil {
		return false, false
	}

	var settings map[string]interface{}
	if err := json.Unmarshal(data, &settings); err != nil {
		return false, false
	}

	hooks, ok := settings["hooks"].(map[string]interface{})
	if !ok {
		return false, false
	}

	checkEvent := func(eventName string) bool {
		eventHooks, ok := hooks[eventName].([]interface{})
		if !ok {
			return false
		}
		for _, hook := range eventHooks {
			hookMap, ok := hook.(map[string]interface{})
			if !ok {
				continue
			}
			commands, ok := hookMap["hooks"].([]interface{})
			if !ok {
				continue
			}
			for _, cmd := range commands {
				cmdMap, ok := cmd.(map[string]interface{})
				if !ok {
					continue
				}
				cmdStr, _ := cmdMap["command"].(string)
				switch cmdStr {
				case "bd prime", "bd prime --stealth",
					"bd prime --hook-json", "bd prime --stealth --hook-json":
					return true
				}
			}
		}
		return false
	}

	return checkEvent("SessionStart"), checkEvent("PreCompact")
}
